<?php
     get_header();
     $options = get_design_plus_option();

     $desc = get_post_meta($post->ID, 'page_sub_title', true);
     $page_title_color = get_post_meta($post->ID, 'page_font_color', true);
     $page_bg_color = get_post_meta($post->ID, 'page_bg_color', true);
     $page_bg_image = get_post_meta($post->ID, 'page_bg_image', true);
     $page_bg_image_mobile = get_post_meta($post->ID, 'page_bg_image_mobile', true);
     $use_overlay = get_post_meta($post->ID, 'page_use_overlay', true);
     if($use_overlay) {
       $page_overlay_color = get_post_meta($post->ID, 'page_overlay_color', true);
       if($page_overlay_color){
         $overlay_color = hex2rgb($page_overlay_color);
         $overlay_color = implode(",",$overlay_color);
         $overlay_opacity = get_post_meta($post->ID, 'page_overlay_opacity', true);
       };
     }
?>
<div id="page_header" style="background:<?php echo esc_attr($page_bg_color); ?>">
 <div id="page_header_inner">
  <div id="page_header_catch" style="color:<?php echo esc_html($page_title_color); ?>;">
   <h2 class="catch rich_font animate_pc animate_mobile"><?php the_title(); ?></h2>
   <?php if($desc){ ?><p class="desc animate_pc animate_mobile"><span><?php echo nl2br(esc_html($desc)); ?></span></p><?php }; ?>
  </div>
 </div>
 <?php if($use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>);"></div><?php }; ?>
 <?php if($page_bg_image || $page_bg_image_mobile) { ?><div class="bg_image" data-parallax-image="<?php echo esc_attr(wp_get_attachment_url($page_bg_image)); ?>" data-parallax-mobile-image="<?php echo esc_attr(wp_get_attachment_url($page_bg_image_mobile)); ?>" data-parallax-speed="0"></div><?php }; ?>
</div>

<div id="main_contents" class="clearfix">

 <div id="main_col" class="clearfix">

 <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

 <article id="article" class="clearfix">

  <?php // post content ------------------------------------------------------------------------------------------------------------------------ ?>
  <div class="post_content clearfix">
   <?php
        the_content();
        if ( ! post_password_required() ) {
          $pagenation_type = get_post_meta($post->ID, 'pagenation_type', true);
          if($pagenation_type == 'type3') {
            $pagenation_type = $options['pagenation_type'];
          };
          if ( $pagenation_type == 'type2' ) {
            if ( $page < $numpages && preg_match( '/href="(.*?)"/', _wp_link_page( $page + 1 ), $matches ) ) :
   ?>
   <div id="p_readmore">
    <a class="button" href="<?php echo esc_url( $matches[1] ); ?>"><?php _e( 'Read more', 'tcd-w' ); ?></a>
    <p class="num"><?php echo $page . ' / ' . $numpages; ?></p>
   </div>
   <?php
            endif;
          } else {
            custom_wp_link_pages();
          }
        }
   ?>
  </div>

  <?php endwhile; endif; ?>

  </article><!-- END #article -->

 </div><!-- END #main_col -->

 <?php get_sidebar(); ?>

</div><!-- END #main_contents -->

<?php get_footer(); ?>