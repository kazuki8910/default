<?php
/*
Template Name:MESSAGE Page
*/
__('MESSAGE Page', 'tcd-w');
?>
<?php
     get_header();
     $options = get_design_plus_option();

     $desc = get_post_meta($post->ID, 'page_sub_title', true);
     $show_tab = get_post_meta($post->ID, 'show_tab', true);
     $tab_bg_blur = get_post_meta($post->ID, 'tab_bg_blur', true);
     $page_title_color = get_post_meta($post->ID, 'page_font_color', true);
     $page_bg_color = get_post_meta($post->ID, 'page_bg_color', true);
     $page_bg_image = get_post_meta($post->ID, 'page_bg_image', true);
     $page_bg_image_mobile = get_post_meta($post->ID, 'page_bg_image_mobile', true);
     $page_use_para = get_post_meta($post->ID, 'page_use_para', true);
     $use_overlay = get_post_meta($post->ID, 'page_use_overlay', true);
     if($use_overlay) {
       $overlay_color = hex2rgb(get_post_meta($post->ID, 'page_overlay_color', true));
       $overlay_color = implode(",",$overlay_color);
       $overlay_opacity = get_post_meta($post->ID, 'page_overlay_opacity', true);
     }

     $page_content_order = get_post_meta($post->ID, 'page2_content_order', true);
     if(empty($page_content_order)) {
       $page_content_order = array('content1','content2','content3','content4');
     }
?>
<div id="page_header" style="background:<?php echo esc_attr($page_bg_color); ?>;">
 <div id="page_header_catch" style="color:<?php echo esc_html($page_title_color); ?>;">
  <h2 class="catch rich_font animate_pc animate_mobile"><span><?php the_title(); ?></span></h2>
  <?php if($desc){ ?><p class="desc animate_pc animate_mobile"><span><?php echo nl2br(esc_html($desc)); ?></span></p><?php }; ?>
 </div>
 <?php
      // tab button
      if($show_tab){
 ?>
 <div id="tab_button_list">
  <div id="tab_button_list_inner">
   <ul>
    <?php
         foreach((array) $page_content_order as $page_content) :
           $i = preg_replace('/[^0-9]/', '', $page_content);
           $tab_name = get_post_meta($post->ID, 'design2_tab' . $i . '_name', true);
           $show_dc = get_post_meta($post->ID, 'show_design2_content'. $i, true);
    ?>
    <?php if( ($page_content == 'content'.$i) && $show_dc && $tab_name ) { ?><li><a href="#design_content_id<?php echo $i; ?>"><?php echo esc_html($tab_name); ?></a></li><?php }; ?>
    <?php endforeach; ?>
   </ul>
  </div>
  <?php if(($page_bg_image || $page_bg_image_mobile) && $tab_bg_blur) { ?>
  <?php if($use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>);"></div><?php }; ?>
  <div id="blur_bg" data-parallax-overlay-blur="<?php echo $tab_bg_blur; ?>"></div>
  <?php }; ?>
 </div>
 <?php }; // END tab button ?>
 <?php if($use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>);"></div><?php }; ?>
 <?php if($page_bg_image || $page_bg_image_mobile) { ?><div class="bg_image" data-parallax-image="<?php echo esc_attr(wp_get_attachment_url($page_bg_image)); ?>" data-parallax-mobile-image="<?php echo esc_attr(wp_get_attachment_url($page_bg_image_mobile)); ?>"<?php if ($page_use_para != 'type1') echo ' data-parallax-speed="0"'; ?>></div><?php }; ?>
</div>

<div id="design_page2">

 <?php
      if ( have_posts() ) : while ( have_posts() ) : the_post();
        if(!post_password_required( $post->ID )):

        foreach((array) $page_content_order as $page_content) :

        $i = preg_replace('/[^0-9]/', '', $page_content);

        $show_design2_content = get_post_meta($post->ID, 'show_design2_content'.$i, true);

        $design2_catch = get_post_meta($post->ID, 'design2_content' . $i . '_catch', true);
        $design2_sub_title = get_post_meta($post->ID, 'design2_content' . $i . '_sub_title', true);
        $design2_desc = get_post_meta($post->ID, 'design2_content' . $i . '_desc', true);

        $show_design2_ic = get_post_meta($post->ID, 'show_design2_content' . $i . '_ic', true);
        $design2_ic_image_id = get_post_meta($post->ID, 'design2_content' . $i . '_ic_image', true);
        $design2_ic_use_para = get_post_meta($post->ID, 'design2_content' . $i . '_ic_use_para', true);

        $design2_ic_catch = get_post_meta($post->ID, 'design2_content' . $i . '_ic_catch', true);
        $design2_ic_title = get_post_meta($post->ID, 'design2_content' . $i . '_ic_title', true);
        $design2_ic_sub_title = get_post_meta($post->ID, 'design2_content'. $i . '_ic_sub_title', true);

        $design2_ic_tab = get_post_meta($post->ID, 'design2_content' . $i . '_ic_tab', true);
        $design2_ic_tab_font_color = get_post_meta($post->ID, 'design2_content' . $i . '_ic_tab_font_color', true);
        $design2_ic_tab_bg_color = get_post_meta($post->ID, 'design2_content' . $i . '_ic_tab_bg_color', true);

        $design2_ic_font_color = get_post_meta($post->ID, 'design2_content' . $i . '_ic_font_color', true);
        $design2_ic_content_direction = get_post_meta($post->ID, 'design2_content' . $i . '_ic_content_direction', true);

        $design2_ic_use_overlay = get_post_meta($post->ID, 'design2_content' . $i . '_ic_use_overlay', true);
        if($design2_ic_use_overlay) {
          $design2_ic_overlay_color = hex2rgb(get_post_meta($post->ID, 'design2_content' . $i . '_ic_overlay_color', true));
          $design2_ic_overlay_color = implode(",",$design2_ic_overlay_color);
          $design2_ic_overlay_opacity = get_post_meta($post->ID, 'design2_content' . $i . '_ic_overlay_opacity', true);
        };

        // content -----------------------------------------------------------------------
        if( ($page_content == 'content'.$i) && $show_design2_content ) {
 ?>
 <div id="design_content_id<?php echo $i; ?>">

   <?php
        // catch and desc
        if($design2_catch || $design2_sub_title || $design2_desc){
   ?>
   <div class="dc_content">
    <?php if($design2_catch){ ?>
    <?php if($design2_sub_title){ ?><p class="sub_title"><?php echo wp_kses_post(nl2br($design2_sub_title)); ?></p><?php }; ?>
    <h3 class="catch rich_font"><span><?php echo wp_kses_post(nl2br($design2_catch)); ?></span></h3>
    <?php }; ?>
    <?php if($design2_desc) { ?>
    <div class="post_content clearfix">
     <?php echo do_shortcode( wpautop(wp_kses_post($design2_desc)) ); ?>
    </div>
    <?php }; ?>
   </div><!-- END .dc_content -->
   <?php }; ?>

   <?php
        // image_content
        if($show_design2_ic && $design2_ic_image_id){
   ?>
   <div class="dc_image_content">
    <div class="dc_image_content_inner direction_<?php echo esc_attr($design2_ic_content_direction); ?>">
     <?php if($design2_ic_tab){ ?>
     <p class="tab" style="color:<?php echo esc_attr($design2_ic_tab_font_color); ?>; background:<?php echo esc_attr($design2_ic_tab_bg_color); ?>;"><?php echo wp_kses_post(nl2br($design2_ic_tab)); ?></p>
     <?php }; ?>
     <?php if($design2_ic_catch || $design2_ic_title){ ?>
     <div class="caption" style="color:<?php echo esc_attr($design2_ic_font_color); ?>;">
      <?php if($design2_ic_catch){ ?>
      <h4 class="catch rich_font"><span><?php echo wp_kses_post(nl2br($design2_ic_catch)); ?></span></h4>
      <?php }; ?>
      <?php if($design2_ic_title) { ?>
      <p class="title"><?php if($design2_ic_sub_title) { echo '<span>' . esc_html($design2_ic_sub_title) . '</span>'; }; ?><?php echo wp_kses_post(nl2br($design2_ic_title)); ?></p>
      <?php }; ?>
     </div>
     <?php }; ?>
    </div>
    <?php if($design2_ic_overlay_color) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($design2_ic_overlay_color); ?>,<?php echo esc_html($design2_ic_overlay_opacity); ?>);"></div><?php }; ?>
    <?php if($design2_ic_image_id) { ?><div class="bg_image" data-parallax-image="<?php echo esc_attr(wp_get_attachment_url($design2_ic_image_id)); ?>" data-parallax-mobile-image=""<?php if ($design2_ic_use_para != 'type1') echo ' data-parallax-speed="0"'; ?>></div><?php }; ?>
   </div><!-- END .dc_image_content -->
   <?php }; ?>

  </div><!-- END #design_content_id -->
  <?php }; ?>

  <?php endforeach; // END contet order ?>

  <?php else: ?>
  <div class="dc_content">
  <?php the_content();
    custom_wp_link_pages();
  ?>
  </div>
  <?php endif; // END post_password_required ?>

  <?php endwhile; endif; ?>

</div><!-- END #design_page -->

<?php get_footer(); ?>