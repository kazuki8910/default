<?php

function design1_meta_box() {
  add_meta_box(
    'design1_meta_box',//ID of meta box
    __('ABOUT Page setting', 'tcd-w'),//label
    'show_design1_meta_box',//callback function
    'page',// post type
    'normal',// context
    'high'// priority
  );
}
add_action('add_meta_boxes', 'design1_meta_box');

function show_design1_meta_box() {
  global $post, $font_type_options, $content_direction_options, $para_options;

  $design1_tab1_name = get_post_meta($post->ID, 'design1_tab1_name', true);
  $design1_tab2_name = get_post_meta($post->ID, 'design1_tab2_name', true);
  $design1_tab3_name = get_post_meta($post->ID, 'design1_tab3_name', true);
  $design1_tab4_name = get_post_meta($post->ID, 'design1_tab4_name', true);

  // コンテンツ１ -------------------------------------------------------
  $show_design1_content1 = get_post_meta($post->ID, 'show_design1_content1', true);

  $design1_content1_catch = get_post_meta($post->ID, 'design1_content1_catch', true);
  $design1_content1_catch_font_size = get_post_meta($post->ID, 'design1_content1_catch_font_size', true);
  if(empty($design1_content1_catch_font_size)){
    $design1_content1_catch_font_size = '30';
  }
  $design1_content1_catch_font_size_mobile = get_post_meta($post->ID, 'design1_content1_catch_font_size_mobile', true);
  if(empty($design1_content1_catch_font_size_mobile)){
    $design1_content1_catch_font_size_mobile = '20';
  }
  $design1_content1_desc = get_post_meta($post->ID, 'design1_content1_desc', true);

  // 画像コンテンツ
  $show_design1_content1_ic = get_post_meta($post->ID, 'show_design1_content1_ic', true);
  $design1_content1_ic_use_para = get_post_meta($post->ID, 'design1_content1_ic_use_para', true);
  if(empty($design1_content1_ic_use_para)){
    $design1_content1_ic_use_para = 'type1';
  }

  // キャッチフレーズ
  $design1_content1_ic_catch = get_post_meta($post->ID, 'design1_content1_ic_catch', true);
  $design1_content1_ic_catch_font_size = get_post_meta($post->ID, 'design1_content1_ic_catch_font_size', true);
  if(empty($design1_content1_ic_catch_font_size)){
    $design1_content1_ic_catch_font_size = '26';
  }
  $design1_content1_ic_catch_font_size_mobile = get_post_meta($post->ID, 'design1_content1_ic_catch_font_size_mobile', true);
  if(empty($design1_content1_ic_catch_font_size_mobile)){
    $design1_content1_ic_catch_font_size_mobile = '20';
  }

  // タイトル
  $design1_content1_ic_title = get_post_meta($post->ID, 'design1_content1_ic_title', true);
  $design1_content1_ic_title_font_size = get_post_meta($post->ID, 'design1_content1_ic_title_font_size', true);
  if(empty($design1_content1_ic_title_font_size)){
    $design1_content1_ic_title_font_size = '20';
  }
  $design1_content1_ic_title_font_size_mobile = get_post_meta($post->ID, 'design1_content1_ic_title_font_size_mobile', true);
  if(empty($design1_content1_ic_title_font_size_mobile)){
    $design1_content1_ic_title_font_size_mobile = '16';
  }

  // サブタイトル
  $design1_content1_ic_sub_title = get_post_meta($post->ID, 'design1_content1_ic_sub_title', true);
  $design1_content1_ic_sub_title_font_size = get_post_meta($post->ID, 'design1_content1_ic_sub_title_font_size', true);
  if(empty($design1_content1_ic_sub_title_font_size)){
    $design1_content1_ic_sub_title_font_size = '14';
  }
  $design1_content1_ic_sub_title_font_size_mobile = get_post_meta($post->ID, 'design1_content1_ic_sub_title_font_size_mobile', true);
  if(empty($design1_content1_ic_sub_title_font_size_mobile)){
    $design1_content1_ic_sub_title_font_size_mobile = '12';
  }

  // 文字の方向
  $design1_content1_ic_content_direction = get_post_meta($post->ID, 'design1_content1_ic_content_direction', true);
  if(empty($design1_content1_ic_content_direction)){
    $design1_content1_ic_content_direction = 'type2';
  }

  // 色の設定
  $design1_content1_ic_font_color = get_post_meta($post->ID, 'design1_content1_ic_font_color', true);
  if(empty($design1_content1_ic_font_color)){
    $design1_content1_ic_font_color = '#FFFFFF';
  };
  $design1_content1_ic_use_overlay = get_post_meta($post->ID, 'design1_content1_ic_use_overlay', true);
  $design1_content1_ic_overlay_color = get_post_meta($post->ID, 'design1_content1_ic_overlay_color', true);
  if(empty($design1_content1_ic_overlay_color)){
    $design1_content1_ic_overlay_color = '#000000';
  };
  $design1_content1_ic_overlay_opacity = get_post_meta($post->ID, 'design1_content1_ic_overlay_opacity', true);
  if(empty($design1_content1_ic_overlay_opacity)){
    $design1_content1_ic_overlay_opacity = '0.3';
  };

  // コンテンツ２ -------------------------------------------------------
  $show_design1_content2 = get_post_meta($post->ID, 'show_design1_content2', true);

  $design1_content2_catch = get_post_meta($post->ID, 'design1_content2_catch', true);
  $design1_content2_catch_font_size = get_post_meta($post->ID, 'design1_content2_catch_font_size', true);
  if(empty($design1_content2_catch_font_size)){
    $design1_content2_catch_font_size = '30';
  }
  $design1_content2_catch_font_size_mobile = get_post_meta($post->ID, 'design1_content2_catch_font_size_mobile', true);
  if(empty($design1_content2_catch_font_size_mobile)){
    $design1_content2_catch_font_size_mobile = '20';
  }

  $design1_content2_desc = get_post_meta($post->ID, 'design1_content2_desc', true);
  $design1_content2_desc2 = get_post_meta($post->ID, 'design1_content2_desc2', true);

  $design1_content2_data_list = get_post_meta($post->ID, 'design1_content2_data_list', true);

  // 画像コンテンツ
  $show_design1_content2_ic = get_post_meta($post->ID, 'show_design1_content2_ic', true);
  $design1_content2_ic_use_para = get_post_meta($post->ID, 'design1_content2_ic_use_para', true);
  if(empty($design1_content2_ic_use_para)){
    $design1_content2_ic_use_para = 'type1';
  }

  // キャッチフレーズ
  $design1_content2_ic_catch = get_post_meta($post->ID, 'design1_content2_ic_catch', true);
  $design1_content2_ic_catch_font_size = get_post_meta($post->ID, 'design1_content2_ic_catch_font_size', true);
  if(empty($design1_content2_ic_catch_font_size)){
    $design1_content2_ic_catch_font_size = '26';
  }
  $design1_content2_ic_catch_font_size_mobile = get_post_meta($post->ID, 'design1_content2_ic_catch_font_size_mobile', true);
  if(empty($design1_content2_ic_catch_font_size_mobile)){
    $design1_content2_ic_catch_font_size_mobile = '30';
  }

  // タイトル
  $design1_content2_ic_title = get_post_meta($post->ID, 'design1_content2_ic_title', true);
  $design1_content2_ic_title_font_size = get_post_meta($post->ID, 'design1_content2_ic_title_font_size', true);
  if(empty($design1_content2_ic_title_font_size)){
    $design1_content2_ic_title_font_size = '20';
  }
  $design1_content2_ic_title_font_size_mobile = get_post_meta($post->ID, 'design1_content2_ic_title_font_size_mobile', true);
  if(empty($design1_content2_ic_title_font_size_mobile)){
    $design1_content2_ic_title_font_size_mobile = '16';
  }

  // サブタイトル
  $design1_content2_ic_sub_title = get_post_meta($post->ID, 'design1_content2_ic_sub_title', true);
  $design1_content2_ic_sub_title_font_size = get_post_meta($post->ID, 'design1_content2_ic_sub_title_font_size', true);
  if(empty($design1_content2_ic_sub_title_font_size)){
    $design1_content2_ic_sub_title_font_size = '14';
  }
  $design1_content2_ic_sub_title_font_size_mobile = get_post_meta($post->ID, 'design1_content2_ic_sub_title_font_size_mobile', true);
  if(empty($design1_content2_ic_sub_title_font_size_mobile)){
    $design1_content2_ic_sub_title_font_size_mobile = '12';
  }

  // 文字の方向
  $design1_content2_ic_content_direction = get_post_meta($post->ID, 'design1_content2_ic_content_direction', true);
  if(empty($design1_content2_ic_content_direction)){
    $design1_content2_ic_content_direction = 'type2';
  }

  // 色の設定
  $design1_content2_ic_font_color = get_post_meta($post->ID, 'design1_content2_ic_font_color', true);
  if(empty($design1_content2_ic_font_color)){
    $design1_content2_ic_font_color = '#FFFFFF';
  };
  $design1_content2_ic_use_overlay = get_post_meta($post->ID, 'design1_content2_ic_use_overlay', true);
  $design1_content2_ic_overlay_color = get_post_meta($post->ID, 'design1_content2_ic_overlay_color', true);
  if(empty($design1_content2_ic_overlay_color)){
    $design1_content2_ic_overlay_color = '#000000';
  };
  $design1_content2_ic_overlay_opacity = get_post_meta($post->ID, 'design1_content2_ic_overlay_opacity', true);
  if(empty($design1_content2_ic_overlay_opacity)){
    $design1_content2_ic_overlay_opacity = '0.3';
  };

  // コンテンツ３ -------------------------------------------------------
  $show_design1_content3 = get_post_meta($post->ID, 'show_design1_content3', true);

  $design1_content3_headline = get_post_meta($post->ID, 'design1_content3_headline', true);
  $design1_content3_headline_font_size = get_post_meta($post->ID, 'design1_content3_headline_font_size', true);
  if(empty($design1_content3_headline_font_size)){
    $design1_content3_headline_font_size = '26';
  }
  $design1_content3_headline_font_size_mobile = get_post_meta($post->ID, 'design1_content3_headline_font_size_mobile', true);
  if(empty($design1_content3_headline_font_size_mobile)){
    $design1_content3_headline_font_size_mobile = '20';
  }

  $design1_content3_data_list = get_post_meta($post->ID, 'design1_content3_data_list', true);

  // コンテンツ４ -------------------------------------------------------
  $show_design1_content4 = get_post_meta($post->ID, 'show_design1_content4', true);

  $design1_content4_headline = get_post_meta($post->ID, 'design1_content4_headline', true);
  $design1_content4_headline_font_size = get_post_meta($post->ID, 'design1_content4_headline_font_size', true);
  if(empty($design1_content4_headline_font_size)){
    $design1_content4_headline_font_size = '26';
  }
  $design1_content4_headline_font_size_mobile = get_post_meta($post->ID, 'design1_content4_headline_font_size_mobile', true);
  if(empty($design1_content4_headline_font_size_mobile)){
    $design1_content4_headline_font_size_mobile = '20';
  }

  // アクセス情報
  $access_address = get_post_meta($post->ID, 'access_address', true);
  $access_logo_retina = get_post_meta($post->ID,'access_logo_retina',true);
  $access_desc1 = get_post_meta($post->ID, 'access_desc1', true);
  $access_desc2 = get_post_meta($post->ID, 'access_desc2', true);

  $access_saturation = get_post_meta($post->ID, 'access_saturation', true);
  if(empty($access_saturation)){
    $access_saturation = '-100';
  }
  $show_access_button = get_post_meta($post->ID, 'show_access_button', true);
  $access_button_label = get_post_meta($post->ID, 'access_button_label', true);
  if(empty($access_button_label)){
    $access_button_label = __( 'Display on large map', 'tcd-w' );
  }
  $access_button_url = get_post_meta($post->ID, 'access_button_url', true);
  $access_button_font_color = get_post_meta($post->ID, 'access_button_font_color', true);
  if(empty($access_button_font_color)){
    $access_button_font_color = '#ffffff';
  };
  $access_button_bg_color = get_post_meta($post->ID, 'access_button_bg_color', true);
  if(empty($access_button_bg_color)){
    $access_button_bg_color = '#000000';
  };
  $access_button_font_color_hover = get_post_meta($post->ID, 'access_button_font_color_hover', true);
  if(empty($access_button_font_color_hover)){
    $access_button_font_color_hover = '#ffffff';
  };
  $access_button_bg_color_hover = get_post_meta($post->ID, 'access_button_bg_color_hover', true);
  if(empty($access_button_bg_color_hover)){
    $access_button_bg_color_hover = '#333333';
  };

  // 並び替え
  $page_content_order = get_post_meta($post->ID, 'page_content_order', true);
  if(empty($page_content_order)) {
    $page_content_order = array('content1','content2','content3','content4');
  }

  echo '<input type="hidden" name="design1_custom_fields_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';

  //入力欄 ***************************************************************************************************************************************************************************************
?>

<?php
     // WP5.0対策として隠しフィールドを用意　選択されているページテンプレートによってABOUT入力欄を表示・非表示する
     if ( count( get_page_templates( $post ) ) > 0 && get_option( 'page_for_posts' ) != $post->ID ) :
       $template = ! empty( $post->page_template ) ? $post->page_template : false;
?>
<select name="hidden_page_template" id="hidden_page_template" style="display:none;">
 <option value="default">Default Template</option>
 <?php page_template_dropdown( $template, 'page' ); ?>
</select>
<?php endif; ?>

<div class="tcd_custom_field_wrap">

 <div class="theme_option_message" style="margin-top:0;">
  <p><?php _e('You can change order by dragging each headline of option field.', 'tcd-w');  ?></p>
 </div>

 <?php // 並び替え ----- ?>
 <div class="theme_option_field_order" style="margin-bottom:15px;">
 <?php foreach((array) $page_content_order as $page_content) : ?>

 <?php // コンテンツ１ ----------------------------------------------------- ?>
 <?php if ($page_content == 'content1') : ?>
  <div class="theme_option_field cf theme_option_field_ac">
   <h3 class="theme_option_headline"><?php printf(__('Content%s setting', 'tcd-w'), 1); ?></h3>
   <div class="theme_option_field_ac_content">
    <p><label for="show_design1_content1"><input id="show_design1_content1" type="checkbox" name="show_design1_content1" value="1" <?php checked( $show_design1_content1, 1 ); ?>><?php printf(__('Display content%s', 'tcd-w'), 1); ?></label></p>
    <h3 class="theme_option_headline2"><?php _e('Tab name', 'tcd-w'); ?></h3>
    <input style="width:100%;" type="text" name="design1_tab1_name" value="<?php echo esc_attr($design1_tab1_name); ?>" />
    <h3 class="theme_option_headline2"><?php _e('Catchphrase', 'tcd-w'); ?></h3>
    <textarea class="large-text" cols="50" rows="2" name="design1_content1_catch"><?php echo esc_textarea($design1_content1_catch); ?></textarea>
    <ul class="option_list">
     <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content1_catch_font_size" value="<?php echo esc_attr($design1_content1_catch_font_size); ?>" /><span>px</span></li>
     <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content1_catch_font_size_mobile" value="<?php echo esc_attr($design1_content1_catch_font_size_mobile); ?>" /><span>px</span></li>
    </ul>
    <h3 class="theme_option_headline2"><?php _e('Content', 'tcd-w'); ?></h3>
    <?php wp_editor( $design1_content1_desc, 'design1_content1_desc', array( 'textarea_name' => 'design1_content1_desc', 'textarea_rows' => 10 )); ?>
    <?php // 画像コンテンツ ?>
    <h3 class="theme_option_headline2"><?php _e('Image content', 'tcd-w'); ?></h3>
    <div class="sub_box cf">
     <h3 class="theme_option_subbox_headline"><?php _e('Image content setting', 'tcd-w'); ?></h3>
     <div class="sub_box_content">
      <p><label><input name="show_design1_content1_ic" type="checkbox" value="1" <?php checked( $show_design1_content1_ic, 1 ); ?>><?php _e( 'Display image content', 'tcd-w' ); ?></label></p>
      <h3 class="theme_option_headline2"><?php _e('Image', 'tcd-w'); ?></h3>
      <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '1450', '500'); ?></p>
      <?php mlcf_media_form('design1_content1_ic_image', __('Image', 'tcd-w') ); ?>
      <h3 class="theme_option_headline2"><?php _e('Catchphrase', 'tcd-w'); ?></h3>
      <textarea class="large-text" cols="50" rows="2" name="design1_content1_ic_catch"><?php echo esc_textarea($design1_content1_ic_catch); ?></textarea>
      <ul class="option_list">
       <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content1_ic_catch_font_size" value="<?php echo esc_attr($design1_content1_ic_catch_font_size); ?>" /><span>px</span></li>
       <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content1_ic_catch_font_size_mobile" value="<?php echo esc_attr($design1_content1_ic_catch_font_size_mobile); ?>" /><span>px</span></li>
      </ul>
      <h3 class="theme_option_headline2"><?php _e('Title', 'tcd-w'); ?></h3>
      <input style="width:100%;" type="text" name="design1_content1_ic_title" value="<?php echo esc_attr($design1_content1_ic_title); ?>" />
      <ul class="option_list">
       <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content1_ic_title_font_size" value="<?php echo esc_attr($design1_content1_ic_title_font_size); ?>" /><span>px</span></li>
       <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content1_ic_title_font_size_mobile" value="<?php echo esc_attr($design1_content1_ic_title_font_size_mobile); ?>" /><span>px</span></li>
      </ul>
      <h3 class="theme_option_headline2"><?php _e('Sub title', 'tcd-w'); ?></h3>
      <input style="width:100%;" type="text" name="design1_content1_ic_sub_title" value="<?php echo esc_attr($design1_content1_ic_sub_title); ?>" />
      <ul class="option_list">
       <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content1_ic_sub_title_font_size" value="<?php echo esc_attr($design1_content1_ic_sub_title_font_size); ?>" /><span>px</span></li>
       <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content1_ic_sub_title_font_size_mobile" value="<?php echo esc_attr($design1_content1_ic_sub_title_font_size_mobile); ?>" /><span>px</span></li>
      </ul>
      <h3 class="theme_option_headline2"><?php _e('Other setting', 'tcd-w'); ?></h3>
      <ul class="option_list">
       <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="design1_content1_ic_font_color" value="<?php echo esc_attr($design1_content1_ic_font_color); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php _e('Content position', 'tcd-w'); ?></span>
        <select name="design1_content1_ic_content_direction">
         <?php foreach ( $content_direction_options as $option ) { ?>
         <option style="padding-right: 10px;" value="<?php esc_attr_e( $option['value'] ); ?>" <?php selected( $design1_content1_ic_content_direction, $option['value'] ); ?>><?php echo $option['label']; ?></option>
         <?php }; ?>
        </select>
       </li>
      </ul>
      <h3 class="theme_option_headline2"><?php _e('Overlay setting', 'tcd-w'); ?></h3>
      <p class="displayment_checkbox"><label><input name="design1_content1_ic_use_overlay" type="checkbox" value="1" <?php checked( $design1_content1_ic_use_overlay, 1 ); ?>><?php _e( 'Use overlay', 'tcd-w' ); ?></label></p>
      <div style="<?php if($design1_content1_ic_use_overlay) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
       <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
        <li class="cf"><span class="label"><?php _e('Color of overlay', 'tcd-w'); ?></span><input class="c-color-picker" type="text" name="design1_content1_ic_overlay_color" value="<?php echo esc_attr( $design1_content1_ic_overlay_color ); ?>" data-default-color="#000000"></li>
        <li class="cf">
         <span class="label"><?php _e('Transparency of overlay', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="design1_content1_ic_overlay_opacity" value="<?php echo esc_attr( $design1_content1_ic_overlay_opacity ); ?>" />
         <div class="theme_option_message2" style="clear:both; margin:7px 0 0 0;">
          <p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p>
         </div>
        </li>
       </ul>
      </div>
      <h3 class="theme_option_headline2"><?php _e('Parallax setting', 'tcd-w'); ?></h3>
      <div class="theme_option_message2">
       <p><?php _e('If you use parallax effect on background, please upload very high height image.', 'tcd-w'); ?></p>
      </div>
      <ul class="design_radio_button">
       <?php foreach ( $para_options as $option ) { ?>
       <li>
        <input type="radio" id="design1_content1_ic_use_para_<?php esc_attr_e( $option['value'] ); ?>" name="design1_content1_ic_use_para" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $design1_content1_ic_use_para, $option['value'] ); ?> />
        <label for="design1_content1_ic_use_para_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
       </li>
       <?php } ?>
      </ul>
      <ul class="button_list cf">
       <li><a class="close_sub_box button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
      </ul>
     </div><!-- END .sub_box_content -->
    </div><!-- END .sub_box -->
    <ul class="button_list cf">
     <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
    </ul>
    <input type="hidden" name="page_content_order[]" value="content1" />
   </div><!-- END .theme_option_field_ac_content -->
  </div><!-- END .theme_option_field -->
 <?php endif; ?>


 <?php // コンテンツ２ ----------------------------------------------------- ?>
 <?php if ($page_content == 'content2') : ?>
  <div class="theme_option_field cf theme_option_field_ac">
   <h3 class="theme_option_headline"><?php printf(__('Content%s setting', 'tcd-w'), 2); ?></h3>
   <div class="theme_option_field_ac_content">
    <p><label for="show_design1_content2"><input id="show_design1_content2" type="checkbox" name="show_design1_content2" value="1" <?php checked( $show_design1_content2, 1 ); ?>><?php printf(__('Display content%s', 'tcd-w'), 2); ?></label></p>
    <h3 class="theme_option_headline2"><?php _e('Tab name', 'tcd-w'); ?></h3>
    <input style="width:100%;" type="text" name="design1_tab2_name" value="<?php echo esc_attr($design1_tab2_name); ?>" />
    <h3 class="theme_option_headline2"><?php _e('Catchphrase', 'tcd-w'); ?></h3>
    <textarea class="large-text" cols="50" rows="2" name="design1_content2_catch"><?php echo esc_textarea($design1_content2_catch); ?></textarea>
    <ul class="option_list">
     <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_catch_font_size" value="<?php echo esc_attr($design1_content2_catch_font_size); ?>" /><span>px</span></li>
     <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_catch_font_size_mobile" value="<?php echo esc_attr($design1_content2_catch_font_size_mobile); ?>" /><span>px</span></li>
    </ul>
    <h3 class="theme_option_headline2"><?php _e('Content', 'tcd-w'); ?>1</h3>
    <?php wp_editor( $design1_content2_desc, 'design1_content2_desc', array( 'textarea_name' => 'design1_content2_desc', 'textarea_rows' => 10 )); ?>
    <h3 class="theme_option_headline2"><?php _e('Image', 'tcd-w'); ?></h3>
    <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '800', '400'); ?></p>
    <?php mlcf_media_form('design1_content2_image', __('Image', 'tcd-w') ); ?>
    <h3 class="theme_option_headline2"><?php _e('Content', 'tcd-w'); ?>2</h3>
    <?php wp_editor( $design1_content2_desc2, 'design1_content2_desc2', array( 'textarea_name' => 'design1_content2_desc2', 'textarea_rows' => 10 )); ?>
    <?php // データ一覧 ---------- ?>
    <h3 class="theme_option_headline2"><?php _e( 'Catchphrase list', 'tcd-w' ); ?></h3>
    <div class="theme_option_message2">
     <p><?php _e('You can change order by dragging each item.', 'tcd-w'); ?></p>
    </div>
    <?php //繰り返しフィールド ----- ?>
    <div class="repeater-wrapper">
     <div class="repeater sortable" data-delete-confirm="<?php _e( 'Delete?', 'tcd-w' ); ?>">
      <?php
           if ( $design1_content2_data_list ) :
             foreach ( $design1_content2_data_list as $key => $value ) :
      ?>
      <div class="sub_box repeater-item repeater-item-<?php echo $key; ?>">
       <h4 class="theme_option_subbox_headline"><?php _e( 'New item', 'tcd-w' ); ?></h4>
       <div class="sub_box_content">
        <h4 class="theme_option_headline2"><?php _e( 'Catchphrase', 'tcd-w' ); ?></h4>
        <textarea class="repeater-label large-text" cols="50" rows="2" name="design1_content2_data_list[<?php echo esc_attr( $key ); ?>][catch]"><?php echo esc_textarea( $design1_content2_data_list[$key]['catch'] ); ?></textarea>
        <h4 class="theme_option_headline2"><?php _e( 'Font size setting', 'tcd-w' ); ?></h4>
        <ul class="option_list">
         <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_data_list[<?php echo esc_attr( $key ); ?>][font_size]" value="<?php echo esc_attr( $design1_content2_data_list[$key]['font_size'] ); ?>" /><span>px</span></li>
         <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_data_list[<?php echo esc_attr( $key ); ?>][font_size_mobile]" value="<?php echo esc_attr( $design1_content2_data_list[$key]['font_size_mobile'] ); ?>" /><span>px</span></li>
        </ul>
        <h4 class="theme_option_headline2"><?php _e( 'Color setting', 'tcd-w' ); ?></h4>
        <ul class="option_list">
         <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="design1_content2_data_list[<?php echo esc_attr( $key ); ?>][font_color]" value="<?php echo esc_attr( $design1_content2_data_list[$key]['font_color']  ); ?>" data-default-color="#000000" class="c-color-picker"></li>
         <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="design1_content2_data_list[<?php echo esc_attr( $key ); ?>][bg_color]" value="<?php echo esc_attr( $design1_content2_data_list[$key]['bg_color']  ); ?>" data-default-color="#f5f5f5" class="c-color-picker"></li>
        </ul>
        <p class="delete-row right-align"><a href="#" class="button button-secondary button-delete-row"><?php _e( 'Delete item', 'tcd-w' ); ?></a></p>
       </div><!-- END .sub_box_content -->
      </div><!-- END .sub_box -->
      <?php
             endforeach;
           endif;
           $key = 'addindex';
           ob_start();
      ?>
      <div class="sub_box repeater-item repeater-item-<?php echo $key; ?>">
       <h4 class="theme_option_subbox_headline"><?php echo esc_html( ! empty( $design1_content2_data_list[$key]['title'] ) ? $design1_content2_data_list[$key]['title'] : __( 'New item', 'tcd-w' ) ); ?></h4>
       <div class="sub_box_content">
        <h4 class="theme_option_headline2"><?php _e( 'Catchphrase', 'tcd-w' );  ?></h4>
        <textarea class="repeater-label large-text" cols="50" rows="2" name="design1_content2_data_list[<?php echo esc_attr( $key ); ?>][catch]"></textarea>
        <h4 class="theme_option_headline2"><?php _e( 'Font size setting', 'tcd-w' ); ?></h4>
        <ul class="option_list">
         <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_data_list[<?php echo esc_attr( $key ); ?>][font_size]" value="22" /><span>px</span></li>
         <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_data_list[<?php echo esc_attr( $key ); ?>][font_size_mobile]" value="18" /><span>px</span></li>
        </ul>
        <h4 class="theme_option_headline2"><?php _e( 'Color setting', 'tcd-w' ); ?></h4>
        <ul class="option_list">
         <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="design1_content2_data_list[<?php echo esc_attr( $key ); ?>][font_color]" value="#000000" data-default-color="#000000" class="c-color-picker"></li>
         <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="design1_content2_data_list[<?php echo esc_attr( $key ); ?>][bg_color]" value="#f5f5f5" data-default-color="#f5f5f5" class="c-color-picker"></li>
        </ul>
        <p class="delete-row right-align"><a href="#" class="button button-secondary button-delete-row"><?php _e( 'Delete item', 'tcd-w' ); ?></a></p>
       </div><!-- END .sub_box_content -->
      </div><!-- END .sub_box -->
      <?php
           $clone = ob_get_clean();
      ?>
     </div><!-- END .repeater -->
     <a href="#" class="button button-secondary button-add-row" data-clone="<?php echo esc_attr( $clone ); ?>"><?php _e( 'Add item', 'tcd-w' ); ?></a>
    </div><!-- END .repeater-wrapper -->
    <?php // 繰り返しフィールドここまで ----- ?>
    <?php // 画像コンテンツ ----- ?>
    <h3 class="theme_option_headline2"><?php _e('Image content', 'tcd-w'); ?></h3>
    <div class="sub_box cf">
     <h3 class="theme_option_subbox_headline"><?php _e('Image content setting', 'tcd-w'); ?></h3>
     <div class="sub_box_content">
      <p><label><input name="show_design1_content2_ic" type="checkbox" value="1" <?php checked( $show_design1_content2_ic, 1 ); ?>><?php _e( 'Display image content', 'tcd-w' ); ?></label></p>
      <h3 class="theme_option_headline2"><?php _e('Image', 'tcd-w'); ?></h3>
      <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '1450', '500'); ?></p>
      <?php mlcf_media_form('design1_content2_ic_image', __('Image', 'tcd-w') ); ?>
      <h3 class="theme_option_headline2"><?php _e('Catchphrase', 'tcd-w'); ?></h3>
      <textarea class="large-text" cols="50" rows="2" name="design1_content2_ic_catch"><?php echo esc_textarea($design1_content2_ic_catch); ?></textarea>
      <ul class="option_list">
       <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_ic_catch_font_size" value="<?php echo esc_attr($design1_content2_ic_catch_font_size); ?>" /><span>px</span></li>
       <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_ic_catch_font_size_mobile" value="<?php echo esc_attr($design1_content2_ic_catch_font_size_mobile); ?>" /><span>px</span></li>
      </ul>
      <h3 class="theme_option_headline2"><?php _e('Title', 'tcd-w'); ?></h3>
      <input style="width:100%;" type="text" name="design1_content2_ic_title" value="<?php echo esc_attr($design1_content2_ic_title); ?>" />
      <ul class="option_list">
       <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_ic_title_font_size" value="<?php echo esc_attr($design1_content2_ic_title_font_size); ?>" /><span>px</span></li>
       <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_ic_title_font_size_mobile" value="<?php echo esc_attr($design1_content2_ic_title_font_size_mobile); ?>" /><span>px</span></li>
      </ul>
      <h3 class="theme_option_headline2"><?php _e('Sub title', 'tcd-w'); ?></h3>
      <input style="width:100%;" type="text" name="design1_content2_ic_sub_title" value="<?php echo esc_attr($design1_content2_ic_sub_title); ?>" />
      <ul class="option_list">
       <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_ic_sub_title_font_size" value="<?php echo esc_attr($design1_content2_ic_sub_title_font_size); ?>" /><span>px</span></li>
       <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content2_ic_sub_title_font_size_mobile" value="<?php echo esc_attr($design1_content2_ic_sub_title_font_size_mobile); ?>" /><span>px</span></li>
      </ul>
      <h3 class="theme_option_headline2"><?php _e('Other setting', 'tcd-w'); ?></h3>
      <ul class="option_list">
       <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="design1_content2_ic_font_color" value="<?php echo esc_attr($design1_content2_ic_font_color); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php _e('Content position', 'tcd-w'); ?></span>
        <select name="design1_content2_ic_content_direction">
         <?php foreach ( $content_direction_options as $option ) { ?>
         <option style="padding-right: 10px;" value="<?php esc_attr_e( $option['value'] ); ?>" <?php selected( $design1_content2_ic_content_direction, $option['value'] ); ?>><?php echo $option['label']; ?></option>
         <?php }; ?>
        </select>
       </li>
      </ul>
      <h3 class="theme_option_headline2"><?php _e('Overlay setting', 'tcd-w'); ?></h3>
      <p class="displayment_checkbox"><label><input name="design1_content2_ic_use_overlay" type="checkbox" value="1" <?php checked( $design1_content2_ic_use_overlay, 1 ); ?>><?php _e( 'Use overlay', 'tcd-w' ); ?></label></p>
      <div style="<?php if($design1_content2_ic_use_overlay) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
       <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
        <li class="cf"><span class="label"><?php _e('Color of overlay', 'tcd-w'); ?></span><input class="c-color-picker" type="text" name="design1_content2_ic_overlay_color" value="<?php echo esc_attr( $design1_content2_ic_overlay_color ); ?>" data-default-color="#000000"></li>
        <li class="cf">
         <span class="label"><?php _e('Transparency of overlay', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="design1_content2_ic_overlay_opacity" value="<?php echo esc_attr( $design1_content2_ic_overlay_opacity ); ?>" />
         <div class="theme_option_message2" style="clear:both; margin:7px 0 0 0;">
          <p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p>
         </div>
        </li>
       </ul>
      </div>
      <h3 class="theme_option_headline2"><?php _e('Parallax setting', 'tcd-w'); ?></h3>
      <div class="theme_option_message2">
       <p><?php _e('If you use parallax effect on background, please upload very high height image.', 'tcd-w'); ?></p>
      </div>
      <ul class="design_radio_button">
       <?php foreach ( $para_options as $option ) { ?>
       <li>
        <input type="radio" id="design1_content2_ic_use_para_<?php esc_attr_e( $option['value'] ); ?>" name="design1_content2_ic_use_para" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $design1_content2_ic_use_para, $option['value'] ); ?> />
        <label for="design1_content2_ic_use_para_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
       </li>
       <?php } ?>
      </ul>
      <ul class="button_list cf">
       <li><a class="close_sub_box button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
      </ul>
     </div><!-- END .sub_box_content -->
    </div><!-- END .sub_box -->
    <ul class="button_list cf">
     <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
    </ul>
    <input type="hidden" name="page_content_order[]" value="content2" />
   </div><!-- END .theme_option_field_ac_content -->
  </div><!-- END .theme_option_field -->
 <?php endif; ?>


 <?php // コンテンツ３ ----------------------------------------------------- ?>
 <?php if ($page_content == 'content3') : ?>
  <div class="theme_option_field cf theme_option_field_ac">
   <h3 class="theme_option_headline"><?php printf(__('Content%s setting', 'tcd-w'), 3); ?></h3>
   <div class="theme_option_field_ac_content">
    <p><label for="show_design1_content3"><input id="show_design1_content3" type="checkbox" name="show_design1_content3" value="1" <?php checked( $show_design1_content3, 1 ); ?>><?php printf(__('Display content%s', 'tcd-w'), 3); ?></label></p>
    <h3 class="theme_option_headline2"><?php _e('Tab name', 'tcd-w'); ?></h3>
    <input style="width:100%;" type="text" name="design1_tab3_name" value="<?php echo esc_attr($design1_tab3_name); ?>" />
    <h3 class="theme_option_headline2"><?php _e('Headline', 'tcd-w'); ?></h3>
    <textarea class="large-text" cols="50" rows="2" name="design1_content3_headline"><?php echo esc_textarea($design1_content3_headline); ?></textarea>
    <ul class="option_list">
     <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content3_headline_font_size" value="<?php echo esc_attr($design1_content3_headline_font_size); ?>" /><span>px</span></li>
     <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content3_headline_font_size_mobile" value="<?php echo esc_attr($design1_content3_headline_font_size_mobile); ?>" /><span>px</span></li>
    </ul>
    <?php // データ一覧 ---------- ?>
    <h3 class="theme_option_headline2"><?php _e( 'Data list', 'tcd-w' ); ?></h3>
    <div class="theme_option_message2">
     <p><?php _e('You can change order by dragging each item.', 'tcd-w'); ?></p>
    </div>
    <?php //繰り返しフィールド ----- ?>
    <div class="repeater-wrapper">
     <div class="repeater sortable" data-delete-confirm="<?php _e( 'Delete?', 'tcd-w' ); ?>">
      <?php
           if ( $design1_content3_data_list ) :
             foreach ( $design1_content3_data_list as $key => $value ) :
      ?>
      <div class="sub_box repeater-item repeater-item-<?php echo $key; ?>">
       <h4 class="theme_option_subbox_headline"><?php _e( 'New item', 'tcd-w' ); ?></h4>
       <div class="sub_box_content">
        <h4 class="theme_option_headline2"><?php _e( 'Headline', 'tcd-w' ); ?></h4>
        <p><input class="repeater-label" type="text" name="design1_content3_data_list[<?php echo esc_attr( $key ); ?>][title]" value="<?php echo esc_attr( isset( $design1_content3_data_list[$key]['title'] ) ? $design1_content3_data_list[$key]['title'] : '' ); ?>" style="width:100%" /></p>
        <h4 class="theme_option_headline2"><?php _e( 'Description', 'tcd-w' ); ?></h4>
        <textarea class="large-text" cols="50" rows="2" name="design1_content3_data_list[<?php echo esc_attr( $key ); ?>][desc]"><?php echo esc_textarea( isset( $design1_content3_data_list[$key]['desc'] ) ? $design1_content3_data_list[$key]['desc'] : '' ); ?></textarea>
        <p class="delete-row right-align"><a href="#" class="button button-secondary button-delete-row"><?php _e( 'Delete item', 'tcd-w' ); ?></a></p>
       </div><!-- END .sub_box_content -->
      </div><!-- END .sub_box -->
      <?php
             endforeach;
           endif;
           $key = 'addindex';
           ob_start();
      ?>
      <div class="sub_box repeater-item repeater-item-<?php echo $key; ?>">
       <h4 class="theme_option_subbox_headline"><?php echo esc_html( ! empty( $design1_content3_data_list[$key]['title'] ) ? $design1_content3_data_list[$key]['title'] : __( 'New item', 'tcd-w' ) ); ?></h4>
       <div class="sub_box_content">
        <h4 class="theme_option_headline2"><?php _e( 'Headline', 'tcd-w' );  ?></h4>
        <p><input class="repeater-label" type="text" name="design1_content3_data_list[<?php echo esc_attr( $key ); ?>][title]" value="" style="width:100%" /></p>
        <h4 class="theme_option_headline2"><?php _e( 'Description', 'tcd-w' );  ?></h4>
        <textarea class="large-text" cols="50" rows="2" name="design1_content3_data_list[<?php echo esc_attr( $key ); ?>][desc]"></textarea>
        <p class="delete-row right-align"><a href="#" class="button button-secondary button-delete-row"><?php _e( 'Delete item', 'tcd-w' ); ?></a></p>
       </div><!-- END .sub_box_content -->
      </div><!-- END .sub_box -->
      <?php
           $clone = ob_get_clean();
      ?>
     </div><!-- END .repeater -->
     <a href="#" class="button button-secondary button-add-row" data-clone="<?php echo esc_attr( $clone ); ?>"><?php _e( 'Add item', 'tcd-w' ); ?></a>
    </div><!-- END .repeater-wrapper -->
    <?php // 繰り返しフィールドここまで ----- ?>
    <ul class="button_list cf">
     <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
    </ul>
    <input type="hidden" name="page_content_order[]" value="content3" />
   </div><!-- END .theme_option_field_ac_content -->
  </div><!-- END .theme_option_field -->
 <?php endif; ?>


 <?php // コンテンツ４ ----------------------------------------------------- ?>
 <?php if ($page_content == 'content4') : ?>
  <div class="theme_option_field cf theme_option_field_ac">
   <h3 class="theme_option_headline"><?php printf(__('Content%s setting', 'tcd-w'), 4); ?></h3>
   <div class="theme_option_field_ac_content">
    <p><label for="show_design1_content4"><input id="show_design1_content4" type="checkbox" name="show_design1_content4" value="1" <?php checked( $show_design1_content4, 1 ); ?>><?php printf(__('Display content%s', 'tcd-w'), 4); ?></label></p>
    <h3 class="theme_option_headline2"><?php _e('Tab name', 'tcd-w'); ?></h3>
    <input style="width:100%;" type="text" name="design1_tab4_name" value="<?php echo esc_attr($design1_tab4_name); ?>" />
    <h3 class="theme_option_headline2"><?php _e('Headline', 'tcd-w'); ?></h3>
    <textarea class="large-text" cols="50" rows="2" name="design1_content4_headline"><?php echo esc_textarea($design1_content4_headline); ?></textarea>
    <ul class="option_list">
     <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content4_headline_font_size" value="<?php echo esc_attr($design1_content4_headline_font_size); ?>" /><span>px</span></li>
     <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="design1_content4_headline_font_size_mobile" value="<?php echo esc_attr($design1_content4_headline_font_size_mobile); ?>" /><span>px</span></li>
    </ul>
    <h3 class="theme_option_headline2"><?php _e('Address of location', 'tcd-w'); ?></h3>
    <div class="theme_option_message no_arrow">
     <p><?php _e( 'You need to register Google Map API key to <a href="../wp-admin/admin.php?page=theme_options" target="_blank">Theme option</a> to display google map.', 'tcd-w' ); ?></p>
    </div>
    <input type="text" name="access_address" value="<?php echo esc_attr($access_address); ?>" style="width:100%" />
    <h3 class="theme_option_headline2"><?php _e('Logo setting', 'tcd-w'); ?></h3>
    <?php mlcf_media_form('access_logo_image', sprintf(__('Image%s', 'tcd-w'), '1') ); ?>
    <p><label><input name="access_logo_retina" type="checkbox" value="1" <?php checked( '1', $access_logo_retina ); ?> /> <?php _e('Use retina display logo image', 'tcd-w');  ?></label></p>
    <h3 class="theme_option_headline2"><?php _e('Description (Under logo)', 'tcd-w'); ?></h3>
    <textarea class="large-text" cols="50" rows="2" name="access_desc1"><?php echo esc_textarea($access_desc1); ?></textarea>
    <h3 class="theme_option_headline2"><?php _e('Saturation of map', 'tcd-w'); ?></h3>
    <div class="theme_option_message2">
     <p><?php _e( 'Please set the saturation of the map. If you set it to -100 the output map is monochrome.', 'tcd-w' ); ?></p>
    </div>
    <p class="range-output"><?php _e( 'Current value: ', 'tcd-w' ); ?><span><?php echo esc_html( $access_saturation ); ?></span></p>
    <input class="range" type="range" name="access_saturation" value="<?php echo esc_attr($access_saturation); ?>" min="-100" max="100" step="10" />
    <h4 class="theme_option_headline2"><?php _e( 'Button setting', 'tcd-w' ); ?></h4>
    <p class="displayment_checkbox"><label><input name="show_access_button" type="checkbox" value="1" <?php checked( $show_access_button, 1 ); ?>><?php _e( 'Display button', 'tcd-w' ); ?></label></p>
    <div style="<?php if($show_access_button == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
     <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
      <li class="cf"><span class="label"><?php _e('label', 'tcd-w');  ?></span><input class="full_width" type="text" name="access_button_label" value="<?php echo esc_attr($access_button_label); ?>" /></li>
      <li class="cf"><span class="label"><?php _e('URL', 'tcd-w');  ?></span><input class="full_width" type="text" name="access_button_url" value="<?php echo esc_url($access_button_url); ?>" /></li>
      <li class="cf"><span class="label"><?php _e('Font color of button', 'tcd-w'); ?></span><input type="text" name="access_button_font_color" value="<?php echo esc_attr($access_button_font_color); ?>" data-default-color="#ffffff" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Background color of button', 'tcd-w'); ?></span><input type="text" name="access_button_bg_color" value="<?php echo esc_attr($access_button_bg_color); ?>" data-default-color="#000000" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Font color of button on mouseover', 'tcd-w'); ?></span><input type="text" name="access_button_font_color_hover" value="<?php echo esc_attr($access_button_font_color_hover); ?>" data-default-color="#ffffff" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Background color of button on mouseover', 'tcd-w'); ?></span><input type="text" name="access_button_bg_color_hover" value="<?php echo esc_attr($access_button_bg_color_hover); ?>" data-default-color="#333333" class="c-color-picker"></li>
     </ul>
    </div>
    <h3 class="theme_option_headline2"><?php _e('Description (Under button)', 'tcd-w'); ?></h3>
    <textarea class="large-text" cols="50" rows="2" name="access_desc2"><?php echo esc_textarea($access_desc2); ?></textarea>
    <ul class="button_list cf">
     <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
    </ul>
    <input type="hidden" name="page_content_order[]" value="content4" />
   </div><!-- END .theme_option_field_ac_content -->
  </div><!-- END .theme_option_field -->
 <?php endif; ?>

 <?php endforeach; // 並び替えここまで ?>
 </div><!-- END .theme_option_field_order -->

</div><!-- END .tcd_custom_field_wrap -->

<?php
}

function save_design1_meta_box( $post_id ) {

  // verify nonce
  if (!isset($_POST['design1_custom_fields_meta_box_nonce']) || !wp_verify_nonce($_POST['design1_custom_fields_meta_box_nonce'], basename(__FILE__))) {
    return $post_id;
  }

  // check autosave
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
    return $post_id;
  }

  // check permissions
  if ('page' == $_POST['post_type']) {
    if (!current_user_can('edit_page', $post_id)) {
      return $post_id;
    }
  } elseif (!current_user_can('edit_post', $post_id)) {
      return $post_id;
  }

  // save or delete
  $cf_keys = array(
    'design1_tab1_name','design1_tab2_name','design1_tab3_name','design1_tab4_name',
    'show_design1_content1',
    'design1_content1_catch','design1_content1_catch_font_size','design1_content1_catch_font_size_mobile','design1_content1_desc',
    'show_design1_content1_ic','design1_content1_ic_use_para',
    'design1_content1_ic_catch','design1_content1_ic_catch_font_size','design1_content1_ic_catch_font_size_mobile',
    'design1_content1_ic_title','design1_content1_ic_title_font_size','design1_content1_ic_title_font_size_mobile',
    'design1_content1_ic_sub_title','design1_content1_ic_sub_title_font_size','design1_content1_ic_sub_title_font_size_mobile',
    'design1_content1_ic_image','design1_content1_ic_font_color','design1_content1_ic_content_direction','design1_content1_ic_use_overlay','design1_content1_ic_overlay_color','design1_content1_ic_overlay_opacity',
    'show_design1_content2',
    'design1_content2_catch','design1_content2_catch_font_size','design1_content2_catch_font_size_mobile','design1_content2_desc','design1_content2_desc2','design1_content2_image',
    'show_design1_content2_ic','design1_content2_ic_use_para',
    'design1_content2_ic_catch','design1_content2_ic_catch_font_size','design1_content2_ic_catch_font_size_mobile',
    'design1_content2_ic_title','design1_content2_ic_title_font_size','design1_content2_ic_title_font_size_mobile',
    'design1_content2_ic_sub_title','design1_content2_ic_sub_title_font_size','design1_content2_ic_sub_title_font_size_mobile',
    'design1_content2_ic_image','design1_content2_ic_font_color','design1_content2_ic_content_direction','design1_content2_ic_use_overlay','design1_content2_ic_overlay_color','design1_content2_ic_overlay_opacity',
    'show_design1_content3',
    'design1_content3_headline','design1_content3_headline_font_size','design1_content3_headline_font_size_mobile',
    'show_design1_content4',
    'design1_content4_headline','design1_content4_headline_font_size','design1_content4_headline_font_size_mobile',
    'access_address','access_saturation','access_desc1','access_desc2','access_logo_image','access_logo_retina',
    'show_access_button','access_button_label','access_button_url','access_button_font_color','access_button_bg_color','access_button_font_color_hover','access_button_bg_color_hover',
  );
  foreach ($cf_keys as $cf_key) {
    $old = get_post_meta($post_id, $cf_key, true);

    if (isset($_POST[$cf_key])) {
      $new = $_POST[$cf_key];
    } else {
      $new = '';
    }

    if ($new && $new != $old) {
      update_post_meta($post_id, $cf_key, $new);
    } elseif ('' == $new && $old) {
      delete_post_meta($post_id, $cf_key, $old);
    }
  }

  // repeater save or delete
  $cf_keys = array( 'design1_content2_data_list','design1_content3_data_list', 'page_content_order' );
  foreach ( $cf_keys as $cf_key ) {
    $old = get_post_meta( $post_id, $cf_key, true );

    if ( isset( $_POST[$cf_key] ) && is_array( $_POST[$cf_key] ) ) {
      $new = array_values( $_POST[$cf_key] );
    } else {
      $new = false;
    }

    if ( $new && $new != $old ) {
      update_post_meta( $post_id, $cf_key, $new );
    } elseif ( ! $new && $old ) {
      delete_post_meta( $post_id, $cf_key, $old );
    }
  }

}
add_action('save_post', 'save_design1_meta_box');




?>
