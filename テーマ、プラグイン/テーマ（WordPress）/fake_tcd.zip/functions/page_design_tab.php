<?php

function design_tab_meta_box() {
  add_meta_box(
    'design_tab_meta_box',//ID of meta box
    __('Designed page tab setting', 'tcd-w'),//label
    'show_design_tab_meta_box',//callback function
    'page',// post type
    'normal',// context
    'high'// priority
  );
}
add_action('add_meta_boxes', 'design_tab_meta_box');

function show_design_tab_meta_box() {
  global $post, $font_type_options, $content_direction_options;


  // tab setting -------------------------------------------------------
  $tab_font_color = get_post_meta($post->ID, 'tab_font_color', true);
  if(empty($tab_font_color)){
    $tab_font_color = '#000000';
  };
  $tab_bg_color = get_post_meta($post->ID, 'tab_bg_color', true);
  if(empty($tab_bg_color)){
    $tab_bg_color = '#ffffff';
  };
  $tab_font_color_hover = get_post_meta($post->ID, 'tab_font_color_hover', true);
  if(empty($tab_font_color_hover)){
    $tab_font_color_hover = '#ffffff';
  };
  $tab_bg_color_hover = get_post_meta($post->ID, 'tab_bg_color_hover', true);
  if(empty($tab_bg_color_hover)){
    $tab_bg_color_hover = '#333333';
  };
  $tab_bg_color_active = get_post_meta($post->ID, 'tab_bg_color_active', true);
  if(empty($tab_bg_color_active)){
    $tab_bg_color_active = '#000000';
  };
  $tab_bg_opacity = get_post_meta($post->ID, 'tab_bg_opacity', true);
  if(empty($tab_bg_opacity)){
    $tab_bg_opacity = '0.7';
  };
  $tab_bg_blur = get_post_meta($post->ID, 'tab_bg_blur', true);
  if(empty($tab_bg_blur)){
    $tab_bg_blur = '3';
  };
  $tab_font_size = get_post_meta($post->ID, 'tab_font_size', true);
  if(empty($tab_font_size)){
    $tab_font_size = '14';
  }
  $tab_font_size_mobile = get_post_meta($post->ID, 'tab_font_size_mobile', true);
  if(empty($tab_font_size_mobile)){
    $tab_font_size_mobile = '12';
  }
  $show_tab = get_post_meta($post->ID, 'show_tab', true);
  if(empty($show_tab)){
    $show_tab = 1;
  }

  echo '<input type="hidden" name="design_tab_custom_fields_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';

  //入力欄 ***************************************************************************************************************************************************************************************
?>

<div class="tcd_custom_field_wrap">

  <?php // タブの設定 ----------------------------------------------------- ?>
  <div class="theme_option_field cf theme_option_field_ac">
   <h3 class="theme_option_headline"><?php _e('Tab button setting', 'tcd-w'); ?></h3>
   <div class="theme_option_field_ac_content">
    <p class="displayment_checkbox"><label><input name="show_tab" type="checkbox" value="1" <?php checked( $show_tab, 1 ); ?>><?php _e( 'Display tab button', 'tcd-w' ); ?></label></p>
    <div style="<?php if($show_tab == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
     <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
      <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="tab_font_size" value="<?php esc_attr_e( $tab_font_size ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="tab_font_size_mobile" value="<?php esc_attr_e( $tab_font_size_mobile ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="tab_font_color" value="<?php echo esc_attr( $tab_font_color ); ?>" data-default-color="#000000" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="tab_bg_color" value="<?php echo esc_attr( $tab_bg_color ); ?>" data-default-color="#ffffff" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="tab_font_color_hover" value="<?php echo esc_attr( $tab_font_color_hover ); ?>" data-default-color="#ffffff" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Background color on mouseover', 'tcd-w'); ?></span><input type="text" name="tab_bg_color_hover" value="<?php echo esc_attr( $tab_bg_color_hover ); ?>" data-default-color="#333333" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Active background', 'tcd-w'); ?></span><input type="text" name="tab_bg_color_active" value="<?php echo esc_attr( $tab_bg_color_active ); ?>" data-default-color="#000000" class="c-color-picker"></li>
      <li class="cf">
       <span class="label"><?php _e('Transparency of background', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="tab_bg_opacity" value="<?php echo esc_attr( $tab_bg_opacity ); ?>" />
       <div class="theme_option_message2" style="clear:both; margin:7px 0 0 0;">
        <p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p>
       </div>
      </li>
      <li class="cf">
       <span class="label"><?php _e('Strenth of background blur effect', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="10" min="0" step="1" name="tab_bg_blur" value="<?php echo esc_attr( $tab_bg_blur ); ?>" />
       <div class="theme_option_message2" style="clear:both; margin:7px 0 0 0;">
        <p><?php _e('Please specify the number of 1 from 10. Blur effect will be stronger as the number is large.', 'tcd-w');  ?></p>
       </div>
      </li>
     </ul>
    </div>
    <ul class="button_list cf">
     <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
    </ul>
   </div><!-- END .theme_option_field_ac_content -->
  </div><!-- END .theme_option_field -->

</div><!-- END .tcd_custom_field_wrap -->

<?php
}

function save_design_tab_meta_box( $post_id ) {

  // verify nonce
  if (!isset($_POST['design_tab_custom_fields_meta_box_nonce']) || !wp_verify_nonce($_POST['design_tab_custom_fields_meta_box_nonce'], basename(__FILE__))) {
    return $post_id;
  }

  // check autosave
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
    return $post_id;
  }

  // check permissions
  if ('page' == $_POST['post_type']) {
    if (!current_user_can('edit_page', $post_id)) {
      return $post_id;
    }
  } elseif (!current_user_can('edit_post', $post_id)) {
      return $post_id;
  }

  // save or delete
  $cf_keys = array(
    'show_tab','tab_font_color','tab_bg_color','tab_font_color_hover','tab_bg_color_hover','tab_bg_color_active','tab_bg_opacity','tab_bg_blur','tab_font_size','tab_font_size_mobile',
  );
  foreach ($cf_keys as $cf_key) {
    $old = get_post_meta($post_id, $cf_key, true);

    if (isset($_POST[$cf_key])) {
      $new = $_POST[$cf_key];
    } else {
      $new = '';
    }

    if ($new && $new != $old) {
      update_post_meta($post_id, $cf_key, $new);
    } elseif ('' == $new && $old) {
      delete_post_meta($post_id, $cf_key, $old);
    }
  }

  // repeater save or delete
  $cf_keys = array( 'design_tab_content2_data_list','design_tab_content3_data_list' );
  foreach ( $cf_keys as $cf_key ) {
    $old = get_post_meta( $post_id, $cf_key, true );

    if ( isset( $_POST[$cf_key] ) && is_array( $_POST[$cf_key] ) ) {
      $new = array_values( $_POST[$cf_key] );
    } else {
      $new = false;
    }

    if ( $new && $new != $old ) {
      update_post_meta( $post_id, $cf_key, $new );
    } elseif ( ! $new && $old ) {
      delete_post_meta( $post_id, $cf_key, $old );
    }
  }

}
add_action('save_post', 'save_design_tab_meta_box');




?>
