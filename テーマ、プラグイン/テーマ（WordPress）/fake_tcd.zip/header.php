<?php $options = get_design_plus_option(); ?>
<!DOCTYPE html>
<html class="pc" <?php language_attributes(); ?>>
<?php if($options['use_ogp']) { ?>
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#">
<?php } else { ?>
<head>
<?php }; ?>
<meta charset="<?php bloginfo('charset'); ?>">
<!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge"><![endif]-->
<meta name="viewport" content="width=device-width">
<meta name="format-detection" content="telephone=no">
<title><?php wp_title('|', true, 'right'); ?></title>

<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
<?php
     if ( $options['favicon'] ) {
       $favicon_image = wp_get_attachment_image_src( $options['favicon'], 'full');
       if(!empty($favicon_image)) {
?>
<link rel="shortcut icon" href="<?php echo esc_url($favicon_image[0]); ?>">
<?php }; }; ?>
<?php wp_enqueue_style('style', get_stylesheet_uri(), false, version_num(), 'all'); wp_enqueue_script( 'jquery' ); if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
<meta name="google-site-verification" content="w5RJePjdMkti17NRlNwReB7Pp4UZoC_yWeqCTKv8_ek" />
</head>
<body id="body" <?php body_class(); ?>>

<?php
     if ($options['show_load_screen'] == 'type2') {
       if(is_front_page()){
         load_icon();
       }
     } elseif ($options['show_load_screen'] == 'type3') {
       if(is_front_page() || is_home() || is_post_type_archive('work') ){
         load_icon();
       }
     };
?>

<div id="container">

 <header id="header" class="animate_pc">

  <div id="header_logo">
   <?php header_logo(); ?>
   <?php
        if ($options['header_logo_show_desc'] == 'type2') {
          if(is_front_page()){
   ?>
   <h3 class="desc"><?php echo esc_html(get_bloginfo('description')); ?></h3>
   <?php
          };
        } elseif ($options['header_logo_show_desc'] == 'type3') {
   ?>
   <h3 class="desc"><?php echo esc_html(get_bloginfo('description')); ?></h3>
   <?php }; ?>
  </div>

  <?php if (has_nav_menu('global-menu')) { ?>
  <a href="#" id="menu_button"><span><?php _e('menu', 'tcd-w'); ?></span></a>
  <?php }; ?>

  <?php if (has_nav_menu('global-menu')) { ?>
  <nav id="global_menu">
   <?php wp_nav_menu( array( 'sort_column' => 'menu_order', 'theme_location' => 'global-menu' , 'container' => '' ) ); ?>
  </nav>
  <?php }; ?>

  <?php get_template_part( 'template-parts/megamenu' ); ?>

 </header>

 <?php if(is_front_page()) { ?>
 <div id="index_header_content" class="height_<?php echo esc_attr($options['index_header_content_height']); ?>">
  <?php
       // Image slider ***********************************************************************************************************************
       if($options['index_header_content_type'] == 'type1') {
         $index_slider_mobile_content_type = $options['index_slider_mobile_content_type'];
  ?>
  <div id="index_slider_wrap"<?php if($index_slider_mobile_content_type != 'type1') { echo ' class="use_mobile_caption"'; }; ?>>
   <div id="index_slider" class="animation_<?php echo esc_attr($options['index_slider_animation_type']); ?>">
    <?php
         // mobile caption
         if($index_slider_mobile_content_type != 'type1') {
           $mobile_logo_image_id = $options['index_slider_mobile_logo_image'];
           if(!empty($mobile_logo_image_id)) {
             $mobile_logo_image = wp_get_attachment_image_src($mobile_logo_image_id, 'full');
           }
           $mobile_logo_width = $options['index_slider_mobile_logo_image_width'];
           $mobile_catch = $options['index_slider_mobile_catch'];
    ?>
    <div class="caption mobile">
     <div class="caption_inner">
      <div class="logo_desc_area animate_mobile">
       <?php if( ($index_slider_mobile_content_type == 'type2') && $mobile_logo_image_id ) { ?>
       <h2 class="logo"><img src="<?php echo esc_attr($mobile_logo_image[0]); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" title="<?php echo esc_attr(get_bloginfo('name')); ?>" <?php if($mobile_logo_width) { ?>style="width:<?php echo esc_attr($mobile_logo_width); ?>px; height:auto;"<?php }; ?> /></h2>
       <?php } elseif( ($index_slider_mobile_content_type == 'type3') && $mobile_catch ) { ?>
       <h2 class="catch rich_font_<?php echo esc_attr($options['index_slider_mobile_catch_font_type']); ?>"><span><?php echo nl2br(esc_html($mobile_catch)); ?></span></h2>
       <?php }; ?>
      </div>
     </div>
    </div>
    <?php }; ?>
    <?php
         // item loop start
         for($i=1; $i<= 3; $i++):
           $image_id = $options['index_slider_image'.$i];
           if(!empty($image_id)) {
             // image
             $image = wp_get_attachment_image_src($image_id, 'full');
             $image_url = $image[0];
    ?>
    <div class="item item<?php echo $i; if($i == 1){ echo ' first_item'; }; ?>">
     <?php
          // caption
          $num = 1;
          $content_type = $options['index_slider_content_type'.$i];
          $content_type_bottom = $options['index_slider_bottom_content_type'.$i];
          $logo_image_id = $options['index_slider_logo_image'.$i];
          if(!empty($logo_image_id)) {
            $logo_image = wp_get_attachment_image_src($logo_image_id, 'full');
          }
          $logo_width = $options['index_slider_logo_image_width'.$i];
          $catch = $options['index_slider_catch'.$i];
          $desc = $options['index_slider_desc'.$i];
          $font_type = $options['index_slider_catch_font_type'.$i];
          $url = $options['index_slider_url'.$i];
          $target = $options['index_slider_target'.$i];
          $button_label = $options['index_slider_button_label'.$i];
          if($catch || $logo_image_id){
     ?>
     <div class="caption direction_<?php echo esc_attr($options['index_slider_content_direction'.$i]); ?> <?php if($index_slider_mobile_content_type != 'type1') { echo 'pc'; }; ?>">
      <div class="caption_inner">
       <div class="logo_desc_area <?php if($i == 1) { echo 'animate_pc'; if($index_slider_mobile_content_type == 'type1'){ echo ' animate_mobile'; }; }; ?> item<?php echo $num; $num++; ?>">
        <?php if( ($content_type == 'type2') && $logo_image_id ) { ?>
        <h2 class="logo"><img src="<?php echo esc_attr($logo_image[0]); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" title="<?php echo esc_attr(get_bloginfo('name')); ?>" <?php if($logo_width) { ?>style="width:<?php echo esc_attr($logo_width); ?>px; height:auto;"<?php }; ?> /></h2>
        <?php } elseif( ($content_type == 'type3') && $catch ) { ?>
        <h2 class="catch rich_font_<?php echo esc_attr($font_type); ?>"><span><?php echo nl2br(esc_html($catch)); ?></span></h2>
        <?php }; ?>
        <?php if($desc) { ?>
        <p class="desc"><span><?php echo nl2br(esc_html($desc)); ?></span></p>
        <?php }; ?>
       </div>
       <?php if( ($content_type_bottom == 'type2') && $url ) { ?>
       <a class="button <?php if($i == 1) { echo 'animate_pc'; if($index_slider_mobile_content_type == 'type1'){ echo ' animate_mobile'; }; }; ?> item<?php echo $num; $num++; ?>" href="<?php echo esc_url($url); ?>"<?php if($target == 1) { echo ' target="_blank"'; }; ?>><span><?php echo esc_html($button_label); ?></span></a>
       <?php } elseif($content_type_bottom == 'type3') { ?>
       <div class="search_area <?php if($i == 1) { echo 'animate_pc'; if($index_slider_mobile_content_type == 'type1'){ echo ' animate_mobile'; }; }; ?> item<?php echo $num; $num++; ?>">
        <form method="get" action="<?php echo esc_url(home_url('/')); ?>">
         <div class="search_input"><input type="text" value="" name="s" placeholder="<?php echo esc_html($options['index_slider_search_label'.$i]); ?>" /></div>
         <div class="search_button"><label for="index_search_button<?php echo $i; ?>"><?php _e('Search','tcd-w'); ?></label><input id="index_search_button<?php echo $i; ?>" type="submit" value="<?php _e('Search','tcd-w'); ?>" /></div>
        </form>
       </div>
       <?php }; ?>
      </div>
     </div><!-- END .caption -->
     <?php
          };
          // overlay
          if($options['index_slider_use_overlay'.$i] || $options['index_slider_use_overlay_mobile'.$i]) {
     ?>
     <div class="overlay"></div>
     <?php
          };
          // image
          $image_mobile_id = $options['index_slider_image_mobile'.$i];
     ?>
     <div class="slice_image_list clearfix <?php if(!empty($image_mobile_id)) { echo 'pc'; }; ?>">
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url); ?>);"></div></div></div>
     </div>
     <?php
          // image mobile
          if(!empty($image_mobile_id)) {
             $image_mobile = wp_get_attachment_image_src($image_mobile_id, 'full');
             $image_url_mobile = $image_mobile[0];
     ?>
     <div class="slice_image_list clearfix mobile">
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url_mobile); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url_mobile); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url_mobile); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url_mobile); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url_mobile); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url_mobile); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url_mobile); ?>);"></div></div></div>
      <div class="slice_image"><div class="image_wrap"><div class="image" style="background-image:url(<?php echo esc_attr($image_url_mobile); ?>);"></div></div></div>
     </div>
     <?php }; ?>
    </div><!-- END .item -->
    <?php
           };// END if image
         endfor; // END item loop
    ?>
   </div><!-- END #index_slider -->
  </div><!-- END #index_slider_wrap -->
  <?php
       // MP4 video, YouTube ***********************************************************************************************************************
       } elseif($options['index_header_content_type'] == 'type2' || $options['index_header_content_type'] == 'type3') {
  ?>
  <div id="index_slider_wrap">
   <div id="index_slider">
    <?php
         $index_movie_mobile_content_type = $options['index_movie_mobile_content_type'];
         for($i=1; $i<= 2; $i++):
           if( ($i == 2) && ($index_movie_mobile_content_type == 'type1') ) {
             break;
           }
           if($i == 1) {
             $device = '';
           } else {
             $device = '_mobile';
           }
           // caption
           $content_type = $options['index_movie_content_type'.$device];
           $content_type_bottom = $options['index_movie_bottom_content_type'.$device];
           $logo_image_id = $options['index_movie_logo_image'.$device];
           if(!empty($logo_image_id)) {
             $logo_image = wp_get_attachment_image_src($logo_image_id, 'full');
           }
           $logo_width = $options['index_movie_logo_image_width'.$device];
           $catch = $options['index_movie_catch'.$device];
           $desc = $options['index_movie_desc'.$device];
           $font_type = $options['index_movie_catch_font_type'.$device];
           $url = $options['index_movie_url'.$device];
           $target = $options['index_movie_target'.$device];
           $button_label = $options['index_movie_button_label'.$device];
           $search_label = $options['index_movie_search_label'.$device];
           if($logo_image_id || $catch || $desc){
    ?>
    <div class="caption <?php if($index_movie_mobile_content_type == 'type2') { if($i == 1){ echo 'pc'; } else { echo 'mobile'; }; }; ?>">
     <div class="caption_inner">
      <div class="logo_desc_area <?php if($i == 1){ echo 'animate_pc'; if($index_movie_mobile_content_type == 'type1') { echo ' animate_mobile'; }; } else { echo ' animate_mobile'; }; ?>">
		  <?php if($desc) { ?>
       <p class="desc"><span><?php echo nl2br(esc_html($desc)); ?></span></p>
       <?php }; ?>
       <?php if( ($content_type == 'type2') && $logo_image_id ) { ?>
       <h2 class="logo"><img src="<?php echo esc_attr($logo_image[0]); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" title="<?php echo esc_attr(get_bloginfo('name')); ?>" <?php if($logo_width) { ?>style="width:<?php echo esc_attr($logo_width); ?>px; height:auto;"<?php }; ?> /></h2>
       <?php } elseif( ($content_type == 'type3') && $catch ) { ?>
       <h2 class="catch rich_font_<?php echo esc_attr($font_type); ?>"><span><?php echo nl2br(esc_html($catch)); ?></span></h2>
       <?php }; ?>
       
      </div>
      <?php if( ($content_type_bottom == 'type2') && $url ) { ?>
      <a class="button <?php if($i == 1){ echo 'animate_pc'; if($index_movie_mobile_content_type == 'type1') { echo ' animate_mobile'; }; } else { echo ' animate_mobile'; }; ?>" href="<?php echo esc_url($url); ?>"<?php if($target == 1) { echo ' target="_blank"'; }; ?>><span><?php echo esc_html($button_label); ?></span></a>
      <?php } elseif($content_type_bottom == 'type3') { ?>
      <div class="search_area <?php if($i == 1){ echo 'animate_pc'; if($index_movie_mobile_content_type == 'type1') { echo ' animate_mobile'; }; } else { echo ' animate_mobile'; }; ?>">
       <form method="get" action="<?php echo esc_url(home_url('/')); ?>">
        <div class="search_input"><input type="text" value="" name="s" placeholder="<?php echo esc_html($search_label); ?>" /></div>
        <div class="search_button"><label for="index_search_button"><?php _e('Search','tcd-w'); ?></label><input id="index_search_button" type="submit" value="<?php _e('Search','tcd-w'); ?>" /></div>
       </form>
      </div>
      <?php }; ?>
     </div>
    </div><!-- END .caption -->
    <?php
           };
         endfor;
         // overlay
         if($options['index_movie_use_overlay'.$device] || $options['index_movie_use_overlay_mobile'.$device]) {
    ?>
    <div class="overlay"></div>
    <?php
         };
         // video ---------------------------------------------------------
         if($options['index_header_content_type'] == 'type2') {
           $video = $options['index_video'];
           if(!empty($video)) {
             $video_image_id = $options['index_movie_image'];
             if($video_image_id) {
               $video_image = wp_get_attachment_image_src($video_image_id, 'full');
             }
    ?>
    <div id="index_video">
     <?php if (auto_play_movie()) { ?>
     <video src="<?php echo esc_url(wp_get_attachment_url($options['index_video'])); ?>" id="index_video_mp4" playsinline autoplay loop muted></video>
     <?php
          } else {
            if($video_image_id) {
     ?>
     <div id="video_poster" style="background:url(<?php echo esc_attr($video_image[0]); ?>) no-repeat center center; background-size:cover;"></div>
     <?php }; }; ?>
    </div>
    <?php
           };
           // YouTube ---------------------------------------------------------
         } elseif($options['index_header_content_type'] == 'type3') {
           $youtube_url = $options['index_youtube_url'];
           if(!empty($youtube_url)) {
             $video_image_id = $options['index_movie_image'];
             if($video_image_id) {
               $video_image = wp_get_attachment_image_src($video_image_id, 'full');
             } 
             if(auto_play_movie()){
    ?>
    <div id="youtube_video_player" class="player" data-property="{videoURL:'<?php echo esc_url($youtube_url); ?>', <?php if($video_image_id) { ?>mobileFallbackImage: '<?php echo esc_attr($video_image[0]); ?>',<?php }; ?> containment:'#index_slider', optimizeDisplay:true, startAt:0, mute:true, autoPlay:true, loop:true, opacity:1, showControls:false}"></div>
    <?php
         } else {
         if($video_image_id) {
    ?>
    <div id="video_poster" style="background:url(<?php echo esc_attr($video_image[0]); ?>) no-repeat center center; background-size:cover;"></div>
    <?php }; }; ?>
    <?php
           };
         };
    ?>
   </div><!-- END #index_slider -->
  </div><!-- END #index_slider_wrap -->
  <?php }; // END header content type ?>

  <?php
       // News --------------------------------------------------------------------
       if( $options['show_index_news']) {
         $post_num = $options['index_news_num'];
         $news_query = new WP_Query('post_type=post&posts_per_page='.$post_num);
         if ($news_query->have_posts()) :
  ?>
  <div id="index_news">
   <?php while($news_query->have_posts()): $news_query->the_post(); ?>
   <article class="item">
    <a href="<?php the_permalink() ?>">
     <p class="date"><time class="entry-date updated" datetime="<?php the_modified_time('c'); ?>"><?php the_time('Y.m.j'); ?></time></p>
     <h4 class="title"><span><?php the_title_attribute(); ?></span></h4>
    </a>
   </article>
   <?php endwhile;  ?>
  </div><!-- END #index_news -->
  <?php endif; wp_reset_query(); }; ?>

 </div><!-- END #index_header_content -->
 <?php }; // END if is front page ?>


