<?php
/*
 * トップページの設定
 */


// Add default values
add_filter( 'before_getting_design_plus_option', 'add_front_page_dp_default_options' );


// Add label of front page tab
add_action( 'tcd_tab_labels', 'add_front_page_tab_label' );


// Add HTML of front page tab
add_action( 'tcd_tab_panel', 'add_front_page_tab_panel' );


// Register sanitize function
add_filter( 'theme_options_validate', 'add_front_page_theme_options_validate' );


// タブの名前
function add_front_page_tab_label( $tab_labels ) {
	$tab_labels['front_page'] = __( 'Front page', 'tcd-w' );
	return $tab_labels;
}


// 初期値
function add_front_page_dp_default_options( $dp_default_options ) {

  // ヘッダーコンテンツ
	$dp_default_options['index_header_content_type'] = 'type1';
	$dp_default_options['index_header_content_height'] = 'type1';

  // 画像スライダー
	$dp_default_options['index_slider_time'] = '7000';
	$dp_default_options['index_slider_animation_type'] = 'type1';
	for ( $i = 1; $i <= 3; $i++ ) {
		$dp_default_options['index_slider_image' . $i] = false;
		$dp_default_options['index_slider_image_mobile' . $i] = false;

		$dp_default_options['index_slider_content_type' . $i] = 'type3';
		$dp_default_options['index_slider_bottom_content_type' . $i] = 'type1';

		$dp_default_options['index_slider_catch' . $i] = __( 'Catchprase will be displayed here.', 'tcd-w' );
		$dp_default_options['index_slider_catch_font_type' . $i] = 'type3';
		$dp_default_options['index_slider_catch_font_size' . $i] = '32';
		$dp_default_options['index_slider_catch_font_size_mobile' . $i] = '20';
		$dp_default_options['index_slider_catch_color' . $i] = '#FFFFFF';

		$dp_default_options['index_slider_logo_image' . $i] = false;
		$dp_default_options['index_slider_logo_image_width' . $i] = '';

		$dp_default_options['index_slider_search_label' . $i] = __( 'Enter search keyword', 'tcd-w' );
		$dp_default_options['index_slider_search_opacity' . $i] = '0.9';

		$dp_default_options['index_slider_desc' . $i] = __( 'Description will be displayed here.<br />Description will be displayed here.', 'tcd-w' );
		$dp_default_options['index_slider_desc_font_size' . $i] = '16';
		$dp_default_options['index_slider_desc_font_size_mobile' . $i] = '13';
		$dp_default_options['index_slider_desc_color' . $i] = '#FFFFFF';

		$dp_default_options['index_slider_use_shadow' . $i] = 0;
		$dp_default_options['index_slider_shadow_h'.$i] = 0;
		$dp_default_options['index_slider_shadow_v'.$i] = 0;
		$dp_default_options['index_slider_shadow_b'.$i] = 0;
		$dp_default_options['index_slider_shadow_c'.$i] = '#888888';

		$dp_default_options['index_slider_content_direction' . $i] = 'type2';

		$dp_default_options['index_slider_button_label' . $i] = 'MORE DETAIL';
		$dp_default_options['index_slider_button_bg_color' . $i] = '#000000';
		$dp_default_options['index_slider_button_font_color' . $i] = '#FFFFFF';
		$dp_default_options['index_slider_button_bg_color_hover' . $i] = '#999999';
		$dp_default_options['index_slider_button_font_color_hover' . $i] = '#FFFFFF';
		$dp_default_options['index_slider_url' . $i] = '#';
		$dp_default_options['index_slider_target' . $i] = 1;

		$dp_default_options['index_slider_use_overlay' . $i] = 1;
		$dp_default_options['index_slider_overlay_color' . $i] = '#000000';
		$dp_default_options['index_slider_overlay_opacity' . $i] = '0.3';
		$dp_default_options['index_slider_use_overlay_mobile' . $i] = '';
		$dp_default_options['index_slider_overlay_color_mobile' . $i] = '#000000';
		$dp_default_options['index_slider_overlay_opacity_mobile' . $i] = '0.3';
	}

  //画像スライダースマホ用設定
	$dp_default_options['index_slider_mobile_content_type'] = 'type1';
	$dp_default_options['index_slider_mobile_logo_image'] = '';
	$dp_default_options['index_slider_mobile_logo_image_width'] = '';

	$dp_default_options['index_slider_mobile_catch'] = '';
	$dp_default_options['index_slider_mobile_catch_font_type'] = 'type2';
	$dp_default_options['index_slider_mobile_catch_font_size'] = '28';
	$dp_default_options['index_slider_mobile_catch_color'] = '#FFFFFF';
	$dp_default_options['index_slider_mobile_use_shadow'] = 0;
	$dp_default_options['index_slider_mobile_shadow_h'] = 0;
	$dp_default_options['index_slider_mobile_shadow_v'] = 0;
	$dp_default_options['index_slider_mobile_shadow_b'] = 0;
	$dp_default_options['index_slider_mobile_shadow_c'] = '#888888';

  // 動画
	$dp_default_options['index_video'] = false;

  // Youtube
	$dp_default_options['index_youtube_url'] = '';

	// 代替画像
	$dp_default_options['index_movie_image'] = false;

  // 動画用コンテンツ
	$dp_default_options['index_movie_content_type'] = 'type3';
	$dp_default_options['index_movie_bottom_content_type'] = 'type1';

	$dp_default_options['index_movie_catch'] = __( 'Catchprase will be displayed here.', 'tcd-w' );
	$dp_default_options['index_movie_catch_font_type'] = 'type3';
	$dp_default_options['index_movie_catch_font_size'] = '32';
	$dp_default_options['index_movie_catch_font_size_mobile'] = '20';
	$dp_default_options['index_movie_catch_color'] = '#FFFFFF';

	$dp_default_options['index_movie_logo_image'] = false;
	$dp_default_options['index_movie_logo_image_width'] = '';

	$dp_default_options['index_movie_search_label'] = __( 'Enter search keyword', 'tcd-w' );
	$dp_default_options['index_movie_search_opacity'] = '0.9';

	$dp_default_options['index_movie_desc'] = __( 'Description will be displayed here.<br />Description will be displayed here.', 'tcd-w' );
	$dp_default_options['index_movie_desc_font_size'] = '16';
	$dp_default_options['index_movie_desc_font_size_mobile'] = '13';
	$dp_default_options['index_movie_desc_color'] = '#FFFFFF';

	$dp_default_options['index_movie_use_shadow'] = 0;
	$dp_default_options['index_movie_shadow_h'] = 0;
	$dp_default_options['index_movie_shadow_v'] = 0;
	$dp_default_options['index_movie_shadow_b'] = 0;
	$dp_default_options['index_movie_shadow_c'] = '#888888';

	$dp_default_options['index_movie_button_label'] = 'MORE DETAIL';
	$dp_default_options['index_movie_button_bg_color'] = '#000000';
	$dp_default_options['index_movie_button_font_color'] = '#FFFFFF';
	$dp_default_options['index_movie_button_bg_color_hover'] = '#999999';
	$dp_default_options['index_movie_button_font_color_hover'] = '#FFFFFF';
	$dp_default_options['index_movie_url'] = '#';
	$dp_default_options['index_movie_target'] = 1;

	$dp_default_options['index_movie_use_overlay'] = 1;
	$dp_default_options['index_movie_overlay_color'] = '#000000';
	$dp_default_options['index_movie_overlay_opacity'] = '0.3';

  // 動画用コンテンツ（スマホ用）
	$dp_default_options['index_movie_mobile_content_type'] = 'type1';

	$dp_default_options['index_movie_content_type_mobile'] = 'type3';
	$dp_default_options['index_movie_bottom_content_type_mobile'] = 'type1';

	$dp_default_options['index_movie_catch_mobile'] = __( 'Catchprase will be displayed here.', 'tcd-w' );
	$dp_default_options['index_movie_catch_font_type_mobile'] = 'type3';
	$dp_default_options['index_movie_mobile_catch_font_size'] = '20';
	$dp_default_options['index_movie_catch_color_mobile'] = '#FFFFFF';

	$dp_default_options['index_movie_logo_image_mobile'] = false;
	$dp_default_options['index_movie_logo_image_width_mobile'] = '';

	$dp_default_options['index_movie_search_label_mobile'] = __( 'Enter search keyword', 'tcd-w' );
	$dp_default_options['index_movie_search_opacity_mobile'] = '0.9';

	$dp_default_options['index_movie_desc_mobile'] = __( 'Description will be displayed here.<br />Description will be displayed here.', 'tcd-w' );
	$dp_default_options['index_movie_mobile_desc_font_size'] = '13';
	$dp_default_options['index_movie_desc_color_mobile'] = '#FFFFFF';

	$dp_default_options['index_movie_use_shadow_mobile'] = 0;
	$dp_default_options['index_movie_shadow_h_mobile'] = 0;
	$dp_default_options['index_movie_shadow_v_mobile'] = 0;
	$dp_default_options['index_movie_shadow_b_mobile'] = 0;
	$dp_default_options['index_movie_shadow_c_mobile'] = '#888888';

	$dp_default_options['index_movie_button_label_mobile'] = 'MORE DETAIL';
	$dp_default_options['index_movie_button_bg_color_mobile'] = '#000000';
	$dp_default_options['index_movie_button_font_color_mobile'] = '#FFFFFF';
	$dp_default_options['index_movie_button_bg_color_hover_mobile'] = '#999999';
	$dp_default_options['index_movie_button_font_color_hover_mobile'] = '#FFFFFF';
	$dp_default_options['index_movie_url_mobile'] = '#';
	$dp_default_options['index_movie_target_mobile'] = 1;

	$dp_default_options['index_movie_use_overlay_mobile'] = 1;
	$dp_default_options['index_movie_overlay_color_mobile'] = '#000000';
	$dp_default_options['index_movie_overlay_opacity_mobile'] = '0.3';

  // ニュースティッカー
	$dp_default_options['show_index_news'] = 1;
	$dp_default_options['index_news_num'] = 5;
	$dp_default_options['index_news_font_color'] = '#FFFFFF';
	$dp_default_options['index_news_font_color_hover'] = '#FFFFFF';
	$dp_default_options['index_news_bg_color'] = '#000000';
	$dp_default_options['index_news_bg_opacity'] = '0.5';
	$dp_default_options['index_news_time'] = '5000';


  // オーバーレイ
	$dp_default_options['use_header_overlay'] = 1;
	$dp_default_options['header_overlay_color'] = '#000000';
	$dp_default_options['header_overlay_opacity'] = '0.3';
	$dp_default_options['use_header_overlay_gd'] = 1;

  // コンテンツビルダー
	$dp_default_options['contents_builder'] = array(
		array(
			"cb_content_select" => "content1",
			"content1_catch" => __( 'Catchprase will be displayed here.', 'tcd-w' ),
			"content1_desc1" => __( 'Description will be displayed here.<br />Description will be displayed here.', 'tcd-w' ),
			"content1_image1" => false,
			"content1_image2" => false,
			"content1_image3" => false,
			"content1_desc2" => __( 'Description will be displayed here.<br />Description will be displayed here.', 'tcd-w' ),
			"content1_show_button" => 1,
			"content1_button_label" => __( 'BUTTON', 'tcd-w' ),
			"content1_button_url" => "#",
			"content1_button_font_color" => "#ffffff",
			"content1_button_bg_color" => "#000000",
			"content1_button_font_color_hover" => "#ffffff",
			"content1_button_bg_color_hover" => "#666666",
			"content1_catch_font_size" => "30",
			"content1_desc_font_size" => "16",
			"content1_catch_font_size_mobile" => "20",
			"content1_desc_font_size_mobile" => "13",
		),
		array(
			"cb_content_select" => "para_content",
			"para_content_catch" => __( 'Catchprase will be displayed here.', 'tcd-w' ),
			"para_content_desc" => __( 'Description will be displayed here.<br />Description will be displayed here.', 'tcd-w' ),
			"para_content_image" => false,
			"para_content_use_overlay" => 1,
			"para_content_overlay_color" => "#000000",
			"para_content_overlay_opacity" => "0.3",
			"para_content_catch_font_size" => "30",
			"para_content_desc_font_size" => "16",
			"para_content_catch_font_size_mobile" => "20",
			"para_content_desc_font_size_mobile" => "13",
			"para_content_direction" => "type2",
		),
		array(
			"cb_content_select" => "post_list",
			"post_list_num" => "9",
			"post_list_show_button" => 1,
			"post_list_button_label" => __( 'BUTTON', 'tcd-w' ),
			"post_list_button_font_color" => "#ffffff",
			"post_list_button_bg_color" => "#000000",
			"post_list_button_font_color_hover" => "#ffffff",
			"post_list_button_bg_color_hover" => "#666666",
		),
		array(
			"cb_content_select" => "carousel",
			"carousel_catch1" => __( 'Catchprase will be displayed here.', 'tcd-w' ),
			"carousel_title1" => __( 'Title will be displayed here', 'tcd-w' ),
			"carousel_sub_title1" => __( 'Subtitle', 'tcd-w' ),
			"carousel_url1" => "#",
			"carousel_image1" => false,
			"carousel_use_overlay1" => 1,
			"carousel_overlay_color1" => "#000000",
			"carousel_overlay_opacity1" => "0.3",
			"carousel_catch2" => __( 'Catchprase will be displayed here.', 'tcd-w' ),
			"carousel_title2" => __( 'Title will be displayed here', 'tcd-w' ),
			"carousel_sub_title2" => __( 'Subtitle', 'tcd-w' ),
			"carousel_url2" => "#",
			"carousel_image2" => false,
			"carousel_use_overlay2" => 1,
			"carousel_overlay_color2" => "#000000",
			"carousel_overlay_opacity2" => "0.3",
			"carousel_catch3" => __( 'Catchprase will be displayed here.', 'tcd-w' ),
			"carousel_title3" => __( 'Title will be displayed here', 'tcd-w' ),
			"carousel_sub_title3" => __( 'Subtitle', 'tcd-w' ),
			"carousel_url3" => "#",
			"carousel_image3" => false,
			"carousel_use_overlay3" => 1,
			"carousel_overlay_color3" => "#000000",
			"carousel_overlay_opacity3" => "0.3",
			"carousel_catch4" => '',
			"carousel_title4" => '',
			"carousel_sub_title4" => '',
			"carousel_url4" => '',
			"carousel_image4" => false,
			"carousel_use_overlay4" => 0,
			"carousel_overlay_color4" => "#000000",
			"carousel_overlay_opacity4" => "0.3",
			"carousel_catch5" => '',
			"carousel_title5" => '',
			"carousel_sub_title5" => '',
			"carousel_url5" => '',
			"carousel_image5" => false,
			"carousel_use_overlay5" => 0,
			"carousel_overlay_color5" => "#000000",
			"carousel_overlay_opacity5" => "0.3",
			"carousel_catch6" => '',
			"carousel_title6" => '',
			"carousel_sub_title6" => '',
			"carousel_url6" => '',
			"carousel_image6" => false,
			"carousel_use_overlay6" => 0,
			"carousel_overlay_color6" => "#000000",
			"carousel_overlay_opacity6" => "0.3",
			"carousel_catch_font_size" => "20",
			"carousel_title_font_size" => "20",
			"carousel_sub_title_font_size" => "14",
			"carousel_catch_font_size_mobile" => "16",
			"carousel_title_font_size_mobile" => "16",
			"carousel_sub_title_font_size_mobile" => "11",
			"carousel_catch_color" => "#FFFFFF",
		),
		array(
			"cb_content_select" => "content2",
			"content2_catch" => __( 'Catchprase will be displayed here.', 'tcd-w' ),
			"content2_desc1" => __( 'Description will be displayed here.<br />Description will be displayed here.', 'tcd-w' ),
			"content2_image" => false,
			"content2_use_overlay" => 1,
			"content2_overlay_color" => "#000000",
			"content2_overlay_opacity" => "0.3",
			"content2_catch2" => __( 'Catchprase will be displayed here.', 'tcd-w' ),
			"content2_catch2_color" => "#ffffff",
			"content2_show_button1" => 1,
			"content2_button1_label" => __( 'BUTTON', 'tcd-w' ),
			"content2_button1_url" => "#",
			"content2_button1_font_color" => "#ffffff",
			"content2_button1_bg_color" => "#000000",
			"content2_button1_font_color_hover" => "#ffffff",
			"content2_button1_bg_color_hover" => "#333333",
			"content2_desc2" => __( 'Description will be displayed here.<br />Description will be displayed here.', 'tcd-w' ),
			"content2_show_button2" => 1,
			"content2_button2_label" => __( 'BUTTON', 'tcd-w' ),
			"content2_button2_url" => "#",
			"content2_button2_font_color" => "#ffffff",
			"content2_button2_bg_color" => "#000000",
			"content2_button2_font_color_hover" => "#ffffff",
			"content2_button2_bg_color_hover" => "#333333",
			"content2_catch_font_size" => "30",
			"content2_desc_font_size" => "16",
			"content2_catch2_font_size" => "30",
			"content2_catch_font_size_mobile" => "20",
			"content2_desc_font_size_mobile" => "13",
			"content2_catch2_font_size_mobile" => "20",
		)
	);

	return $dp_default_options;

}

// 入力欄の出力　■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
function add_front_page_tab_panel( $options ) {

  global $dp_default_options, $index_content_type_options, $time_options, $font_type_options, $content_direction_options, $index_slider_content_type_options, $index_slider_content_type_options2, $index_slider_content_type_options3, $index_slider_animation_type_options, $header_content_height_options, $index_movie_mobile_content_type_options;
  $work_label = $options['work_label'] ? esc_html( $options['work_label'] ) : __( 'Achievement', 'tcd-w' );

?>

<div id="tab-content-logo" class="tab-content">

   <?php // ヘッダーコンテンツの設定 ---------- ?>
   <div class="theme_option_field cf theme_option_field_ac">
    <h3 class="theme_option_headline"><?php _e('Header content setting', 'tcd-w');  ?></h3>
    <div class="theme_option_field_ac_content">

     <?php // コンテンツのタイプ ---------- ?>
     <h4 class="theme_option_headline2"><?php _e('Background type', 'tcd-w');  ?></h4>
     <ul class="design_radio_button">
      <?php foreach ( $index_content_type_options as $option ) { ?>
      <li>
       <input type="radio" id="index_header_content_button_<?php esc_attr_e( $option['value'] ); ?>" name="dp_options[index_header_content_type]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_header_content_type'], $option['value'] ); ?> />
       <label for="index_header_content_button_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
      </li>
      <?php } ?>
     </ul>

     <?php // 画像スライダー ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■ ?>
     <div id="index_content_slider" style="<?php if($options['index_header_content_type'] == 'type1') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
      <h4 class="theme_option_headline2"><?php _e('Image slider setting', 'tcd-w');  ?></h4>

      <?php // 繰り返し PCの設定----- ?>
      <?php for($i = 1; $i <= 3; $i++) : ?>
      <div class="sub_box cf"> 
       <h3 class="theme_option_subbox_headline"><?php printf(__('Slide%s setting', 'tcd-w'), $i); ?></h3>
       <div class="sub_box_content">
        <?php // 画像の設定 ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Image', 'tcd-w' ); ?></h4>
        <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '1450', '1000'); ?></p>
        <div class="image_box cf index_slider_image<?php echo $i; ?>">
         <div class="cf cf_media_field hide-if-no-js index_slider_image<?php echo $i; ?>">
          <input type="hidden" value="<?php echo esc_attr( $options['index_slider_image'.$i] ); ?>" id="index_slider_image<?php echo $i; ?>" name="dp_options[index_slider_image<?php echo $i; ?>]" class="cf_media_id">
          <div class="preview_field"><?php if($options['index_slider_image'.$i]){ echo wp_get_attachment_image($options['index_slider_image'.$i], 'full'); }; ?></div>
          <div class="buttton_area">
           <input type="button" value="<?php _e('Select Image', 'tcd-w'); ?>" class="cfmf-select-img button">
           <input type="button" value="<?php _e('Remove Image', 'tcd-w'); ?>" class="cfmf-delete-img button <?php if(!$options['index_slider_image'.$i]){ echo 'hidden'; }; ?>">
          </div>
         </div>
        </div>
        <?php // コンテンツのタイプ（上部） ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Content display at top', 'tcd-w' ); ?></h4>
        <ul class="design_radio_button">
         <?php foreach ( $index_slider_content_type_options2 as $option ) { ?>
         <li class="index_slider_content_<?php esc_attr_e( $option['value'] ); ?>_button">
          <input type="radio" id="index_slider_content_type<?php echo $i; ?>_<?php esc_attr_e( $option['value'] ); ?>" name="dp_options[index_slider_content_type<?php echo $i; ?>]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_slider_content_type'.$i], $option['value'] ); ?> />
          <label for="index_slider_content_type<?php echo $i; ?>_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
         </li>
         <?php }; ?>
        </ul>
        <?php //ロゴの設定 -------------------------- ?>
        <div class="index_slider_logo_area" style="<?php if($options['index_slider_content_type'.$i] == 'type2') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e( 'Logo setting', 'tcd-w' ); ?></h4>
         <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '145', '18'); ?></p>
         <div class="image_box cf index_slider_logo_image<?php echo $i; ?>">
          <div class="cf cf_media_field hide-if-no-js">
           <input type="hidden" value="<?php echo esc_attr( $options['index_slider_logo_image'.$i] ); ?>" id="index_slider_logo_image<?php echo $i; ?>" name="dp_options[index_slider_logo_image<?php echo $i; ?>]" class="cf_media_id">
           <div class="preview_field"><?php if ( $options['index_slider_logo_image'.$i] ) { echo wp_get_attachment_image( $options['index_slider_logo_image'.$i], 'full' ); } ?></div>
           <div class="button_area">
            <input type="button" value="<?php _e( 'Select Image', 'tcd-w' ); ?>" class="cfmf-select-img button">
            <input type="button" value="<?php _e( 'Remove Image', 'tcd-w' ); ?>" class="cfmf-delete-img button <?php if ( ! $options['index_slider_logo_image'.$i] ) { echo 'hidden'; } ?>">
           </div>
          </div>
         </div>
         <div class="slider_logo_preview-wrapper" style="display:none;">
          <h6 class="theme_option_headline2"><?php _e( 'Logo preview', 'tcd-w' ); ?></h6>
          <div class="theme_option_message2">
           <p><?php _e( 'You can change the logo size by moving the mouse cursor over the logo and dragging the arrow. Double-click on the logo to return to the original size.', 'tcd-w' ); ?></p>
          </div>
          <input type="hidden" value="<?php echo esc_attr( $options['index_slider_logo_image_width'.$i] ); ?>" name="dp_options[index_slider_logo_image_width<?php echo $i; ?>]" id="index_slider_logo_image_width<?php echo $i; ?>">
          <div class="slider_logo_preview slider_logo_preview-pc" data-logo-width-input="#index_slider_logo_image_width<?php echo $i; ?>" data-logo-img=".index_slider_logo_image<?php echo $i; ?> img" data-bg-img=".index_slider_image<?php echo $i; ?> img" data-display-overlay=".index_slider_use_overlay<?php echo $i; ?>" data-overlay-color=".index_slider_overlay_color<?php echo $i; ?>" data-overlay-opacity=".index_slider_overlay_opacity<?php echo $i; ?>"></div>
         </div>
        </div><!-- END .index_slider_logo_area -->
        <?php // キャッチフレーズ ----------------------- ?>
        <div class="index_slider_catch_area" style="<?php if($options['index_slider_content_type'.$i] == 'type3') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e( 'Catchphrase setting', 'tcd-w' ); ?></h4>
         <textarea class="large-text" cols="50" rows="3" name="dp_options[index_slider_catch<?php echo $i; ?>]"><?php echo esc_textarea(  $options['index_slider_catch'.$i] ); ?></textarea>
         <ul class="option_list">
          <li class="cf"><span class="label"><?php _e('Font type', 'tcd-w');  ?></span>
           <select name="dp_options[index_slider_catch_font_type<?php echo $i; ?>]">
            <?php foreach ( $font_type_options as $option ) { ?>
            <option style="padding-right: 10px;" value="<?php echo esc_attr($option['value']); ?>" <?php selected( $options['index_slider_catch_font_type'.$i], $option['value'] ); ?>><?php echo $option['label']; ?></option>
            <?php } ?>
           </select>
          </li>
          <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_slider_catch_font_size<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_catch_font_size'.$i] ); ?>" /><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_slider_catch_font_size_mobile<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_catch_font_size_mobile'.$i] ); ?>" /><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_slider_catch_color<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_catch_color'.$i] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
         </ul>
        </div><!-- END .index_slider_catch_area -->
        <?php // 説明文 ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e('Description', 'tcd-w');  ?></h4>
        <textarea class="large-text" cols="50" rows="3" name="dp_options[index_slider_desc<?php echo $i; ?>]"><?php echo esc_textarea(  $options['index_slider_desc'.$i] ); ?></textarea>
        <ul class="option_list">
         <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_slider_desc_font_size<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_desc_font_size'.$i] ); ?>" /><span>px</span></li>
         <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_slider_desc_font_size_mobile<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_desc_font_size_mobile'.$i] ); ?>" /><span>px</span></li>
         <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_slider_desc_color<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_desc_color'.$i] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
        </ul>
        <?php // テキストシャドウ ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Dropshadow setting', 'tcd-w' ); ?></h4>
        <p class="displayment_checkbox"><label><input name="dp_options[index_slider_use_shadow<?php echo $i; ?>]" type="checkbox" value="1" <?php checked( $options['index_slider_use_shadow'.$i], 1 ); ?>><?php _e( 'Use dropshadow on text content', 'tcd-w' ); ?></label></p>
        <div style="<?php if($options['index_slider_use_shadow'.$i] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
          <li class="cf"><span class="label"><?php _e('Dropshadow position (left)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_slider_shadow_h<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_shadow_h'.$i] ); ?>"><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Dropshadow position (top)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_slider_shadow_v<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_shadow_v'.$i] ); ?>"><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Dropshadow size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_slider_shadow_b<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_shadow_b'.$i] ); ?>"><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Dropshadow color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_slider_shadow_c<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_shadow_c'.$i] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
         </ul>
        </div>
        <?php // コンテンツのタイプ（下部） ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Content display at bottom', 'tcd-w' ); ?></h4>
        <ul class="design_radio_button">
         <?php foreach ( $index_slider_content_type_options3 as $option ) { ?>
         <li class="index_slider_bottom_content_<?php esc_attr_e( $option['value'] ); ?>_button">
          <input type="radio" id="index_slider_bottom_content_type<?php echo $i; ?>_<?php esc_attr_e( $option['value'] ); ?>" name="dp_options[index_slider_bottom_content_type<?php echo $i; ?>]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_slider_bottom_content_type'.$i], $option['value'] ); ?> />
          <label for="index_slider_bottom_content_type<?php echo $i; ?>_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
         </li>
         <?php }; ?>
        </ul>
        <?php // ボタン ----------------------- ?>
        <div class="index_slider_button_area" style="<?php if($options['index_slider_bottom_content_type'.$i] == 'type2') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e('Button setting', 'tcd-w');  ?></h4>
         <ul class="option_list">
          <li class="cf"><span class="label"><?php _e('label', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[index_slider_button_label<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_button_label'.$i] ); ?>" /></li>
          <li class="cf"><span class="label"><?php _e('URL', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[index_slider_url<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_url'.$i] ); ?>"></li>
          <li class="cf"><span class="label"><?php _e('Open link in new window', 'tcd-w'); ?></span><input name="dp_options[index_slider_target<?php echo $i; ?>]" type="checkbox" value="1" <?php checked( $options['index_slider_target'.$i], 1 ); ?>></li>
          <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_slider_button_bg_color<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_button_bg_color'.$i] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
          <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_slider_button_font_color<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_button_font_color'.$i] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
          <li class="cf"><span class="label"><?php _e('Background color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[index_slider_button_bg_color_hover<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_button_bg_color_hover'.$i] ); ?>" data-default-color="#999999" class="c-color-picker"></li>
          <li class="cf"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[index_slider_button_font_color_hover<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_button_font_color_hover'.$i] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
         </ul>
        </div>
        <?php //検索フォームの設定 -------------------------- ?>
        <div class="index_slider_search_area" style="<?php if($options['index_slider_bottom_content_type'.$i] == 'type3') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e('Search form setting', 'tcd-w');  ?></h4>
         <ul class="option_list">
          <li class="cf"><span class="label"><?php _e('Placeholder', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[index_slider_search_label<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_search_label'.$i] ); ?>" /></li>
          <li class="cf"><span class="label"><?php _e('Transparency of background', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[index_slider_search_opacity<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_search_opacity'.$i] ); ?>" /><p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p></li>
         </ul>
        </div><!-- END .index_slider_search_area -->
        <?php // オーバーレイ ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Overlay setting', 'tcd-w' ); ?></h4>
        <p class="displayment_checkbox"><label><input class="index_slider_use_overlay<?php echo $i; ?>" name="dp_options[index_slider_use_overlay<?php echo $i; ?>]" type="checkbox" value="1" <?php checked( $options['index_slider_use_overlay'.$i], 1 ); ?>><?php _e( 'Use overlay', 'tcd-w' ); ?></label></p>
        <div style="<?php if($options['index_slider_use_overlay'.$i] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
          <li class="cf"><span class="label"><?php _e('Color of overlay', 'tcd-w'); ?></span><input class="c-color-picker index_slider_overlay_color<?php echo $i; ?>" type="text" name="dp_options[index_slider_overlay_color<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_overlay_color'.$i] ); ?>" data-default-color="#000000"></li>
          <li class="cf"><span class="label"><?php _e('Transparency of overlay', 'tcd-w'); ?></span><input class="hankaku index_slider_overlay_opacity<?php echo $i; ?>" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[index_slider_overlay_opacity<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_overlay_opacity'.$i] ); ?>" /><p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p></li>
         </ul>
        </div>
        <?php // コンテンツの方向 ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e('Direction of content', 'tcd-w');  ?></h4>
        <ul class="design_radio_button">
         <?php foreach ( $content_direction_options as $option ) { ?>
         <li>
          <input type="radio" id="index_slider_content_direction<?php echo $i . '_' . esc_attr($option['value']); ?>" name="dp_options[index_slider_content_direction<?php echo $i; ?>]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_slider_content_direction'.$i], $option['value'] ); ?> />
          <label for="index_slider_content_direction<?php echo $i . '_' . esc_attr($option['value']); ?>"><?php echo $option['label']; ?></label>
         </li>
         <?php } ?>
        </ul>
        <ul class="button_list cf">
         <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
         <li><a class="close_sub_box button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
        </ul>
       </div><!-- END .sub_box_content -->
      </div><!-- END .sub_box -->
      <?php endfor; ?>
      <?php // 繰り返し PCの設定　ここまで ----- ?>

      <?php // モバイルサイズ専用設定 ---------------------------------------------------------------------------------------------------------------- ?>
      <div class="sub_box cf">
       <h3 class="theme_option_subbox_headline"><?php _e('Mobile size setting', 'tcd-w'); ?></h3>
       <div class="sub_box_content">
        <div class="theme_option_message2" style="margin-top:15px;">
         <p><?php _e( 'This content will be replaced by content above when the web browser become mobile size.', 'tcd-w' ); ?></p>
        </div>
        <?php //コンテンツの設定 -------------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Content type setting', 'tcd-w' ); ?></h4>
        <div class="theme_option_message2">
         <p><?php _e('If you select Catchphrase or Logo type, catchphrase above will not be displayed.', 'tcd-w'); ?></p>
        </div>
        <ul class="design_radio_button">
         <?php foreach ( $index_slider_content_type_options as $option ) { ?>
         <li class="index_slider_mobile_content_<?php esc_attr_e( $option['value'] ); ?>_button">
          <input type="radio" id="index_slider_mobile_content_type_<?php esc_attr_e( $option['value'] ); ?>" name="dp_options[index_slider_mobile_content_type]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_slider_mobile_content_type'], $option['value'] ); ?> />
          <label for="index_slider_mobile_content_type_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
         </li>
         <?php } ?>
        </ul>
        <?php //ロゴの設定 -------------------------- ?>
        <div class="index_slider_logo_area_mobile" style="<?php if($options['index_slider_mobile_content_type'] == 'type2') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e( 'Logo setting', 'tcd-w' ); ?></h4>
         <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '145', '18'); ?></p>
         <div class="image_box cf index_slider_mobile_logo_image">
          <div class="cf cf_media_field hide-if-no-js">
           <input type="hidden" value="<?php echo esc_attr( $options['index_slider_mobile_logo_image'] ); ?>" id="index_slider_mobile_logo_image" name="dp_options[index_slider_mobile_logo_image]" class="cf_media_id">
           <div class="preview_field"><?php if ( $options['index_slider_mobile_logo_image'] ) { echo wp_get_attachment_image( $options['index_slider_mobile_logo_image'], 'full' ); } ?></div>
           <div class="button_area">
            <input type="button" value="<?php _e( 'Select Image', 'tcd-w' ); ?>" class="cfmf-select-img button">
            <input type="button" value="<?php _e( 'Remove Image', 'tcd-w' ); ?>" class="cfmf-delete-img button <?php if ( ! $options['index_slider_mobile_logo_image'] ) { echo 'hidden'; } ?>">
           </div>
          </div>
         </div>
         <div class="slider_logo_preview-wrapper" style="display: none;">
          <h6 class="theme_option_headline2"><?php _e( 'Logo preview', 'tcd-w' ); ?></h6>
          <div class="theme_option_message2">
           <p><?php _e( 'You can change the logo size by moving the mouse cursor over the logo and dragging the arrow. Double-click on the logo to return to the original size.', 'tcd-w' ); ?></p>
          </div>
          <input type="hidden" value="<?php echo esc_attr( $options['index_slider_mobile_logo_image_width'] ); ?>" name="dp_options[index_slider_mobile_logo_image_width]" id="index_slider_mobile_logo_image_width">
          <div class="slider_logo_preview slider_logo_preview-mobile index_slider_mobile_logo_image_preview index_slider_mobile_logo_image_preview-mobile" data-logo-width-input="#index_slider_mobile_logo_image_width" data-logo-img=".index_slider_mobile_logo_image img" data-bg-img=".index_slider_image_mobile1 img, .index_slider_image1 img" data-display-overlay=".index_slider_use_overlay_mobile1, .index_slider_use_overlay1" data-overlay-color=".index_slider_overlay_color_mobile1, .index_slider_overlay_color1" data-overlay-opacity=".index_slider_overlay_opacity_mobile1, .index_slider_overlay_opacity1"></div>
         </div>
        </div><!-- END .index_slider_logo_area_mobile -->
        <?php // スマホ専用キャッチフレーズ ------------------------ ?>
        <div class="index_slider_catch_area_mobile" style="<?php if($options['index_slider_mobile_content_type'] == 'type3') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e( 'Catchphrase setting', 'tcd-w' ); ?></h4>
         <textarea class="large-text" cols="50" rows="3" name="dp_options[index_slider_mobile_catch]"><?php echo esc_textarea(  $options['index_slider_mobile_catch'] ); ?></textarea>
         <ul class="option_list">
          <li class="cf"><span class="label"><?php _e('Font type', 'tcd-w');  ?></span>
           <select name="dp_options[index_slider_mobile_catch_font_type]">
            <?php foreach ( $font_type_options as $option ) { ?>
            <option style="padding-right: 10px;" value="<?php echo esc_attr($option['value']); ?>" <?php selected( $options['index_slider_mobile_catch_font_type'], $option['value'] ); ?>><?php echo $option['label']; ?></option>
            <?php } ?>
           </select>
          </li>
          <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_slider_mobile_catch_font_size]" value="<?php echo esc_attr( $options['index_slider_mobile_catch_font_size'] ); ?>" /><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_slider_mobile_catch_color]" value="<?php echo esc_attr( $options['index_slider_mobile_catch_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
         </ul>
         <?php // テキストシャドウ ----------------------- ?>
         <h4 class="theme_option_headline2"><?php _e( 'Dropshadow setting', 'tcd-w' ); ?></h4>
         <p class="displayment_checkbox"><label><input name="dp_options[index_slider_mobile_use_shadow]" type="checkbox" value="1" <?php checked( $options['index_slider_mobile_use_shadow'], 1 ); ?>><?php _e( 'Use dropshadow on text content', 'tcd-w' ); ?></label></p>
         <div style="<?php if($options['index_slider_mobile_use_shadow'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
          <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
           <li class="cf"><span class="label"><?php _e('Dropshadow position (left)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_slider_mobile_shadow_h]" value="<?php echo esc_attr( $options['index_slider_mobile_shadow_h'] ); ?>"><span>px</span></li>
           <li class="cf"><span class="label"><?php _e('Dropshadow position (top)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_slider_mobile_shadow_v]" value="<?php echo esc_attr( $options['index_slider_mobile_shadow_v'] ); ?>"><span>px</span></li>
           <li class="cf"><span class="label"><?php _e('Dropshadow size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_slider_mobile_shadow_b]" value="<?php echo esc_attr( $options['index_slider_mobile_shadow_b'] ); ?>"><span>px</span></li>
           <li class="cf"><span class="label"><?php _e('Dropshadow color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_slider_mobile_shadow_c]" value="<?php echo esc_attr( $options['index_slider_mobile_shadow_c'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
          </ul>
         </div>
        </div><!-- END .index_slider_catch_area_mobile -->
        <?php // 繰り返し 画像の設定 ----------------------------- ?>
        <?php for($i = 1; $i <= 3; $i++) : ?>
        <div class="sub_box cf"<?php if($i == 1){ echo ' style="margin-top:25px;"'; }; ?>>
         <h3 class="theme_option_subbox_headline"><?php printf(__('Slide%s setting (mobile size)', 'tcd-w'), $i); ?></h3>
         <div class="sub_box_content">
          <div class="theme_option_message2" style="margin-top:10px;">
           <p><?php _e( 'You can set images for mobile size. If it is not specified, PC image will be displayed instead.', 'tcd-w' ); ?></p>
          </div>
          <h4 class="theme_option_headline2"><?php _e( 'Image', 'tcd-w' ); ?></h4>
          <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '750', '1334'); ?></p>
          <div class="image_box cf">
           <div class="cf cf_media_field hide-if-no-js index_slider_image_mobile<?php echo $i; ?>">
            <input type="hidden" value="<?php echo esc_attr( $options['index_slider_image_mobile'.$i] ); ?>" id="index_slider_image_mobile<?php echo $i; ?>" name="dp_options[index_slider_image_mobile<?php echo $i; ?>]" class="cf_media_id">
            <div class="preview_field"><?php if($options['index_slider_image_mobile'.$i]){ echo wp_get_attachment_image($options['index_slider_image_mobile'.$i], 'full'); }; ?></div>
            <div class="buttton_area">
             <input type="button" value="<?php _e('Select Image', 'tcd-w'); ?>" class="cfmf-select-img button">
             <input type="button" value="<?php _e('Remove Image', 'tcd-w'); ?>" class="cfmf-delete-img button <?php if(!$options['index_slider_image_mobile'.$i]){ echo 'hidden'; }; ?>">
            </div>
           </div>
          </div>
          <?php // オーバーレイ ----------------------- ?>
          <h4 class="theme_option_headline2"><?php _e( 'Overlay setting', 'tcd-w' ); ?></h4>
          <p class="displayment_checkbox"><label><input class="index_slider_use_overlay_mobile<?php echo $i; ?>" name="dp_options[index_slider_use_overlay_mobile<?php echo $i; ?>]" type="checkbox" value="1" <?php checked( $options['index_slider_use_overlay_mobile'.$i], 1 ); ?>><?php _e( 'Use overlay', 'tcd-w' ); ?></label></p>
          <div class="index_slider_show_overlay_mobile" style="<?php if($options['index_slider_use_overlay_mobile'.$i] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
           <ul class="color_field" style="border-top:1px dotted #ccc; padding-top:12px;">
            <li class="cf"><span class="label"><?php _e('Color of overlay', 'tcd-w'); ?></span><input class="c-color-picker index_slider_overlay_color_mobile<?php echo $i; ?>" type="text" name="dp_options[index_slider_overlay_color_mobile<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_overlay_color_mobile'.$i] ); ?>" data-default-color="#000000"></li>
            <li class="cf"><span class="label"><?php _e('Transparency of overlay', 'tcd-w'); ?></span><input class="hankaku index_slider_overlay_opacity_mobile<?php echo $i; ?>" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[index_slider_overlay_opacity_mobile<?php echo $i; ?>]" value="<?php echo esc_attr( $options['index_slider_overlay_opacity_mobile'.$i] ); ?>" /><p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p></li>
           </ul>
          </div><!-- END .index_slider_show_overlay_mobile -->
          <ul class="button_list cf">
           <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
           <li><a class="close_sub_box button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
          </ul>
         </div><!-- END .sub_box_content -->
        </div><!-- END .sub_box -->
        <?php endfor; ?>
        <?php // 繰り返し ここまで ----- ?>
        <ul class="button_list cf">
         <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
         <li><a class="close_sub_box button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
        </ul>
       </div><!-- END .sub_box_content -->
      </div><!-- END .sub_box -->
      <?php // モバイルサイズ用設定ここまで --------------- ?>

      <?php // スピードの設定 ---------- ?>
      <h4 class="theme_option_headline2"><?php _e('Slider speed setting', 'tcd-w');  ?></h4>
      <select name="dp_options[index_slider_time]">
       <?php
            $i = 1;
            foreach ( $time_options as $option ):
              if( $i >= 5 && $i <= 10 ){
       ?>
       <option style="padding-right: 10px;" value="<?php echo esc_attr( $option['value'] ); ?>" <?php selected( $options['index_slider_time'], $option['value'] ); ?>><?php echo esc_html($option['label']); ?></option>
       <?php
              }
              $i++;
           endforeach;
       ?>
      </select>

      <?php // アニメーションのタイプ ---------- ?>
      <h4 class="theme_option_headline2"><?php _e('Animation type', 'tcd-w');  ?></h4>
      <ul class="design_radio_button">
       <?php foreach ( $index_slider_animation_type_options as $option ) { ?>
       <li>
        <input type="radio" id="index_slider_animation_type_<?php esc_attr_e( $option['value'] ); ?>" name="dp_options[index_slider_animation_type]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_slider_animation_type'], $option['value'] ); ?> />
        <label for="index_slider_animation_type_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
       </li>
       <?php } ?>
      </ul>

     </div><!-- END #header_content_slider スライダーの設定はここまで-->

     <?php // 動画 ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■ ?>
     <div id="index_content_video" style="<?php if($options['index_header_content_type'] == 'type2') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
      <h4 class="theme_option_headline2"><?php _e('Video setting', 'tcd-w');  ?></h4>
      <div class="theme_option_message2">
       <p><?php _e('Please upload MP4 format file.', 'tcd-w');  ?></p>
       <p><?php _e('Web browser takes few second to load the data of video so we recommend to use loading screen if you want to display video.', 'tcd-w'); ?></p>
      </div>
      <div class="image_box cf">
       <div class="cf cf_media_field hide-if-no-js index_video">
        <input type="hidden" value="<?php echo esc_attr( $options['index_video'] ); ?>" id="index_video" name="dp_options[index_video]" class="cf_media_id">
        <div class="preview_field preview_field_video">
         <?php if($options['index_video']){ ?>
         <h4><?php _e( 'Uploaded MP4 file', 'tcd-w' ); ?></h4>
         <p><?php echo esc_url(wp_get_attachment_url($options['index_video'])); ?></p>
         <?php }; ?>
        </div>
        <div class="buttton_area">
         <input type="button" value="<?php _e('Select MP4 file', 'tcd-w'); ?>" class="cfmf-select-video button">
         <input type="button" value="<?php _e('Remove MP4 file', 'tcd-w'); ?>" class="cfmf-delete-video button <?php if(!$options['index_video']){ echo 'hidden'; }; ?>">
        </div>
       </div>
      </div>
     </div><!-- END #header_content_video 動画の設定はここまで -->

     <?php // YouTube ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■ ?>
     <div id="index_content_youtube" style="<?php if($options['index_header_content_type'] == 'type3') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
      <h4 class="theme_option_headline2"><?php _e('Youtube setting', 'tcd-w');  ?></h4>
      <div class="theme_option_message2">
       <p><?php _e('Please enter Youtube URL.', 'tcd-w');  ?></p>
       <p><?php _e('Web browser takes few second to load the data of video so we recommend to use loading screen if you want to display video.', 'tcd-w'); ?></p>
      </div>
      <input id="dp_options[index_youtube_url]" class="regular-text" type="text" name="dp_options[index_youtube_url]" value="<?php esc_attr_e( $options['index_youtube_url'] ); ?>" />
     </div><!-- END #header_content_youtube YouTubeの設定はここまで -->

     <?php // 代替画像、動画用キャッチフレーズ ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■ ?>
     <div id="index_movie_content" style="<?php if($options['index_header_content_type'] != 'type1') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
      <?php // 代替画像 ----------- ?>
      <h4 class="theme_option_headline2"><?php _e('Substitute image', 'tcd-w');  ?></h4>
      <div class="theme_option_message2">
       <p><?php _e('If the mobile device can\'t play video this image will be displayed instead.', 'tcd-w');  ?></p>
      </div>
      <div class="image_box cf">
       <div class="cf cf_media_field hide-if-no-js index_movie_image">
        <input type="hidden" value="<?php echo esc_attr( $options['index_movie_image'] ); ?>" id="index_movie_image" name="dp_options[index_movie_image]" class="cf_media_id">
        <div class="preview_field"><?php if($options['index_movie_image']){ echo wp_get_attachment_image($options['index_movie_image'], 'full'); }; ?></div>
        <div class="buttton_area">
         <input type="button" value="<?php _e('Select Image', 'tcd-w'); ?>" class="cfmf-select-img button">
         <input type="button" value="<?php _e('Remove Image', 'tcd-w'); ?>" class="cfmf-delete-img button <?php if(!$options['index_movie_image']){ echo 'hidden'; }; ?>">
        </div>
       </div>
      </div>
      <h4 class="theme_option_headline2"><?php _e('Contents setting', 'tcd-w');  ?></h4>
      <?php // PC用キャッチフレーズ ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■ ?>
      <div class="sub_box cf">
       <h3 class="theme_option_subbox_headline"><?php _e('Default content', 'tcd-w'); ?></h3>
       <div class="sub_box_content">
        <?php // コンテンツのタイプ（上部） ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Content display at top', 'tcd-w' ); ?></h4>
        <ul class="design_radio_button">
         <?php foreach ( $index_slider_content_type_options2 as $option ) { ?>
         <li class="index_movie_content_<?php esc_attr_e( $option['value'] ); ?>_button">
          <input type="radio" id="index_movie_content_<?php esc_attr_e( $option['value'] ); ?>" name="dp_options[index_movie_content_type]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_movie_content_type'], $option['value'] ); ?> />
          <label for="index_movie_content_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
         </li>
         <?php } ?>
        </ul>
        <?php //ロゴの設定 -------------------------- ?>
        <div class="index_movie_logo_area" style="<?php if($options['index_movie_content_type'] == 'type2') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e( 'Logo setting', 'tcd-w' ); ?></h4>
         <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '145', '18'); ?></p>
         <div class="image_box cf index_movie_logo_image">
          <div class="cf cf_media_field hide-if-no-js">
           <input type="hidden" value="<?php echo esc_attr( $options['index_movie_logo_image'] ); ?>" id="index_movie_logo_image" name="dp_options[index_movie_logo_image]" class="cf_media_id">
           <div class="preview_field"><?php if ( $options['index_movie_logo_image'] ) { echo wp_get_attachment_image( $options['index_movie_logo_image'], 'full' ); } ?></div>
           <div class="button_area">
            <input type="button" value="<?php _e( 'Select Image', 'tcd-w' ); ?>" class="cfmf-select-img button">
            <input type="button" value="<?php _e( 'Remove Image', 'tcd-w' ); ?>" class="cfmf-delete-img button <?php if ( ! $options['index_movie_logo_image'] ) { echo 'hidden'; } ?>">
           </div>
          </div>
         </div>
         <div class="index_default_movie_image" style="display:none;">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/admin/img/top_image.jpg">
         </div>
         <div class="slider_logo_preview-wrapper" style="display:none;">
          <h6 class="theme_option_headline2"><?php _e( 'Logo preview', 'tcd-w' ); ?></h6>
          <div class="theme_option_message2">
           <p><?php _e( 'You can change the logo size by moving the mouse cursor over the logo and dragging the arrow. Double-click on the logo to return to the original size.', 'tcd-w' ); ?></p>
          </div>
          <input type="hidden" value="<?php echo esc_attr( $options['index_movie_logo_image_width'] ); ?>" name="dp_options[index_movie_logo_image_width]" id="index_movie_logo_image_width">
          <div class="slider_logo_preview slider_logo_preview-pc" data-logo-width-input="#index_movie_logo_image_width" data-logo-img=".index_movie_logo_image img" data-bg-img=".index_movie_image img, .index_default_movie_image img" data-display-overlay=".index_movie_use_overlay" data-overlay-color=".index_movie_overlay_color" data-overlay-opacity=".index_movie_overlay_opacity"></div>
         </div>
        </div><!-- END .index_movie_logo_area -->
        <?php // キャッチフレーズ ----------------------- ?>
        <div class="index_movie_catch_area" style="<?php if($options['index_movie_content_type'] == 'type3') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e( 'Catchphrase setting', 'tcd-w' ); ?></h4>
         <textarea class="large-text" cols="50" rows="3" name="dp_options[index_movie_catch]"><?php echo esc_textarea(  $options['index_movie_catch'] ); ?></textarea>
         <ul class="option_list">
          <li class="cf"><span class="label"><?php _e('Font type', 'tcd-w');  ?></span>
           <select name="dp_options[index_movie_catch_font_type]">
            <?php foreach ( $font_type_options as $option ) { ?>
            <option style="padding-right: 10px;" value="<?php echo esc_attr($option['value']); ?>" <?php selected( $options['index_movie_catch_font_type'], $option['value'] ); ?>><?php echo $option['label']; ?></option>
            <?php } ?>
           </select>
          </li>
          <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_catch_font_size]" value="<?php echo esc_attr( $options['index_movie_catch_font_size'] ); ?>" /><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_catch_font_size_mobile]" value="<?php echo esc_attr( $options['index_movie_catch_font_size_mobile'] ); ?>" /><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_catch_color]" value="<?php echo esc_attr( $options['index_movie_catch_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
         </ul>
        </div><!-- END .index_slider_catch_area -->
        <?php // 説明文 ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e('Description', 'tcd-w');  ?></h4>
        <textarea class="large-text" cols="50" rows="3" name="dp_options[index_movie_desc]"><?php echo esc_textarea(  $options['index_movie_desc'] ); ?></textarea>
        <ul class="option_list">
         <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_desc_font_size]" value="<?php echo esc_attr( $options['index_movie_desc_font_size'] ); ?>" /><span>px</span></li>
         <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_desc_font_size_mobile]" value="<?php echo esc_attr( $options['index_movie_desc_font_size_mobile'] ); ?>" /><span>px</span></li>
         <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_desc_color]" value="<?php echo esc_attr( $options['index_movie_desc_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
        </ul>
        <?php // テキストシャドウ ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Dropshadow setting', 'tcd-w' ); ?></h4>
        <p class="displayment_checkbox"><label><input name="dp_options[index_movie_use_shadow]" type="checkbox" value="1" <?php checked( $options['index_movie_use_shadow'], 1 ); ?>><?php _e( 'Use dropshadow on text content', 'tcd-w' ); ?></label></p>
        <div style="<?php if($options['index_movie_use_shadow'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
          <li class="cf"><span class="label"><?php _e('Dropshadow position (left)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_shadow_h]" value="<?php echo esc_attr( $options['index_movie_shadow_h'] ); ?>"><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Dropshadow position (top)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_shadow_v]" value="<?php echo esc_attr( $options['index_movie_shadow_v'] ); ?>"><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Dropshadow size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_shadow_b]" value="<?php echo esc_attr( $options['index_movie_shadow_b'] ); ?>"><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Dropshadow color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_shadow_c]" value="<?php echo esc_attr( $options['index_movie_shadow_c'] ); ?>" data-default-color="#888888" class="c-color-picker"></li>
         </ul>
        </div>
        <?php // コンテンツのタイプ（下部） ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Content display at bottom', 'tcd-w' ); ?></h4>
        <ul class="design_radio_button">
         <?php foreach ( $index_slider_content_type_options3 as $option ) { ?>
         <li class="index_movie_bottom_content_<?php esc_attr_e( $option['value'] ); ?>_button">
          <input type="radio" id="index_movie_bottom_content_type_<?php esc_attr_e( $option['value'] ); ?>" name="dp_options[index_movie_bottom_content_type]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_movie_bottom_content_type'], $option['value'] ); ?> />
          <label for="index_movie_bottom_content_type_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
         </li>
         <?php }; ?>
        </ul>
        <?php // ボタン ----------------------- ?>
        <div class="index_movie_button_area" style="<?php if($options['index_movie_bottom_content_type'] == 'type2') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e('Button setting', 'tcd-w');  ?></h4>
         <ul class="option_list">
          <li class="cf"><span class="label"><?php _e('label', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[index_movie_button_label]" value="<?php echo esc_attr( $options['index_movie_button_label'] ); ?>" /></li>
          <li class="cf"><span class="label"><?php _e('URL', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[index_movie_url]" value="<?php echo esc_attr( $options['index_movie_url'] ); ?>"></li>
          <li class="cf"><span class="label"><?php _e('Open link in new window', 'tcd-w'); ?></span><input name="dp_options[index_movie_target]" type="checkbox" value="1" <?php checked( $options['index_movie_target'], 1 ); ?>></li>
          <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_button_bg_color]" value="<?php echo esc_attr( $options['index_movie_button_bg_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
          <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_button_font_color]" value="<?php echo esc_attr( $options['index_movie_button_font_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
          <li class="cf"><span class="label"><?php _e('Background color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_button_bg_color_hover]" value="<?php echo esc_attr( $options['index_movie_button_bg_color_hover'] ); ?>" data-default-color="#999999" class="c-color-picker"></li>
          <li class="cf"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_button_font_color_hover]" value="<?php echo esc_attr( $options['index_movie_button_font_color_hover'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
         </ul>
        </div>
        <?php //検索フォームの設定 -------------------------- ?>
        <div class="index_movie_search_area" style="<?php if($options['index_movie_bottom_content_type'] == 'type3') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e('Search form setting', 'tcd-w');  ?></h4>
         <ul class="option_list">
          <li class="cf"><span class="label"><?php _e('Placeholder', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[index_movie_search_label]" value="<?php echo esc_attr( $options['index_movie_search_label'] ); ?>" /></li>
          <li class="cf"><span class="label"><?php _e('Transparency of background', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[index_movie_search_opacity]" value="<?php echo esc_attr( $options['index_movie_search_opacity'] ); ?>" /><p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p></li>
         </ul>
        </div><!-- END .index_movie_search_area -->
        <?php // オーバーレイ ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Overlay setting', 'tcd-w' ); ?></h4>
        <p class="displayment_checkbox"><label><input class="index_movie_use_overlay" name="dp_options[index_movie_use_overlay]" type="checkbox" value="1" <?php checked( $options['index_movie_use_overlay'], 1 ); ?>><?php _e( 'Use overlay', 'tcd-w' ); ?></label></p>
        <div style="<?php if($options['index_movie_use_overlay'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
          <li class="cf"><span class="label"><?php _e('Color of overlay', 'tcd-w'); ?></span><input class="c-color-picker index_movie_overlay_color" type="text" name="dp_options[index_movie_overlay_color]" value="<?php echo esc_attr( $options['index_movie_overlay_color'] ); ?>" data-default-color="#000000"></li>
          <li class="cf"><span class="label"><?php _e('Transparency of overlay', 'tcd-w'); ?></span><input class="hankaku index_movie_overlay_opacity" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[index_movie_overlay_opacity]" value="<?php echo esc_attr( $options['index_movie_overlay_opacity'] ); ?>" /><p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p></li>
         </ul>
        </div>
        <ul class="button_list cf">
         <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
         <li><a class="close_sub_box button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
        </ul>
       </div><!-- END .sub_box_content -->
      </div><!-- END .sub_box -->
      <?php // モバイルサイズ用キャッチフレーズ ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■ ?>
      <div class="sub_box cf">
       <h3 class="theme_option_subbox_headline"><?php _e('Content for mobile size', 'tcd-w'); ?></h3>
       <div class="sub_box_content">
        <?php //コンテンツの設定 -------------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Content type setting', 'tcd-w' ); ?></h4>
        <div class="theme_option_message2" style="margin-top:15px;">
         <p><?php _e( 'This content will be replaced by content above when the web browser become mobile size.', 'tcd-w' ); ?></p>
        </div>
        <ul class="design_radio_button">
         <?php foreach ( $index_movie_mobile_content_type_options as $option ) { ?>
         <li class="index_movie_mobile_content_<?php esc_attr_e( $option['value'] ); ?>_button">
          <input type="radio" id="index_movie_mobile_content_type_<?php esc_attr_e( $option['value'] ); ?>" name="dp_options[index_movie_mobile_content_type]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_movie_mobile_content_type'], $option['value'] ); ?> />
          <label for="index_movie_mobile_content_type_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
         </li>
         <?php } ?>
        </ul>
        <div id="index_movie_mobile_content_type2_area" style="<?php if($options['index_movie_mobile_content_type'] == 'type2') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
        <?php // コンテンツのタイプ（上部） ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Content display at top', 'tcd-w' ); ?></h4>
        <ul class="design_radio_button">
         <?php foreach ( $index_slider_content_type_options2 as $option ) { ?>
         <li class="index_movie_content_<?php esc_attr_e( $option['value'] ); ?>_button">
          <input type="radio" id="index_movie_content_<?php esc_attr_e( $option['value'] ); ?>_mobile" name="dp_options[index_movie_content_type_mobile]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_movie_content_type_mobile'], $option['value'] ); ?> />
          <label for="index_movie_content_<?php esc_attr_e( $option['value'] ); ?>_mobile"><?php echo $option['label']; ?></label>
         </li>
         <?php } ?>
        </ul>
        <?php //ロゴの設定 -------------------------- ?>
        <div class="index_movie_logo_area" style="<?php if($options['index_movie_content_type_mobile'] == 'type2') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e( 'Logo setting', 'tcd-w' ); ?></h4>
         <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '145', '18'); ?></p>
         <div class="image_box cf index_movie_logo_image_mobile">
          <div class="cf cf_media_field hide-if-no-js">
           <input type="hidden" value="<?php echo esc_attr( $options['index_movie_logo_image_mobile'] ); ?>" id="index_movie_logo_image_mobile" name="dp_options[index_movie_logo_image_mobile]" class="cf_media_id">
           <div class="preview_field"><?php if ( $options['index_movie_logo_image_mobile'] ) { echo wp_get_attachment_image( $options['index_movie_logo_image_mobile'], 'full' ); } ?></div>
           <div class="button_area">
            <input type="button" value="<?php _e( 'Select Image', 'tcd-w' ); ?>" class="cfmf-select-img button">
            <input type="button" value="<?php _e( 'Remove Image', 'tcd-w' ); ?>" class="cfmf-delete-img button <?php if ( ! $options['index_movie_logo_image_mobile'] ) { echo 'hidden'; } ?>">
           </div>
          </div>
         </div>
         <div class="index_movie_image" style="display:none;">
          <img src="<?php echo esc_url(get_template_directory_uri()); ?>/admin/img/top_image.jpg">
         </div>
         <div class="slider_logo_preview-wrapper" style="display:none;">
          <h6 class="theme_option_headline2"><?php _e( 'Logo preview', 'tcd-w' ); ?></h6>
          <div class="theme_option_message2">
           <p><?php _e( 'You can change the logo size by moving the mouse cursor over the logo and dragging the arrow. Double-click on the logo to return to the original size.', 'tcd-w' ); ?></p>
          </div>
          <input type="hidden" value="<?php echo esc_attr( $options['index_movie_logo_image_width_mobile'] ); ?>" name="dp_options[index_movie_logo_image_width_mobile]" id="index_movie_logo_image_width_mobile">
          <div class="slider_logo_preview slider_logo_preview-mobile" data-logo-width-input="#index_movie_logo_image_width_mobile" data-logo-img=".index_movie_logo_image_mobile img" data-bg-img=".index_movie_image img, .index_default_movie_image img" data-display-overlay=".index_movie_use_overlay_mobile" data-overlay-color=".index_movie_overlay_color_mobile" data-overlay-opacity=".index_movie_overlay_opacity_mobile"></div>
         </div>
        </div><!-- END .index_movie_logo_area -->
        <?php // キャッチフレーズ ----------------------- ?>
        <div class="index_movie_catch_area" style="<?php if($options['index_movie_content_type_mobile'] == 'type3') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e( 'Catchphrase setting', 'tcd-w' ); ?></h4>
         <textarea class="large-text" cols="50" rows="3" name="dp_options[index_movie_catch_mobile]"><?php echo esc_textarea(  $options['index_movie_catch_mobile'] ); ?></textarea>
         <ul class="option_list">
          <li class="cf"><span class="label"><?php _e('Font type', 'tcd-w');  ?></span>
           <select name="dp_options[index_movie_catch_font_type_mobile]">
            <?php foreach ( $font_type_options as $option ) { ?>
            <option style="padding-right: 10px;" value="<?php echo esc_attr($option['value']); ?>" <?php selected( $options['index_movie_catch_font_type_mobile'], $option['value'] ); ?>><?php echo $option['label']; ?></option>
            <?php } ?>
           </select>
          </li>
          <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_mobile_catch_font_size]" value="<?php echo esc_attr( $options['index_movie_mobile_catch_font_size'] ); ?>" /><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_catch_color_mobile]" value="<?php echo esc_attr( $options['index_movie_catch_color_mobile'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
         </ul>
        </div><!-- END .index_slider_catch_area -->
        <?php // 説明文 ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e('Description', 'tcd-w');  ?></h4>
        <textarea class="large-text" cols="50" rows="3" name="dp_options[index_movie_desc_mobile]"><?php echo esc_textarea(  $options['index_movie_desc_mobile'] ); ?></textarea>
        <ul class="option_list">
         <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_mobile_desc_font_size]" value="<?php echo esc_attr( $options['index_movie_mobile_desc_font_size'] ); ?>" /><span>px</span></li>
         <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_desc_color_mobile]" value="<?php echo esc_attr( $options['index_movie_desc_color_mobile'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
        </ul>
        <?php // テキストシャドウ ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Dropshadow setting', 'tcd-w' ); ?></h4>
        <p class="displayment_checkbox"><label><input name="dp_options[index_movie_use_shadow_mobile]" type="checkbox" value="1" <?php checked( $options['index_movie_use_shadow_mobile'], 1 ); ?>><?php _e( 'Use dropshadow on text content', 'tcd-w' ); ?></label></p>
        <div style="<?php if($options['index_movie_use_shadow_mobile'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
          <li class="cf"><span class="label"><?php _e('Dropshadow position (left)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_shadow_h_mobile]" value="<?php echo esc_attr( $options['index_movie_shadow_h_mobile'] ); ?>"><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Dropshadow position (top)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_shadow_v_mobile]" value="<?php echo esc_attr( $options['index_movie_shadow_v_mobile'] ); ?>"><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Dropshadow size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[index_movie_shadow_b_mobile]" value="<?php echo esc_attr( $options['index_movie_shadow_b_mobile'] ); ?>"><span>px</span></li>
          <li class="cf"><span class="label"><?php _e('Dropshadow color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_shadow_c_mobile]" value="<?php echo esc_attr( $options['index_movie_shadow_c_mobile'] ); ?>" data-default-color="#888888" class="c-color-picker"></li>
         </ul>
        </div>
        <?php // コンテンツのタイプ（下部） ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Content display at bottom', 'tcd-w' ); ?></h4>
        <ul class="design_radio_button">
         <?php foreach ( $index_slider_content_type_options3 as $option ) { ?>
         <li class="index_movie_bottom_content_<?php esc_attr_e( $option['value'] ); ?>_button">
          <input type="radio" id="index_movie_bottom_content_type_<?php esc_attr_e( $option['value'] ); ?>_mobile" name="dp_options[index_movie_bottom_content_type_mobile]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_movie_bottom_content_type_mobile'], $option['value'] ); ?> />
          <label for="index_movie_bottom_content_type_<?php esc_attr_e( $option['value'] ); ?>_mobile"><?php echo $option['label']; ?></label>
         </li>
         <?php }; ?>
        </ul>
        <?php // ボタン ----------------------- ?>
        <div class="index_movie_button_area" style="<?php if($options['index_movie_bottom_content_type_mobile'] == 'type2') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e('Button setting', 'tcd-w');  ?></h4>
         <ul class="option_list">
          <li class="cf"><span class="label"><?php _e('label', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[index_movie_button_label_mobile]" value="<?php echo esc_attr( $options['index_movie_button_label_mobile'] ); ?>" /></li>
          <li class="cf"><span class="label"><?php _e('URL', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[index_movie_url_mobile]" value="<?php echo esc_attr( $options['index_movie_url_mobile'] ); ?>"></li>
          <li class="cf"><span class="label"><?php _e('Open link in new window', 'tcd-w'); ?></span><input name="dp_options[index_movie_target_mobile]" type="checkbox" value="1" <?php checked( $options['index_movie_target_mobile'], 1 ); ?>></li>
          <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_button_bg_color_mobile]" value="<?php echo esc_attr( $options['index_movie_button_bg_color_mobile'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
          <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_button_font_color_mobile]" value="<?php echo esc_attr( $options['index_movie_button_font_color_mobile'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
          <li class="cf"><span class="label"><?php _e('Background color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_button_bg_color_hover_mobile]" value="<?php echo esc_attr( $options['index_movie_button_bg_color_hover_mobile'] ); ?>" data-default-color="#999999" class="c-color-picker"></li>
          <li class="cf"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[index_movie_button_font_color_hover_mobile]" value="<?php echo esc_attr( $options['index_movie_button_font_color_hover_mobile'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
         </ul>
        </div>
        <?php //検索フォームの設定 -------------------------- ?>
        <div class="index_movie_search_area" style="<?php if($options['index_movie_bottom_content_type_mobile'] == 'type3') { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <h4 class="theme_option_headline2"><?php _e('Search form setting', 'tcd-w');  ?></h4>
         <ul class="option_list">
          <li class="cf"><span class="label"><?php _e('Placeholder', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[index_movie_search_label_mobile]" value="<?php echo esc_attr( $options['index_movie_search_label_mobile'] ); ?>" /></li>
          <li class="cf"><span class="label"><?php _e('Transparency of background', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[index_movie_search_opacity_mobile]" value="<?php echo esc_attr( $options['index_movie_search_opacity_mobile'] ); ?>" /><p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p></li>
         </ul>
        </div><!-- END .index_movie_search_area -->
        <?php // オーバーレイ ----------------------- ?>
        <h4 class="theme_option_headline2"><?php _e( 'Overlay setting', 'tcd-w' ); ?></h4>
        <p class="displayment_checkbox"><label><input class="index_movie_use_overlay_mobile" name="dp_options[index_movie_use_overlay_mobile]" type="checkbox" value="1" <?php checked( $options['index_movie_use_overlay_mobile'], 1 ); ?>><?php _e( 'Use overlay', 'tcd-w' ); ?></label></p>
        <div style="<?php if($options['index_movie_use_overlay_mobile'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
         <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
          <li class="cf"><span class="label"><?php _e('Color of overlay', 'tcd-w'); ?></span><input class="c-color-picker index_movie_overlay_color_mobile" type="text" name="dp_options[index_movie_overlay_color_mobile]" value="<?php echo esc_attr( $options['index_movie_overlay_color_mobile'] ); ?>" data-default-color="#000000"></li>
          <li class="cf"><span class="label"><?php _e('Transparency of overlay', 'tcd-w'); ?></span><input class="hankaku index_movie_overlay_opacity_mobile" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[index_movie_overlay_opacity_mobile]" value="<?php echo esc_attr( $options['index_movie_overlay_opacity_mobile'] ); ?>" /><p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p></li>
         </ul>
        </div>
        <ul class="button_list cf">
         <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
         <li><a class="close_sub_box button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
        </ul>
       </div><!-- END use same setting -->
       </div><!-- END .sub_box_content -->
      </div><!-- END .sub_box -->
     </div><!-- END index_movie_content -->
     <?php // コンテンツの高さ ---------- ?>
     <h4 class="theme_option_headline2"><?php _e('Header content height', 'tcd-w');  ?></h4>
     <ul class="design_radio_button">
      <?php foreach ( $header_content_height_options as $option ) { ?>
      <li>
       <input type="radio" id="index_header_content_height_<?php esc_attr_e( $option['value'] ); ?>" name="dp_options[index_header_content_height]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['index_header_content_height'], $option['value'] ); ?> />
       <label for="index_header_content_height_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
      </li>
      <?php } ?>
     </ul>
     <ul class="button_list cf">
      <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
      <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
     </ul>
    </div><!-- END .theme_option_field_ac_content -->
   </div><!-- END .theme_option_field -->
   <?php // ヘッダーコンテンツここまで -- ?>

   <?php // ニュースティッカー ------------------------------------------------------------------ ?>
   <div class="theme_option_field theme_option_field_ac">
    <h3 class="theme_option_headline"><?php _e('News ticker setting', 'tcd-w');  ?></h3>
    <div class="theme_option_field_ac_content">
     <p><label><input id="dp_options[show_index_news]" name="dp_options[show_index_news]" type="checkbox" value="1" <?php checked( '1', $options['show_index_news'] ); ?> /> <?php  _e('Display news ticker', 'tcd-w'); ?></label></p>
     <h4 class="theme_option_headline2"><?php _e('Number of post to display', 'tcd-w');  ?></h4>
     <select name="dp_options[index_news_num]">
      <?php for($i=3; $i<= 10; $i++): ?>
      <option style="padding-right: 10px;" value="<?php echo esc_attr($i); ?>" <?php selected( $options['index_news_num'], $i ); ?>><?php echo esc_html($i); ?></option>
      <?php endfor; ?>
     </select>
     <h4 class="theme_option_headline2"><?php _e('Color setting', 'tcd-w');  ?></h4>
     <ul class="color_field">
      <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_news_font_color]" value="<?php echo esc_attr( $options['index_news_font_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[index_news_font_color_hover]" value="<?php echo esc_attr( $options['index_news_font_color_hover'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[index_news_bg_color]" value="<?php echo esc_attr( $options['index_news_bg_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Transparency of background', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[index_news_bg_opacity]" value="<?php echo esc_attr( $options['index_news_bg_opacity'] ); ?>" /><p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p></li>
      <li class="cf">
       <span class="label"><?php _e('Ticker speed', 'tcd-w'); ?></span>
       <select name="dp_options[index_news_time]">
        <?php
             $i = 1;
             foreach ( $time_options as $option ):
               if( $i >= 3 && $i <= 10 ){
        ?>
        <option style="padding-right: 10px;" value="<?php echo esc_attr( $option['value'] ); ?>" <?php selected( $options['index_news_time'], $option['value'] ); ?>><?php echo esc_html($option['label']); ?></option>
        <?php
               }
               $i++;
            endforeach;
        ?>
       </select>
      </li>
     </ul>
     <ul class="button_list cf">
      <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
      <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
     </ul>
    </div><!-- END .theme_option_field_ac_content -->
   </div><!-- END .theme_option_field -->

   <?php // コンテンツビルダー ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■ ?>
   <div class="theme_option_field theme_option_field_ac open active show_arrow">
    <h3 class="theme_option_headline"><?php _e('Content builder', 'tcd-w');  ?></h3>
    <div class="theme_option_field_ac_content">
     <div class="theme_option_message no_arrow">
      <?php echo __( '<p>You can build contents freely with this function.</p><br /><p>STEP1: Click Add content button.<br />STEP2: Select content from dropdown menu.<br />STEP3: Input data and save the option.</p><br /><p>You can change order by dragging MOVE button and you can delete content by clicking DELETE button.</p>', 'tcd-w' ); ?>
     </div>
     <h4 class="theme_option_headline2"><?php _e( 'Content image', 'tcd-w' ); ?></h4>
     <ul class="design_button_list cf rebox_group">
      <li><a href="<?php bloginfo('template_url'); ?>/admin/img/cb_content1.jpg" title="<?php _e( 'Content1', 'tcd-w' ); ?>"><?php _e( 'Content1', 'tcd-w' ); ?></a></li>
      <li><a href="<?php bloginfo('template_url'); ?>/admin/img/cb_content2.jpg" title="<?php _e( 'Content2', 'tcd-w' ); ?>"><?php _e( 'Content2', 'tcd-w' ); ?></a></li>
      <li><a href="<?php bloginfo('template_url'); ?>/admin/img/cb_parallax.jpg" title="<?php _e( 'Parallax content', 'tcd-w' ); ?>"><?php _e( 'Parallax content', 'tcd-w' ); ?></a></li>
      <li><a href="<?php bloginfo('template_url'); ?>/admin/img/cb_post_list.jpg" title="<?php printf(__('%s list', 'tcd-w'), $work_label); ?>"><?php printf(__('%s list', 'tcd-w'), $work_label); ?></a></li>
      <li><a href="<?php bloginfo('template_url'); ?>/admin/img/cb_carousel.jpg" title="<?php _e( 'Carousel', 'tcd-w' ); ?>"><?php _e( 'Carousel', 'tcd-w' ); ?></a></li>
     </ul>
    </div><!-- END .theme_option_field_ac_content -->
   </div><!-- END .theme_option_field -->

   <div id="contents_builder_wrap">
    <div id="contents_builder">
     <p class="cb_message"><?php _e( 'Click Add content button to start content builder', 'tcd-w' ); ?></p>
     <?php
          if (!empty($options['contents_builder'])) {
            foreach($options['contents_builder'] as $key => $content) :
              $cb_index = 'cb_'.$key.'_'.mt_rand(0,999999);
     ?>
     <div class="cb_row">
      <ul class="cb_button cf">
       <li><span class="cb_move"><?php echo __('Move', 'tcd-w'); ?></span></li>
       <li><span class="cb_delete"><?php echo __('Delete', 'tcd-w'); ?></span></li>
      </ul>
      <div class="cb_column_area cf">
       <div class="cb_column">
        <input type="hidden" class="cb_index" value="<?php echo $cb_index; ?>" />
        <?php the_cb_content_select($cb_index, $content['cb_content_select']); ?>
        <?php if (!empty($content['cb_content_select'])) the_cb_content_setting($cb_index, $content['cb_content_select'], $content); ?>
       </div>
      </div><!-- END .cb_column_area -->
     </div><!-- END .cb_row -->
     <?php
          endforeach;
         };
     ?>
    </div><!-- END #contents_builder -->
    <ul class="button_list cf" id="cb_add_row_buttton_area">
     <li><input type="button" value="<?php echo __( 'Add content', 'tcd-w' ); ?>" class="button-ml add_row"></li>
     <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
    </ul>
   </div><!-- END #contents_builder_wrap -->

   <?php // コンテンツビルダー追加用 非表示 ?>
   <div id="contents_builder-clone" class="hidden">
    <div class="cb_row">
     <ul class="cb_button cf">
      <li><span class="cb_move"><?php echo __('Move', 'tcd-w'); ?></span></li>
      <li><span class="cb_delete"><?php echo __('Delete', 'tcd-w'); ?></span></li>
     </ul>
     <div class="cb_column_area cf">
      <div class="cb_column">
       <input type="hidden" class="cb_index" value="cb_cloneindex" />
       <?php the_cb_content_select('cb_cloneindex'); ?>
      </div>
     </div><!-- END .cb_column_area -->
    </div><!-- END .cb_row -->
    <?php
         the_cb_content_setting('cb_cloneindex', 'content1');
         the_cb_content_setting('cb_cloneindex', 'content2');
         the_cb_content_setting('cb_cloneindex', 'para_content');
         the_cb_content_setting('cb_cloneindex', 'post_list');
         the_cb_content_setting('cb_cloneindex', 'carousel');
         the_cb_content_setting('cb_cloneindex', 'free_space');
    ?>
   </div><!-- END #contents_builder-clone.hidden -->
   <?php // コンテンツビルダーここまで ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■ ?>


</div><!-- END .tab-content -->

<?php
} // END add_front_page_tab_panel()


// バリデーション　■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
function add_front_page_theme_options_validate( $input ) {

  global $dp_default_options, $index_content_type_options, $time_options, $font_type_options, $content_direction_options, $index_slider_content_type_options, $index_slider_content_type_options2, $index_slider_content_type_options3, $index_slider_animation_type_options, $header_content_height_options, $index_movie_mobile_content_type_options;

  // ヘッダーコンテンツ
  if ( ! isset( $input['index_header_content_type'] ) )
    $input['index_header_content_type'] = null;
  if ( ! array_key_exists( $input['index_header_content_type'], $index_content_type_options ) )
    $input['index_header_content_type'] = null;

  // ヘッダーコンテンツの高さ
  if ( ! isset( $input['index_header_content_height'] ) )
    $input['index_header_content_height'] = null;
  if ( ! array_key_exists( $input['index_header_content_height'], $header_content_height_options ) )
    $input['index_header_content_height'] = null;

  // 画像スライダーの時間
  if ( ! isset( $value['index_slider_time'] ) )
    $value['index_slider_time'] = null;
  if ( ! array_key_exists( $value['index_slider_time'], $time_options ) )
    $value['index_slider_time'] = null;

  // 画像スライダーのアニメーション
  if ( ! isset( $input['index_slider_animation_type'] ) )
    $input['index_slider_animation_type'] = null;
  if ( ! array_key_exists( $input['index_slider_animation_type'], $index_slider_animation_type_options ) )
    $input['index_slider_animation_type'] = null;

  // 画像スライダー
  for ( $i = 1; $i <= 3; $i++ ) {
    // 画像の設定
    $input['index_slider_image'.$i] = wp_filter_nohtml_kses( $input['index_slider_image'.$i] );
    $input['index_slider_image_mobile'.$i] = wp_filter_nohtml_kses( $input['index_slider_image_mobile'.$i] );

    // コンテンツのタイプ
    if ( ! isset( $value['index_slider_content_type'.$i] ) )
      $value['index_slider_content_type'.$i] = null;
    if ( ! array_key_exists( $value['index_slider_content_type'.$i], $index_slider_content_type_options2 ) )
      $value['index_slider_content_type'.$i] = null;
    if ( ! isset( $value['index_slider_bottom_content_type'.$i] ) )
      $value['index_slider_bottom_content_type'.$i] = null;
    if ( ! array_key_exists( $value['index_slider_bottom_content_type'.$i], $index_slider_content_type_options3 ) )
      $value['index_slider_bottom_content_type'.$i] = null;

    // ロゴの設定
    $input['index_slider_logo_image'.$i] = wp_filter_nohtml_kses( $input['index_slider_logo_image'.$i] );
    $input['index_slider_logo_image_width'.$i] = wp_filter_nohtml_kses( $input['index_slider_logo_image_width'.$i] );

    // キャッチフレーズ
    $input['index_slider_catch'.$i] = wp_filter_nohtml_kses( $input['index_slider_catch'.$i] );
    if ( ! isset( $value['index_slider_catch_font_type'.$i] ) )
      $value['index_slider_catch_font_type'.$i] = null;
    if ( ! array_key_exists( $value['index_slider_catch_font_type'.$i], $font_type_options ) )
      $value['index_slider_catch_font_type'.$i] = null;
    $input['index_slider_catch_font_size'.$i] = wp_filter_nohtml_kses( $input['index_slider_catch_font_size'.$i] );
    $input['index_slider_catch_font_size_mobile'.$i] = wp_filter_nohtml_kses( $input['index_slider_catch_font_size_mobile'.$i] );
    $input['index_slider_catch_color'.$i] = wp_filter_nohtml_kses( $input['index_slider_catch_color'.$i] );

    // 説明文
    $input['index_slider_desc'.$i] = wp_filter_nohtml_kses( $input['index_slider_desc'.$i] );
    $input['index_slider_desc_font_size'.$i] = wp_filter_nohtml_kses( $input['index_slider_desc_font_size'.$i] );
    $input['index_slider_desc_font_size_mobile'.$i] = wp_filter_nohtml_kses( $input['index_slider_desc_font_size_mobile'.$i] );
    $input['index_slider_desc_color'.$i] = wp_filter_nohtml_kses( $input['index_slider_desc_color'.$i] );

    // テキストシャドウ
    if ( ! isset( $input['index_slider_use_shadow'.$i] ) )
      $input['index_slider_use_shadow'.$i] = null;
      $input['index_slider_use_shadow'.$i] = ( $input['index_slider_use_shadow'.$i] == 1 ? 1 : 0 );
    $input['index_slider_shadow_h'.$i] = wp_filter_nohtml_kses( $input['index_slider_shadow_h'.$i] );
    $input['index_slider_shadow_v'.$i] = wp_filter_nohtml_kses( $input['index_slider_shadow_v'.$i] );
    $input['index_slider_shadow_b'.$i] = wp_filter_nohtml_kses( $input['index_slider_shadow_b'.$i] );
    $input['index_slider_shadow_c'.$i] = wp_filter_nohtml_kses( $input['index_slider_shadow_c'.$i] );

    // ボタン
    $input['index_slider_button_label'.$i] = wp_filter_nohtml_kses( $input['index_slider_button_label'.$i] );
    $input['index_slider_button_bg_color'.$i] = wp_filter_nohtml_kses( $input['index_slider_button_bg_color'.$i] );
    $input['index_slider_button_font_color'.$i] = wp_filter_nohtml_kses( $input['index_slider_button_font_color'.$i] );
    $input['index_slider_button_bg_color_hover'.$i] = wp_filter_nohtml_kses( $input['index_slider_button_bg_color_hover'.$i] );
    $input['index_slider_button_font_color_hover'.$i] = wp_filter_nohtml_kses( $input['index_slider_button_font_color_hover'.$i] );
    $input['index_slider_url'.$i] = wp_filter_nohtml_kses( $input['index_slider_url'.$i] );
    if ( ! isset( $input['index_slider_target'.$i] ) )
      $input['index_slider_target'.$i] = null;
      $input['index_slider_target'.$i] = ( $input['index_slider_target'.$i] == 1 ? 1 : 0 );

    // 検索フォームの設定
    $input['index_slider_search_label'.$i] = wp_filter_nohtml_kses( $input['index_slider_search_label'.$i] );
    $input['index_slider_search_opacity'.$i] = wp_filter_nohtml_kses( $input['index_slider_search_opacity'.$i] );

    // オーバーレイ
    if ( ! isset( $input['index_slider_use_overlay'.$i] ) )
      $input['index_slider_use_overlay'.$i] = null;
      $input['index_slider_use_overlay'.$i] = ( $input['index_slider_use_overlay'.$i] == 1 ? 1 : 0 );
    $input['index_slider_overlay_color'.$i] = wp_filter_nohtml_kses( $input['index_slider_overlay_color'.$i] );
    $input['index_slider_overlay_opacity'.$i] = wp_filter_nohtml_kses( $input['index_slider_overlay_opacity'.$i] );
    if ( ! isset( $input['index_slider_use_overlay_mobile'.$i] ) )
      $input['index_slider_use_overlay_mobile'.$i] = null;
      $input['index_slider_use_overlay_mobile'.$i] = ( $input['index_slider_use_overlay_mobile'.$i] == 1 ? 1 : 0 );
    $input['index_slider_overlay_color_mobile'.$i] = wp_filter_nohtml_kses( $input['index_slider_overlay_color_mobile'.$i] );
    $input['index_slider_overlay_opacity_mobile'.$i] = wp_filter_nohtml_kses( $input['index_slider_overlay_opacity_mobile'.$i] );

    // コンテンツの方向
    if ( ! isset( $value['index_slider_content_direction'.$i] ) )
      $value['index_slider_content_direction'.$i] = null;
    if ( ! array_key_exists( $value['index_slider_content_direction'.$i], $content_direction_options ) )
      $value['index_slider_content_direction'.$i] = null;

  }

  // 画像スライダー　スマホ用　コンテンツのタイプ
  if ( ! isset( $value['index_slider_mobile_content_type'] ) )
    $value['index_slider_mobile_content_type'] = null;
  if ( ! array_key_exists( $value['index_slider_mobile_content_type'], $index_slider_content_type_options ) )
    $value['index_slider_mobile_content_type'] = null;

  // 画像スライダー　スマホ用　キャッチフレーズ
  $input['index_slider_mobile_catch'] = wp_filter_nohtml_kses( $input['index_slider_mobile_catch'] );
  if ( ! isset( $value['index_slider_mobile_catch_font_type'] ) )
    $value['index_slider_mobile_catch_font_type'] = null;
  if ( ! array_key_exists( $value['index_slider_mobile_catch_font_type'], $font_type_options ) )
    $value['index_slider_mobile_catch_font_type'] = null;
  $input['index_slider_mobile_catch_font_size'] = wp_filter_nohtml_kses( $input['index_slider_mobile_catch_font_size'] );
  $input['index_slider_mobile_catch_color'] = wp_filter_nohtml_kses( $input['index_slider_mobile_catch_color'] );

  // 画像スライダー　スマホ用　ロゴ
  $input['index_slider_mobile_logo_image'] = absint( $input['index_slider_mobile_logo_image'] );
  $input['index_slider_mobile_logo_image_width'] = absint( $input['index_slider_mobile_logo_image_width'] );

  // 画像スライダー　スマホ用　テキストシャドウ
  if ( ! isset( $input['index_slider_mobile_use_shadow'] ) )
    $input['index_slider_mobile_use_shadow'] = null;
    $input['index_slider_mobile_use_shadow'] = ( $input['index_slider_mobile_use_shadow'] == 1 ? 1 : 0 );
  $input['index_slider_mobile_shadow_h'] = wp_filter_nohtml_kses( $input['index_slider_mobile_shadow_h'] );
  $input['index_slider_mobile_shadow_v'] = wp_filter_nohtml_kses( $input['index_slider_mobile_shadow_v'] );
  $input['index_slider_mobile_shadow_b'] = wp_filter_nohtml_kses( $input['index_slider_mobile_shadow_b'] );
  $input['index_slider_mobile_shadow_c'] = wp_filter_nohtml_kses( $input['index_slider_mobile_shadow_c'] );

  // 動画 ----------------------------------------------------------------
  $input['index_video'] = wp_filter_nohtml_kses( $input['index_video'] );

  // Youtube --------------------------------------------------------------
  $input['index_youtube_url'] = wp_filter_nohtml_kses( $input['index_youtube_url'] );

  // 動画用コンテンツ PC用 -----------------------------------------------------
  // 代替画像
  $input['index_movie_image'] = wp_filter_nohtml_kses( $input['index_movie_image'] );

  // コンテンツのタイプ
  if ( ! isset( $value['index_movie_content_type'] ) )
    $value['index_movie_content_type'] = null;
  if ( ! array_key_exists( $value['index_movie_content_type'], $index_slider_content_type_options2 ) )
    $value['index_movie_content_type'] = null;
  if ( ! isset( $value['index_movie_bottom_content_type'] ) )
    $value['index_movie_bottom_content_type'] = null;
  if ( ! array_key_exists( $value['index_movie_bottom_content_type'], $index_slider_content_type_options3 ) )
    $value['index_movie_bottom_content_type'] = null;

  // ロゴの設定
  $input['index_movie_logo_image'] = wp_filter_nohtml_kses( $input['index_movie_logo_image'] );
  $input['index_movie_logo_image_width'] = wp_filter_nohtml_kses( $input['index_movie_logo_image_width'] );

  // キャッチフレーズ
  $input['index_movie_catch'] = wp_filter_nohtml_kses( $input['index_movie_catch'] );
  if ( ! isset( $value['index_movie_catch_font_type'] ) )
    $value['index_movie_catch_font_type'] = null;
  if ( ! array_key_exists( $value['index_movie_catch_font_type'], $font_type_options ) )
    $value['index_movie_catch_font_type'] = null;
  $input['index_movie_catch_font_size'] = wp_filter_nohtml_kses( $input['index_movie_catch_font_size'] );
  $input['index_movie_catch_font_size_mobile'] = wp_filter_nohtml_kses( $input['index_movie_catch_font_size_mobile'] );
  $input['index_movie_catch_color'] = wp_filter_nohtml_kses( $input['index_movie_catch_color'] );

  // 説明文
  $input['index_movie_desc'] = wp_filter_nohtml_kses( $input['index_movie_desc'] );
  $input['index_movie_desc_font_size'] = wp_filter_nohtml_kses( $input['index_movie_desc_font_size'] );
  $input['index_movie_desc_font_size_mobile'] = wp_filter_nohtml_kses( $input['index_movie_desc_font_size_mobile'] );
  $input['index_movie_desc_color'] = wp_filter_nohtml_kses( $input['index_movie_desc_color'] );

  // テキストシャドウ
  if ( ! isset( $input['index_movie_use_shadow'] ) )
    $input['index_movie_use_shadow'] = null;
    $input['index_movie_use_shadow'] = ( $input['index_movie_use_shadow'] == 1 ? 1 : 0 );
  $input['index_movie_shadow_h'] = wp_filter_nohtml_kses( $input['index_movie_shadow_h'] );
  $input['index_movie_shadow_v'] = wp_filter_nohtml_kses( $input['index_movie_shadow_v'] );
  $input['index_movie_shadow_b'] = wp_filter_nohtml_kses( $input['index_movie_shadow_b'] );
  $input['index_movie_shadow_c'] = wp_filter_nohtml_kses( $input['index_movie_shadow_c'] );

  // ボタン
  $input['index_movie_button_label'] = wp_filter_nohtml_kses( $input['index_movie_button_label'] );
  $input['index_movie_button_bg_color'] = wp_filter_nohtml_kses( $input['index_movie_button_bg_color'] );
  $input['index_movie_button_font_color'] = wp_filter_nohtml_kses( $input['index_movie_button_font_color'] );
  $input['index_movie_button_bg_color_hover'] = wp_filter_nohtml_kses( $input['index_movie_button_bg_color_hover'] );
  $input['index_movie_button_font_color_hover'] = wp_filter_nohtml_kses( $input['index_movie_button_font_color_hover'] );
  $input['index_movie_url'] = wp_filter_nohtml_kses( $input['index_movie_url'] );
  if ( ! isset( $input['index_movie_target'] ) )
    $input['index_movie_target'] = null;
    $input['index_movie_target'] = ( $input['index_movie_target'] == 1 ? 1 : 0 );

  // 検索フォームの設定
  $input['index_movie_search_label'] = wp_filter_nohtml_kses( $input['index_movie_search_label'] );
  $input['index_movie_search_opacity'] = wp_filter_nohtml_kses( $input['index_movie_search_opacity'] );

  // オーバーレイ
  if ( ! isset( $input['index_movie_use_overlay'] ) )
    $input['index_movie_use_overlay'] = null;
    $input['index_movie_use_overlay'] = ( $input['index_movie_use_overlay'] == 1 ? 1 : 0 );
  $input['index_movie_overlay_color'] = wp_filter_nohtml_kses( $input['index_movie_overlay_color'] );
  $input['index_movie_overlay_opacity'] = wp_filter_nohtml_kses( $input['index_movie_overlay_opacity'] );

  // 動画用コンテンツ スマホ用 -----------------------------------------------------
  if ( ! isset( $value['index_movie_mobile_content_type'] ) )
    $value['index_movie_mobile_content_type'] = null;
  if ( ! array_key_exists( $value['index_movie_mobile_content_type'], $index_movie_mobile_content_type_options ) )
    $value['index_movie_mobile_content_type'] = null;
  if ( ! isset( $value['index_movie_content_type_mobile'] ) )
    $value['index_movie_content_type_mobile'] = null;
  if ( ! array_key_exists( $value['index_movie_content_type_mobile'], $index_slider_content_type_options2 ) )
    $value['index_movie_content_type_mobile'] = null;
  if ( ! isset( $value['index_movie_bottom_content_type_mobile'] ) )
    $value['index_movie_bottom_content_type_mobile'] = null;
  if ( ! array_key_exists( $value['index_movie_bottom_content_type_mobile'], $index_slider_content_type_options3 ) )
    $value['index_movie_bottom_content_type_mobile'] = null;

  // ロゴの設定
  $input['index_movie_logo_image_mobile'] = wp_filter_nohtml_kses( $input['index_movie_logo_image_mobile'] );
  $input['index_movie_logo_image_width_mobile'] = wp_filter_nohtml_kses( $input['index_movie_logo_image_width_mobile'] );

  // キャッチフレーズ
  $input['index_movie_catch_mobile'] = wp_filter_nohtml_kses( $input['index_movie_catch_mobile'] );
  if ( ! isset( $value['index_movie_catch_font_type_mobile'] ) )
    $value['index_movie_catch_font_type_mobile'] = null;
  if ( ! array_key_exists( $value['index_movie_catch_font_type_mobile'], $font_type_options ) )
    $value['index_movie_catch_font_type_mobile'] = null;
  $input['index_movie_mobile_catch_font_size'] = wp_filter_nohtml_kses( $input['index_movie_mobile_catch_font_size'] );
  $input['index_movie_catch_color_mobile'] = wp_filter_nohtml_kses( $input['index_movie_catch_color_mobile'] );

  // 説明文
  $input['index_movie_desc_mobile'] = wp_filter_nohtml_kses( $input['index_movie_desc_mobile'] );
  $input['index_movie_mobile_desc_font_size'] = wp_filter_nohtml_kses( $input['index_movie_mobile_desc_font_size'] );
  $input['index_movie_desc_color_mobile'] = wp_filter_nohtml_kses( $input['index_movie_desc_color_mobile'] );

  // テキストシャドウ
  if ( ! isset( $input['index_movie_use_shadow_mobile'] ) )
    $input['index_movie_use_shadow_mobile'] = null;
    $input['index_movie_use_shadow_mobile'] = ( $input['index_movie_use_shadow_mobile'] == 1 ? 1 : 0 );
  $input['index_movie_shadow_h_mobile'] = wp_filter_nohtml_kses( $input['index_movie_shadow_h_mobile'] );
  $input['index_movie_shadow_v_mobile'] = wp_filter_nohtml_kses( $input['index_movie_shadow_v_mobile'] );
  $input['index_movie_shadow_b_mobile'] = wp_filter_nohtml_kses( $input['index_movie_shadow_b_mobile'] );
  $input['index_movie_shadow_c_mobile'] = wp_filter_nohtml_kses( $input['index_movie_shadow_c_mobile'] );

  // ボタン
  $input['index_movie_button_label_mobile'] = wp_filter_nohtml_kses( $input['index_movie_button_label_mobile'] );
  $input['index_movie_button_bg_color_mobile'] = wp_filter_nohtml_kses( $input['index_movie_button_bg_color_mobile'] );
  $input['index_movie_button_font_color_mobile'] = wp_filter_nohtml_kses( $input['index_movie_button_font_color_mobile'] );
  $input['index_movie_button_bg_color_hover_mobile'] = wp_filter_nohtml_kses( $input['index_movie_button_bg_color_hover_mobile'] );
  $input['index_movie_button_font_color_hover_mobile'] = wp_filter_nohtml_kses( $input['index_movie_button_font_color_hover_mobile'] );
  $input['index_movie_url_mobile'] = wp_filter_nohtml_kses( $input['index_movie_url_mobile'] );
  if ( ! isset( $input['index_movie_target_mobile'] ) )
    $input['index_movie_target_mobile'] = null;
    $input['index_movie_target_mobile'] = ( $input['index_movie_target_mobile'] == 1 ? 1 : 0 );

  // 検索フォームの設定
  $input['index_movie_search_label_mobile'] = wp_filter_nohtml_kses( $input['index_movie_search_label_mobile'] );
  $input['index_movie_search_opacity_mobile'] = wp_filter_nohtml_kses( $input['index_movie_search_opacity_mobile'] );

  // オーバーレイ
  if ( ! isset( $input['index_movie_use_overlay_mobile'] ) )
    $input['index_movie_use_overlay_mobile'] = null;
    $input['index_movie_use_overlay_mobile'] = ( $input['index_movie_use_overlay_mobile'] == 1 ? 1 : 0 );
  $input['index_movie_overlay_color_mobile'] = wp_filter_nohtml_kses( $input['index_movie_overlay_color_mobile'] );
  $input['index_movie_overlay_opacity_mobile'] = wp_filter_nohtml_kses( $input['index_movie_overlay_opacity_mobile'] );


  // ニュースティッカー
  if ( ! isset( $input['show_index_news'] ) )
    $input['show_index_news'] = null;
    $input['show_index_news'] = ( $input['show_index_news'] == 1 ? 1 : 0 );
  $input['index_news_num'] = wp_filter_nohtml_kses( $input['index_news_num'] );
  $input['index_news_font_color'] = wp_filter_nohtml_kses( $input['index_news_font_color'] );
  $input['index_news_font_color_hover'] = wp_filter_nohtml_kses( $input['index_news_font_color_hover'] );
  $input['index_news_bg_color'] = wp_filter_nohtml_kses( $input['index_news_bg_color'] );
  $input['index_news_bg_opacity'] = wp_filter_nohtml_kses( $input['index_news_bg_opacity'] );
  if ( ! isset( $value['index_news_time'] ) )
    $value['index_news_time'] = null;
  if ( ! array_key_exists( $value['index_news_time'], $time_options ) )
    $value['index_news_time'] = null;


  // コンテンツビルダー -----------------------------------------------------------------------------
  if (!empty($input['contents_builder'])) {

    $input_cb = $input['contents_builder'];
    $input['contents_builder'] = array();

    foreach($input_cb as $key => $value) {

      // クローン用はスルー
      //if (in_array($key, array('cb_cloneindex', 'cb_cloneindex2'))) continue;
      if (in_array($key, array('cb_cloneindex', 'cb_cloneindex2'), true)) continue;

      //コンテンツ1 -----------------------------------------------------------------------
      if ($value['cb_content_select'] == 'content1') {

        $value['content1_catch'] = wp_filter_nohtml_kses( $value['content1_catch'] );
        $value['content1_catch_font_size'] = wp_filter_nohtml_kses( $value['content1_catch_font_size'] );
        $value['content1_catch_font_size_mobile'] = wp_filter_nohtml_kses( $value['content1_catch_font_size_mobile'] );
        $value['content1_desc1'] = wp_filter_nohtml_kses( $value['content1_desc1'] );
        $value['content1_desc2'] = wp_filter_nohtml_kses( $value['content1_desc2'] );
        $value['content1_desc_font_size'] = wp_filter_nohtml_kses( $value['content1_desc_font_size'] );
        $value['content1_desc_font_size_mobile'] = wp_filter_nohtml_kses( $value['content1_desc_font_size_mobile'] );
        if ( ! isset( $value['content1_show_button'] ) )
          $value['content1_show_button'] = null;
          $value['content1_show_button'] = ( $value['content1_show_button'] == 1 ? 1 : 0 );
        $value['content1_button_label'] = wp_filter_nohtml_kses( $value['content1_button_label'] );
        $value['content1_button_url'] = wp_filter_nohtml_kses( $value['content1_button_url'] );
        $value['content1_button_bg_color'] = wp_filter_nohtml_kses( $value['content1_button_bg_color'] );
        $value['content1_button_font_color'] = wp_filter_nohtml_kses( $value['content1_button_font_color'] );
        $value['content1_button_bg_color_hover'] = wp_filter_nohtml_kses( $value['content1_button_bg_color_hover'] );
        $value['content1_button_font_color_hover'] = wp_filter_nohtml_kses( $value['content1_button_font_color_hover'] );
        $value['content1_image1'] = wp_filter_nohtml_kses( $value['content1_image1'] );
        $value['content1_image2'] = wp_filter_nohtml_kses( $value['content1_image2'] );
        $value['content1_image3'] = wp_filter_nohtml_kses( $value['content1_image3'] );

      //コンテンツ2 -----------------------------------------------------------------------
      } elseif ($value['cb_content_select'] == 'content2') {

        $value['content2_catch'] = wp_filter_nohtml_kses( $value['content2_catch'] );
        $value['content2_catch_font_size'] = wp_filter_nohtml_kses( $value['content2_catch_font_size'] );
        $value['content2_catch_font_size_mobile'] = wp_filter_nohtml_kses( $value['content2_catch_font_size_mobile'] );
        $value['content2_desc1'] = wp_filter_nohtml_kses( $value['content2_desc1'] );
        $value['content2_desc2'] = wp_filter_nohtml_kses( $value['content2_desc2'] );
        $value['content2_desc_font_size'] = wp_filter_nohtml_kses( $value['content2_desc_font_size'] );
        $value['content2_desc_font_size_mobile'] = wp_filter_nohtml_kses( $value['content2_desc_font_size_mobile'] );
        if ( ! isset( $value['content2_show_button1'] ) )
          $value['content2_show_button1'] = null;
          $value['content2_show_button1'] = ( $value['content2_show_button1'] == 1 ? 1 : 0 );
        $value['content2_button1_label'] = wp_filter_nohtml_kses( $value['content2_button1_label'] );
        $value['content2_button1_url'] = wp_filter_nohtml_kses( $value['content2_button1_url'] );
        $value['content2_button1_bg_color'] = wp_filter_nohtml_kses( $value['content2_button1_bg_color'] );
        $value['content2_button1_font_color'] = wp_filter_nohtml_kses( $value['content2_button1_font_color'] );
        $value['content2_button1_bg_color_hover'] = wp_filter_nohtml_kses( $value['content2_button1_bg_color_hover'] );
        $value['content2_button1_font_color_hover'] = wp_filter_nohtml_kses( $value['content2_button1_font_color_hover'] );
        if ( ! isset( $value['content2_show_button2'] ) )
          $value['content2_show_button2'] = null;
          $value['content2_show_button2'] = ( $value['content2_show_button2'] == 1 ? 1 : 0 );
        $value['content2_button2_label'] = wp_filter_nohtml_kses( $value['content2_button2_label'] );
        $value['content2_button2_url'] = wp_filter_nohtml_kses( $value['content2_button2_url'] );
        $value['content2_button2_bg_color'] = wp_filter_nohtml_kses( $value['content2_button2_bg_color'] );
        $value['content2_button2_font_color'] = wp_filter_nohtml_kses( $value['content2_button2_font_color'] );
        $value['content2_button2_bg_color_hover'] = wp_filter_nohtml_kses( $value['content2_button2_bg_color_hover'] );
        $value['content2_button2_font_color_hover'] = wp_filter_nohtml_kses( $value['content2_button2_font_color_hover'] );
        $value['content2_image'] = wp_filter_nohtml_kses( $value['content2_image'] );
        if ( ! isset( $value['content2_use_overlay'] ) )
          $value['content2_use_overlay'] = null;
          $value['content2_use_overlay'] = ( $value['content2_use_overlay'] == 1 ? 1 : 0 );
        $value['content2_overlay_color'] = wp_filter_nohtml_kses( $value['content2_overlay_color'] );
        $value['content2_overlay_opacity'] = wp_filter_nohtml_kses( $value['content2_overlay_opacity'] );
        $value['content2_catch2'] = wp_filter_nohtml_kses( $value['content2_catch2'] );
        $value['content2_catch2_font_size'] = wp_filter_nohtml_kses( $value['content2_catch2_font_size'] );
        $value['content2_catch2_font_size_mobile'] = wp_filter_nohtml_kses( $value['content2_catch2_font_size_mobile'] );
        $value['content2_catch2_color'] = wp_filter_nohtml_kses( $value['content2_catch2_color'] );

      //パララックスコンテンツ -----------------------------------------------------------------------
      } elseif ($value['cb_content_select'] == 'para_content') {

        $value['para_content_image'] = wp_filter_nohtml_kses( $value['para_content_image'] );
        $value['para_content_catch'] = wp_filter_nohtml_kses( $value['para_content_catch'] );
        $value['para_content_catch_font_size'] = wp_filter_nohtml_kses( $value['para_content_catch_font_size'] );
        $value['para_content_catch_font_size_mobile'] = wp_filter_nohtml_kses( $value['para_content_catch_font_size_mobile'] );
        $value['para_content_desc'] = wp_filter_nohtml_kses( $value['para_content_desc'] );
        $value['para_content_desc_font_size'] = wp_filter_nohtml_kses( $value['para_content_desc_font_size'] );
        $value['para_content_desc_font_size_mobile'] = wp_filter_nohtml_kses( $value['para_content_desc_font_size_mobile'] );
        if ( ! isset( $value['para_content_use_overlay'] ) )
          $value['para_content_use_overlay'] = null;
          $value['para_content_use_overlay'] = ( $value['para_content_use_overlay'] == 1 ? 1 : 0 );
        $value['para_content_overlay_color'] = wp_filter_nohtml_kses( $value['para_content_overlay_color'] );
        $value['para_content_overlay_opacity'] = wp_filter_nohtml_kses( $value['para_content_overlay_opacity'] );
       if ( ! isset( $value['para_content_direction'] ) )
         $value['para_content_direction'] = null;
       if ( ! array_key_exists( $value['para_content_direction'], $content_direction_options ) )
         $value['para_content_direction'] = null;

      //記事一覧 -----------------------------------------------------------------------
      } elseif ($value['cb_content_select'] == 'post_list') {
        $value['post_list_num'] = wp_filter_nohtml_kses( $value['post_list_num'] );
        if ( ! isset( $value['post_list_show_button'] ) )
          $value['post_list_show_button'] = null;
          $value['post_list_show_button'] = ( $value['post_list_show_button'] == 1 ? 1 : 0 );
        $value['post_list_button_label'] = wp_filter_nohtml_kses( $value['post_list_button_label'] );
        $value['post_list_button_bg_color'] = wp_filter_nohtml_kses( $value['post_list_button_bg_color'] );
        $value['post_list_button_font_color'] = wp_filter_nohtml_kses( $value['post_list_button_font_color'] );
        $value['post_list_button_bg_color_hover'] = wp_filter_nohtml_kses( $value['post_list_button_bg_color_hover'] );
        $value['post_list_button_font_color_hover'] = wp_filter_nohtml_kses( $value['post_list_button_font_color_hover'] );

      //カルーセル -----------------------------------------------------------------------
      } elseif ($value['cb_content_select'] == 'carousel') {

        for ( $i = 1; $i <= 6; $i++ ) {
          $value['carousel_image'.$i] = wp_filter_nohtml_kses( $value['carousel_image'.$i] );
          $value['carousel_catch'.$i] = wp_filter_nohtml_kses( $value['carousel_catch'.$i] );
          $value['carousel_title'.$i] = wp_filter_nohtml_kses( $value['carousel_title'.$i] );
          $value['carousel_sub_title'.$i] = wp_filter_nohtml_kses( $value['carousel_sub_title'.$i] );
          $value['carousel_url'.$i] = wp_filter_nohtml_kses( $value['carousel_url'.$i] );
          if ( ! isset( $value['carousel_use_overlay'.$i] ) )
            $value['carousel_use_overlay'.$i] = null;
            $value['carousel_use_overlay'.$i] = ( $value['carousel_use_overlay'.$i] == 1 ? 1 : 0 );
          $value['carousel_overlay_color'.$i] = wp_filter_nohtml_kses( $value['carousel_overlay_color'.$i] );
          $value['carousel_overlay_opacity'.$i] = wp_filter_nohtml_kses( $value['carousel_overlay_opacity'.$i] );
        }
        $value['carousel_catch_font_size'] = wp_filter_nohtml_kses( $value['carousel_catch_font_size'] );
        $value['carousel_title_font_size'] = wp_filter_nohtml_kses( $value['carousel_title_font_size'] );
        $value['carousel_sub_title_font_size'] = wp_filter_nohtml_kses( $value['carousel_sub_title_font_size'] );
        $value['carousel_catch_font_size_mobile'] = wp_filter_nohtml_kses( $value['carousel_catch_font_size_mobile'] );
        $value['carousel_title_font_size_mobile'] = wp_filter_nohtml_kses( $value['carousel_title_font_size_mobile'] );
        $value['carousel_sub_title_font_size_mobile'] = wp_filter_nohtml_kses( $value['carousel_sub_title_font_size_mobile'] );
        $value['carousel_catch_color'] = wp_filter_nohtml_kses( $value['carousel_catch_color'] );

      //自由入力欄 -----------------------------------------------------------------------
      } elseif ($value['cb_content_select'] == 'free_space') {

        if ( ! isset( $value['free_space'] )) {
          $value['free_space'] = null;
        } else {
          $value['free_space'] = $value['free_space'];
        }

      }

      $input['contents_builder'][] = $value;

    }

  } //コンテンツビルダーここまで -----------------------------------------------------------------------

  return $input;

};


/**
 * コンテンツビルダー用 コンテンツ選択プルダウン　■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
 */
function the_cb_content_select($cb_index = 'cb_cloneindex', $selected = null) {

  $options = get_design_plus_option();
  $work_label = $options['work_label'] ? esc_html( $options['work_label'] ) : __( 'Achievement', 'tcd-w' );

	$cb_content_select = array(
		'content1' => __('Content1', 'tcd-w'),
		'content2' => __('Content2', 'tcd-w'),
		'para_content' => __('Parallax content', 'tcd-w'),
		'post_list' => sprintf(__('%s list', 'tcd-w'), $work_label),
		'carousel' => __('Carousel', 'tcd-w'),
		'free_space' => __('Free space', 'tcd-w')
	);

	if ($selected && isset($cb_content_select[$selected])) {
		$add_class = ' hidden';
	} else {
		$add_class = '';
	}

	$out = '<select name="dp_options[contents_builder]['.esc_attr($cb_index).'][cb_content_select]" class="cb_content_select'.$add_class.'">';
	$out .= '<option value="" style="padding-right: 10px;">'.__("Choose the content", "tcd-w").'</option>';

	foreach($cb_content_select as $key => $value) {
		$attr = '';
		if ($key == $selected) {
			$attr = ' selected="selected"';
		}
		$out .= '<option value="'.esc_attr($key).'"'.$attr.' style="padding-right: 10px;">'.esc_html($value).'</option>';
	}

	$out .= '</select>';

	echo $out; 
}

/**
 * コンテンツビルダー用 コンテンツ設定　■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
 */
function the_cb_content_setting($cb_index = 'cb_cloneindex', $cb_content_select = null, $value = array()) {

  global $content_direction_options;
  $options = get_design_plus_option();
  $work_label = $options['work_label'] ? esc_html( $options['work_label'] ) : __( 'Achievement', 'tcd-w' );

?>

<div class="cb_content_wrap cf <?php echo esc_attr($cb_content_select); ?>">

<?php
     // コンテンツ1　-------------------------------------------------------------
     if ($cb_content_select == 'content1') {

       if (!isset($value['content1_catch'])) { $value['content1_catch'] = ''; }
       if (!isset($value['content1_catch_font_size'])) { $value['content1_catch_font_size'] = '30'; }
       if (!isset($value['content1_catch_font_size_mobile'])) { $value['content1_catch_font_size_mobile'] = '20'; }
       if (!isset($value['content1_desc1'])) { $value['content1_desc1'] = ''; }
       if (!isset($value['content1_desc2'])) { $value['content1_desc2'] = ''; }
       if (!isset($value['content1_desc_font_size'])) { $value['content1_desc_font_size'] = '16'; }
       if (!isset($value['content1_desc_font_size_mobile'])) { $value['content1_desc_font_size_mobile'] = '13'; }
       if (!isset($value['content1_show_button'])) { $value['content1_show_button'] = 0; }
       if (!isset($value['content1_button_label'])) { $value['content1_button_label'] = ''; }
       if (!isset($value['content1_button_url'])) { $value['content1_button_url'] = ''; }
       if (!isset($value['content1_button_bg_color'])) { $value['content1_button_bg_color'] = '#000000'; }
       if (!isset($value['content1_button_font_color'])) { $value['content1_button_font_color'] = '#ffffff'; }
       if (!isset($value['content1_button_bg_color_hover'])) { $value['content1_button_bg_color_hover'] = '#333333'; }
       if (!isset($value['content1_button_font_color_hover'])) { $value['content1_button_font_color_hover'] = '#ffffff'; }
       if (!isset($value['content1_image1'])) { $value['content1_image1'] = false; }
       if (!isset($value['content1_image2'])) { $value['content1_image2'] = false; }
       if (!isset($value['content1_image3'])) { $value['content1_image3'] = false; }

?>

  <h3 class="cb_content_headline"><?php _e('Content1', 'tcd-w');  ?></h3>
  <div class="cb_content">

   <h4 class="theme_option_headline2"><?php _e('Catchphrase', 'tcd-w');  ?></h4>
   <textarea class="large-text" cols="50" rows="3" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_catch]"><?php echo esc_textarea(  $value['content1_catch'] ); ?></textarea>

   <h4 class="theme_option_headline2"><?php _e('Description', 'tcd-w');  ?></h4>
   <textarea class="large-text" cols="50" rows="3" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_desc1]"><?php echo esc_textarea(  $value['content1_desc1'] ); ?></textarea>

   <?php for($i = 1; $i <= 3; $i++) : ?>
   <h4 class="theme_option_headline2"><?php printf(__('Image%s', 'tcd-w'), $i); ?></h4>
   <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '300', '300'); ?></p>
   <div class="image_box cf">
    <div class="cf cf_media_field hide-if-no-js content1_image<?php echo $i; ?>">
     <input type="hidden" value="<?php echo esc_attr( $value['content1_image'.$i] ); ?>" id="content1_image<?php echo $i; ?>-<?php echo $cb_index; ?>" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_image<?php echo $i; ?>]" class="cf_media_id">
     <div class="preview_field"><?php if($value['content1_image'.$i]){ echo wp_get_attachment_image($value['content1_image'.$i], 'medium'); }; ?></div>
     <div class="buttton_area">
      <input type="button" value="<?php _e('Select Image', 'tcd-w'); ?>" class="cfmf-select-img button">
      <input type="button" value="<?php _e('Remove Image', 'tcd-w'); ?>" class="cfmf-delete-img button <?php if(!$value['content1_image'.$i]){ echo 'hidden'; }; ?>">
     </div>
    </div>
   </div>
   <?php endfor; ?>

   <h4 class="theme_option_headline2"><?php _e('Description (bottom area)', 'tcd-w');  ?></h4>
   <textarea class="large-text" cols="50" rows="3" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_desc2]"><?php echo esc_textarea(  $value['content1_desc2'] ); ?></textarea>

   <h4 class="theme_option_headline2"><?php _e('Button setting', 'tcd-w');  ?></h4>
   <p class="displayment_checkbox"><label><input name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_show_button]" type="checkbox" value="1" <?php checked( $value['content1_show_button'], 1 ); ?>><?php _e( 'Display button', 'tcd-w' ); ?></label></p>
   <div style="<?php if($value['content1_show_button'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
    <ul class="option_list" style="border-top:1px dotted #ddd; padding:8px 0 0 0;">
     <li class="cf"><span class="label"><?php _e('Label', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_button_label]" value="<?php echo esc_attr( $value['content1_button_label'] ); ?>"></li>
     <li class="cf"><span class="label"><?php _e('URL', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_button_url]" value="<?php echo esc_attr( $value['content1_button_url'] ); ?>"></li>
     <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_button_font_color]" value="<?php echo esc_attr( $value['content1_button_font_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_button_bg_color]" value="<?php echo esc_attr( $value['content1_button_bg_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_button_font_color_hover]" value="<?php echo esc_attr( $value['content1_button_font_color_hover'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Background color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_button_bg_color_hover]" value="<?php echo esc_attr( $value['content1_button_bg_color_hover'] ); ?>" data-default-color="#333333" class="c-color-picker"></li>
    </ul>
   </div>

   <h4 class="theme_option_headline2"><?php _e('Font size setting', 'tcd-w');  ?></h4>
   <ul class="option_list">
    <li class="cf"><span class="label"><?php _e('Catchphrase', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_catch_font_size]" value="<?php esc_attr_e( $value['content1_catch_font_size'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Description', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_desc_font_size]" value="<?php esc_attr_e( $value['content1_desc_font_size'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Catchphrase (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_catch_font_size_mobile]" value="<?php esc_attr_e( $value['content1_catch_font_size_mobile'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Description (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content1_desc_font_size_mobile]" value="<?php esc_attr_e( $value['content1_desc_font_size_mobile'] ); ?>" /><span>px</span></li>
   </ul>

<?php
     // コンテンツ2　-------------------------------------------------------------
     } elseif ($cb_content_select == 'content2') {

       if (!isset($value['content2_catch'])) { $value['content2_catch'] = ''; }
       if (!isset($value['content2_catch_font_size'])) { $value['content2_catch_font_size'] = '30'; }
       if (!isset($value['content2_catch_font_size_mobile'])) { $value['content2_catch_font_size_mobile'] = '20'; }
       if (!isset($value['content2_desc1'])) { $value['content2_desc1'] = ''; }
       if (!isset($value['content2_desc2'])) { $value['content2_desc2'] = ''; }
       if (!isset($value['content2_desc_font_size'])) { $value['content2_desc_font_size'] = '16'; }
       if (!isset($value['content2_desc_font_size_mobile'])) { $value['content2_desc_font_size_mobile'] = '13'; }
       if (!isset($value['content2_show_button1'])) { $value['content2_show_button1'] = 0; }
       if (!isset($value['content2_button1_label'])) { $value['content2_button1_label'] = ''; }
       if (!isset($value['content2_button1_url'])) { $value['content2_button1_url'] = ''; }
       if (!isset($value['content2_button1_bg_color'])) { $value['content2_button1_bg_color'] = '#000000'; }
       if (!isset($value['content2_button1_font_color'])) { $value['content2_button1_font_color'] = '#ffffff'; }
       if (!isset($value['content2_button1_bg_color_hover'])) { $value['content2_button1_bg_color_hover'] = '#333333'; }
       if (!isset($value['content2_button1_font_color_hover'])) { $value['content2_button1_font_color_hover'] = '#ffffff'; }
       if (!isset($value['content2_show_button2'])) { $value['content2_show_button2'] = 0; }
       if (!isset($value['content2_button2_label'])) { $value['content2_button2_label'] = ''; }
       if (!isset($value['content2_button2_url'])) { $value['content2_button2_url'] = ''; }
       if (!isset($value['content2_button2_bg_color'])) { $value['content2_button2_bg_color'] = '#000000'; }
       if (!isset($value['content2_button2_font_color'])) { $value['content2_button2_font_color'] = '#ffffff'; }
       if (!isset($value['content2_button2_bg_color_hover'])) { $value['content2_button2_bg_color_hover'] = '#333333'; }
       if (!isset($value['content2_button2_font_color_hover'])) { $value['content2_button2_font_color_hover'] = '#ffffff'; }
       if (!isset($value['content2_image'])) { $value['content2_image'] = false; }
       if (!isset($value['content2_use_overlay'])) { $value['content2_use_overlay'] = 0; }
       if (!isset($value['content2_overlay_color'])) { $value['content2_overlay_color'] = '#000000'; }
       if (!isset($value['content2_overlay_opacity'])) { $value['content2_overlay_opacity'] = '0.3'; }
       if (!isset($value['content2_catch2'])) { $value['content2_catch2'] = ''; }
       if (!isset($value['content2_catch2_font_size'])) { $value['content2_catch2_font_size'] = '30'; }
       if (!isset($value['content2_catch2_font_size_mobile'])) { $value['content2_catch2_font_size_mobile'] = '20'; }
       if (!isset($value['content2_catch2_color'])) { $value['content2_catch2_color'] = '#ffffff'; }

?>

  <h3 class="cb_content_headline"><?php _e('Content2', 'tcd-w');  ?></h3>
  <div class="cb_content">

   <h4 class="theme_option_headline2"><?php _e('Catchphrase', 'tcd-w');  ?></h4>
   <textarea class="large-text" cols="50" rows="3" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_catch]"><?php echo esc_textarea(  $value['content2_catch'] ); ?></textarea>

   <h4 class="theme_option_headline2"><?php _e('Description', 'tcd-w');  ?></h4>
   <textarea class="large-text" cols="50" rows="3" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_desc1]"><?php echo esc_textarea(  $value['content2_desc1'] ); ?></textarea>

   <h4 class="theme_option_headline2"><?php _e('Image', 'tcd-w');  ?></h4>
   <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '800', '250'); ?></p>
   <div class="image_box cf">
    <div class="cf cf_media_field hide-if-no-js content2_image">
     <input type="hidden" value="<?php echo esc_attr( $value['content2_image'] ); ?>" id="content2_image-<?php echo $cb_index; ?>" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_image]" class="cf_media_id">
     <div class="preview_field"><?php if($value['content2_image']){ echo wp_get_attachment_image($value['content2_image'], 'medium'); }; ?></div>
     <div class="buttton_area">
      <input type="button" value="<?php _e('Select Image', 'tcd-w'); ?>" class="cfmf-select-img button">
      <input type="button" value="<?php _e('Remove Image', 'tcd-w'); ?>" class="cfmf-delete-img button <?php if(!$value['content2_image']){ echo 'hidden'; }; ?>">
     </div>
    </div>
   </div>

   <h4 class="theme_option_headline2"><?php _e( 'Overlay setting', 'tcd-w' ); ?></h4>
   <p class="displayment_checkbox"><label><input name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_use_overlay]" type="checkbox" value="1" <?php checked( $value['content2_use_overlay'], 1 ); ?>><?php _e( 'Use overlay', 'tcd-w' ); ?></label></p>
   <div style="<?php if($value['content2_use_overlay'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
    <ul class="option_list" style="border-top:1px dotted #ddd; padding:8px 0 0 0;">
     <li class="cf"><span class="label"><?php _e('Color of overlay', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_overlay_color]" value="<?php echo esc_attr( $value['content2_overlay_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Transparency of overlay', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_overlay_opacity]" value="<?php echo esc_attr( $value['content2_overlay_opacity'] ); ?>" /><p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p></li>
    </ul>
   </div><!-- END .header_slider_show_overlay -->

   <h4 class="theme_option_headline2"><?php _e('Catchphrase (image area)', 'tcd-w');  ?></h4>
   <textarea class="large-text" cols="50" rows="3" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_catch2]"><?php echo esc_textarea(  $value['content2_catch2'] ); ?></textarea>

   <h4 class="theme_option_headline2"><?php _e('Font color of catchphrase (image area)', 'tcd-w');  ?></h4>
   <input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_catch2_color]" value="<?php echo esc_attr( $value['content2_catch2_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker">

   <h4 class="theme_option_headline2"><?php _e('Button setting (image area)', 'tcd-w');  ?></h4>
   <p class="displayment_checkbox"><label><input name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_show_button1]" type="checkbox" value="1" <?php checked( $value['content2_show_button1'], 1 ); ?>><?php _e( 'Display button', 'tcd-w' ); ?></label></p>
   <div style="<?php if($value['content2_show_button1'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
    <ul class="option_list" style="border-top:1px dotted #ddd; padding:8px 0 0 0;">
     <li class="cf"><span class="label"><?php _e('Label', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button1_label]" value="<?php echo esc_attr( $value['content2_button1_label'] ); ?>"></li>
     <li class="cf"><span class="label"><?php _e('URL', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button1_url]" value="<?php echo esc_attr( $value['content2_button1_url'] ); ?>"></li>
     <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button1_font_color]" value="<?php echo esc_attr( $value['content2_button1_font_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button1_bg_color]" value="<?php echo esc_attr( $value['content2_button1_bg_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button1_font_color_hover]" value="<?php echo esc_attr( $value['content2_button1_font_color_hover'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Background color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button1_bg_color_hover]" value="<?php echo esc_attr( $value['content2_button1_bg_color_hover'] ); ?>" data-default-color="#333333" class="c-color-picker"></li>
    </ul>
   </div>

   <h4 class="theme_option_headline2"><?php _e('Description (bottom area)', 'tcd-w');  ?></h4>
   <textarea class="large-text" cols="50" rows="3" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_desc2]"><?php echo esc_textarea(  $value['content2_desc2'] ); ?></textarea>

   <h4 class="theme_option_headline2"><?php _e('Button setting (bottom area)', 'tcd-w');  ?></h4>
   <p class="displayment_checkbox"><label><input name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_show_button2]" type="checkbox" value="1" <?php checked( $value['content2_show_button2'], 1 ); ?>><?php _e( 'Display button', 'tcd-w' ); ?></label></p>
   <div style="<?php if($value['content2_show_button2'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
    <ul class="option_list" style="border-top:1px dotted #ddd; padding:8px 0 0 0;">
     <li class="cf"><span class="label"><?php _e('Label', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button2_label]" value="<?php echo esc_attr( $value['content2_button2_label'] ); ?>"></li>
     <li class="cf"><span class="label"><?php _e('URL', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button2_url]" value="<?php echo esc_attr( $value['content2_button2_url'] ); ?>"></li>
     <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button2_font_color]" value="<?php echo esc_attr( $value['content2_button2_font_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button2_bg_color]" value="<?php echo esc_attr( $value['content2_button2_bg_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button2_font_color_hover]" value="<?php echo esc_attr( $value['content2_button2_font_color_hover'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Background color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_button2_bg_color_hover]" value="<?php echo esc_attr( $value['content2_button2_bg_color_hover'] ); ?>" data-default-color="#333333" class="c-color-picker"></li>
    </ul>
   </div>

   <h4 class="theme_option_headline2"><?php _e('Font size setting', 'tcd-w');  ?></h4>
   <ul class="option_list">
    <li class="cf"><span class="label"><?php _e('Catchphrase', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_catch_font_size]" value="<?php esc_attr_e( $value['content2_catch_font_size'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Description', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_desc_font_size]" value="<?php esc_attr_e( $value['content2_desc_font_size'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Catchphrase (image area)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_catch2_font_size]" value="<?php esc_attr_e( $value['content2_catch2_font_size'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Catchphrase (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_catch_font_size_mobile]" value="<?php esc_attr_e( $value['content2_catch_font_size_mobile'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Description (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_desc_font_size_mobile]" value="<?php esc_attr_e( $value['content2_desc_font_size_mobile'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Catchphrase (image area for mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][content2_catch2_font_size_mobile]" value="<?php esc_attr_e( $value['content2_catch2_font_size_mobile'] ); ?>" /><span>px</span></li>
   </ul>

<?php
     // パララックスコンテンツ　-------------------------------------------------------------
     } elseif ($cb_content_select == 'para_content') {

       if (!isset($value['para_content_catch'])) { $value['para_content_catch'] = ''; }
       if (!isset($value['para_content_catch_font_size'])) { $value['para_content_catch_font_size'] = '30'; }
       if (!isset($value['para_content_catch_font_size_mobile'])) { $value['para_content_catch_font_size_mobile'] = '20'; }
       if (!isset($value['para_content_desc'])) { $value['para_content_desc'] = ''; }
       if (!isset($value['para_content_desc_font_size'])) { $value['para_content_desc_font_size'] = '16'; }
       if (!isset($value['para_content_desc_font_size_mobile'])) { $value['para_content_desc_font_size_mobile'] = '13'; }
       if (!isset($value['para_content_image'])) { $value['para_content_image'] = false; }
       if (!isset($value['para_content_use_overlay'])) { $value['para_content_use_overlay'] = 0; }
       if (!isset($value['para_content_overlay_color'])) { $value['para_content_overlay_color'] = '#000000'; }
       if (!isset($value['para_content_overlay_opacity'])) { $value['para_content_overlay_opacity'] = '0.3'; }
       if (!isset($value['para_content_direction'])) { $value['para_content_direction'] = 'type2'; }

?>

  <h3 class="cb_content_headline"><?php _e('Parallax content', 'tcd-w');  ?></h3>
  <div class="cb_content">

   <h4 class="theme_option_headline2"><?php _e('Catchphrase', 'tcd-w');  ?></h4>
   <textarea class="large-text" cols="50" rows="3" name="dp_options[contents_builder][<?php echo $cb_index; ?>][para_content_catch]"><?php echo esc_textarea(  $value['para_content_catch'] ); ?></textarea>

   <h4 class="theme_option_headline2"><?php _e('Description', 'tcd-w');  ?></h4>
   <textarea class="large-text" cols="50" rows="3" name="dp_options[contents_builder][<?php echo $cb_index; ?>][para_content_desc]"><?php echo esc_textarea(  $value['para_content_desc'] ); ?></textarea>

   <h4 class="theme_option_headline2"><?php _e('Image', 'tcd-w');  ?></h4>
   <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '1450', '1000'); ?></p>
   <div class="image_box cf">
    <div class="cf cf_media_field hide-if-no-js para_content_image">
     <input type="hidden" value="<?php echo esc_attr( $value['para_content_image'] ); ?>" id="para_content_image-<?php echo $cb_index; ?>" name="dp_options[contents_builder][<?php echo $cb_index; ?>][para_content_image]" class="cf_media_id">
     <div class="preview_field"><?php if($value['para_content_image']){ echo wp_get_attachment_image($value['para_content_image'], 'medium'); }; ?></div>
     <div class="buttton_area">
      <input type="button" value="<?php _e('Select Image', 'tcd-w'); ?>" class="cfmf-select-img button">
      <input type="button" value="<?php _e('Remove Image', 'tcd-w'); ?>" class="cfmf-delete-img button <?php if(!$value['para_content_image']){ echo 'hidden'; }; ?>">
     </div>
    </div>
   </div>

   <h4 class="theme_option_headline2"><?php _e( 'Overlay setting', 'tcd-w' ); ?></h4>
   <p class="displayment_checkbox"><label><input name="dp_options[contents_builder][<?php echo $cb_index; ?>][para_content_use_overlay]" type="checkbox" value="1" <?php checked( $value['para_content_use_overlay'], 1 ); ?>><?php _e( 'Use overlay', 'tcd-w' ); ?></label></p>
   <div style="<?php if($value['para_content_use_overlay'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
    <ul class="option_list" style="border-top:1px dotted #ddd; padding:8px 0 0 0;">
     <li class="cf"><span class="label"><?php _e('Color of overlay', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][para_content_overlay_color]" value="<?php echo esc_attr( $value['para_content_overlay_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Transparency of overlay', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[contents_builder][<?php echo $cb_index; ?>][para_content_overlay_opacity]" value="<?php echo esc_attr( $value['para_content_overlay_opacity'] ); ?>" /><p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p></li>
    </ul>
   </div><!-- END .header_slider_show_overlay -->

   <h4 class="theme_option_headline2"><?php _e('Font size setting', 'tcd-w');  ?></h4>
   <ul class="option_list">
    <li class="cf"><span class="label"><?php _e('Catchphrase', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][para_content_catch_font_size]" value="<?php esc_attr_e( $value['para_content_catch_font_size'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Description', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][para_content_desc_font_size]" value="<?php esc_attr_e( $value['para_content_desc_font_size'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Catchphrase (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][para_content_catch_font_size_mobile]" value="<?php esc_attr_e( $value['para_content_catch_font_size_mobile'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Description (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][para_content_desc_font_size_mobile]" value="<?php esc_attr_e( $value['para_content_desc_font_size_mobile'] ); ?>" /><span>px</span></li>
   </ul>

   <h4 class="theme_option_headline2"><?php _e('Direction of content', 'tcd-w');  ?></h4>
   <ul class="design_radio_button">
    <?php foreach ( $content_direction_options as $option ) { ?>
    <li>
     <input type="radio" id="para_content_direction<?php echo $cb_index . '_' . esc_attr($option['value']); ?>" name="dp_options[contents_builder][<?php echo $cb_index; ?>][para_content_direction]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $value['para_content_direction'], $option['value'] ); ?> />
     <label for="para_content_direction<?php echo $cb_index . '_' . esc_attr($option['value']); ?>"><?php echo $option['label']; ?></label>
    </li>
    <?php } ?>
   </ul>

<?php
     // 実績一覧　-------------------------------------------------------------
     } elseif ($cb_content_select == 'post_list') {

       if (!isset($value['post_list_num'])) { $value['post_list_num'] = 9; }
       if (!isset($value['post_list_show_button'])) { $value['post_list_show_button'] = 1; }
       if (!isset($value['post_list_button_label'])) { $value['post_list_button_label'] = 'WORKS'; }
       if (!isset($value['post_list_button_bg_color'])) { $value['post_list_button_bg_color'] = '#000000'; }
       if (!isset($value['post_list_button_font_color'])) { $value['post_list_button_font_color'] = '#ffffff'; }
       if (!isset($value['post_list_button_bg_color_hover'])) { $value['post_list_button_bg_color_hover'] = '#666666'; }
       if (!isset($value['post_list_button_font_color_hover'])) { $value['post_list_button_font_color_hover'] = '#ffffff'; }
?>

  <h3 class="cb_content_headline"><?php printf(__('%s list', 'tcd-w'), $work_label); ?></h3>
  <div class="cb_content">

   <div class="theme_option_message2" style="margin-top:20px;">
    <p><?php printf(__('You can change the font size and color from "%s list setting" in "%s menu".', 'tcd-w'), $work_label, $work_label); ?></p>
   </div>

   <h4 class="theme_option_headline2"><?php _e('Number of post', 'tcd-w');  ?></h4>
   <select name="dp_options[contents_builder][<?php echo $cb_index; ?>][post_list_num]">
    <?php for($i=3; $i<= 15; $i++): ?>
    <?php if( $i % 3 == 0 ){ ?>
    <option style="padding-right: 10px;" value="<?php echo esc_attr($i); ?>" <?php selected( $value['post_list_num'], $i ); ?>><?php echo esc_html($i); ?></option>
    <?php }; ?>
    <?php endfor; ?>
   </select>

   <h4 class="theme_option_headline2"><?php _e('Button setting', 'tcd-w');  ?></h4>
   <p class="displayment_checkbox"><label><input name="dp_options[contents_builder][<?php echo $cb_index; ?>][post_list_show_button]" type="checkbox" value="1" <?php checked( $value['post_list_show_button'], 1 ); ?>><?php _e( 'Display button', 'tcd-w' ); ?></label></p>
   <div style="<?php if($value['post_list_show_button'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
    <ul class="option_list" style="border-top:1px dotted #ddd; padding:8px 0 0 0;">
     <li class="cf"><span class="label"><?php _e('Label', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][post_list_button_label]" value="<?php echo esc_attr( $value['post_list_button_label'] ); ?>"></li>
     <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][post_list_button_font_color]" value="<?php echo esc_attr( $value['post_list_button_font_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
     <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][post_list_button_bg_color]" value="<?php echo esc_attr( $value['post_list_button_bg_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
     <li class="cf color_picker_bottom"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][post_list_button_font_color_hover]" value="<?php echo esc_attr( $value['post_list_button_font_color_hover'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
     <li class="cf color_picker_bottom"><span class="label"><?php _e('Background color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][post_list_button_bg_color_hover]" value="<?php echo esc_attr( $value['post_list_button_bg_color_hover'] ); ?>" data-default-color="#666666" class="c-color-picker"></li>
    </ul>
   </div>

<?php
     // カルーセル　-------------------------------------------------------------
     } elseif ($cb_content_select == 'carousel') {

       for ( $i = 1; $i <= 6; $i++ ) {
         if (!isset($value['carousel_image'.$i])) { $value['carousel_image'.$i] = false; }
         if (!isset($value['carousel_catch'.$i])) { $value['carousel_catch'.$i] = ''; }
         if (!isset($value['carousel_title'.$i])) { $value['carousel_title'.$i] = ''; }
         if (!isset($value['carousel_sub_title'.$i])) { $value['carousel_sub_title'.$i] = ''; }
         if (!isset($value['carousel_url'.$i])) { $value['carousel_url'.$i] = ''; }
         if (!isset($value['carousel_use_overlay'.$i])) { $value['carousel_use_overlay'.$i] = 0; }
         if (!isset($value['carousel_overlay_color'.$i])) { $value['carousel_overlay_color'.$i] = '#000000'; }
         if (!isset($value['carousel_overlay_opacity'.$i])) { $value['carousel_overlay_opacity'.$i] = '0.3'; }
       }
       if (!isset($value['carousel_catch_font_size'])) { $value['carousel_catch_font_size'] = '20'; }
       if (!isset($value['carousel_title_font_size'])) { $value['carousel_title_font_size'] = '20'; }
       if (!isset($value['carousel_sub_title_font_size'])) { $value['carousel_sub_title_font_size'] = '14'; }
       if (!isset($value['carousel_catch_font_size_mobile'])) { $value['carousel_catch_font_size_mobile'] = '16'; }
       if (!isset($value['carousel_title_font_size_mobile'])) { $value['carousel_title_font_size_mobile'] = '16'; }
       if (!isset($value['carousel_sub_title_font_size_mobile'])) { $value['carousel_sub_title_font_size_mobile'] = '11'; }
       if (!isset($value['carousel_catch_color'])) { $value['carousel_catch_color'] = '#FFFFFF'; }

?>

  <h3 class="cb_content_headline"><?php _e('Carousel', 'tcd-w'); ?></h3>
  <div class="cb_content">

   <h4 class="theme_option_headline2"><?php _e('Item setting', 'tcd-w');  ?></h4>
   <?php for($i = 1; $i <= 6; $i++) : ?>
   <div class="sub_box cf">
    <h3 class="theme_option_subbox_headline"><?php printf(__('Item%s', 'tcd-w'), $i); ?></h3>
    <div class="sub_box_content">
     <h4 class="theme_option_headline2"><?php _e('Catchphrase', 'tcd-w');  ?></h4>
     <textarea class="large-text" cols="50" rows="3" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_catch<?php echo $i; ?>]"><?php echo esc_textarea(  $value['carousel_catch'.$i] ); ?></textarea>
     <h4 class="theme_option_headline2"><?php _e('Title', 'tcd-w');  ?></h4>
     <input type="text" style="width:100%;" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_title<?php echo $i; ?>]" value="<?php echo esc_attr( $value['carousel_title'.$i] ); ?>">
     <h4 class="theme_option_headline2"><?php _e('Sub title', 'tcd-w');  ?></h4>
     <input type="text" style="width:100%;" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_sub_title<?php echo $i; ?>]" value="<?php echo esc_attr( $value['carousel_sub_title'.$i] ); ?>">
     <h4 class="theme_option_headline2"><?php _e('URL', 'tcd-w');  ?></h4>
     <input type="text" style="width:100%;" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_url<?php echo $i; ?>]" value="<?php echo esc_attr( $value['carousel_url'.$i] ); ?>">
     <h4 class="theme_option_headline2"><?php _e('Image', 'tcd-w');  ?></h4>
     <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '520', '520'); ?></p>
     <div class="image_box cf">
      <div class="cf cf_media_field hide-if-no-js carousel_image<?php echo $i; ?>">
       <input type="hidden" value="<?php echo esc_attr( $value['carousel_image'.$i] ); ?>" id="carousel_image-<?php echo $cb_index; ?>-<?php echo $i; ?>" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_image<?php echo $i; ?>]" class="cf_media_id">
       <div class="preview_field"><?php if($value['carousel_image'.$i]){ echo wp_get_attachment_image($value['carousel_image'.$i], 'medium'); }; ?></div>
       <div class="buttton_area">
        <input type="button" value="<?php _e('Select Image', 'tcd-w'); ?>" class="cfmf-select-img button">
        <input type="button" value="<?php _e('Remove Image', 'tcd-w'); ?>" class="cfmf-delete-img button <?php if(!$value['carousel_image'.$i]){ echo 'hidden'; }; ?>">
       </div>
      </div>
     </div>
     <h4 class="theme_option_headline2"><?php _e( 'Overlay setting', 'tcd-w' ); ?></h4>
     <p class="displayment_checkbox"><label><input name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_use_overlay<?php echo $i; ?>]" type="checkbox" value="1" <?php checked( $value['carousel_use_overlay'.$i], 1 ); ?>><?php _e( 'Use overlay', 'tcd-w' ); ?></label></p>
     <div style="<?php if($value['carousel_use_overlay'.$i] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
      <ul class="option_list" style="border-top:1px dotted #ddd; padding:8px 0 0 0;">
       <li class="cf"><span class="label"><?php _e('Color of overlay', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_overlay_color<?php echo $i; ?>]" value="<?php echo esc_attr( $value['carousel_overlay_color'.$i] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php _e('Transparency of overlay', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_overlay_opacity<?php echo $i; ?>]" value="<?php echo esc_attr( $value['carousel_overlay_opacity'.$i] ); ?>" /><p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p></li>
      </ul>
     </div><!-- END .header_slider_show_overlay -->
     <ul class="button_list cf">
      <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
      <li><a class="close_sub_box button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
     </ul>
    </div><!-- END .sub_box_content -->
   </div><!-- END .sub_box -->
   <?php endfor; ?>

   <h4 class="theme_option_headline2"><?php _e('Font setting', 'tcd-w');  ?></h4>
   <ul class="option_list">
    <li class="cf"><span class="label"><?php _e('Catchphrase', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_catch_font_size]" value="<?php esc_attr_e( $value['carousel_catch_font_size'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Title', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_title_font_size]" value="<?php esc_attr_e( $value['carousel_title_font_size'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Sub title', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_sub_title_font_size]" value="<?php esc_attr_e( $value['carousel_sub_title_font_size'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Catchphrase (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_catch_font_size_mobile]" value="<?php esc_attr_e( $value['carousel_catch_font_size_mobile'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Title (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_title_font_size_mobile]" value="<?php esc_attr_e( $value['carousel_title_font_size_mobile'] ); ?>" /><span>px</span></li>
    <li class="cf"><span class="label"><?php _e('Sub title (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_sub_title_font_size_mobile]" value="<?php esc_attr_e( $value['carousel_sub_title_font_size_mobile'] ); ?>" /><span>px</span></li>
    <li class="cf color_picker_bottom"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[contents_builder][<?php echo $cb_index; ?>][carousel_catch_color]" value="<?php echo esc_attr( $value['carousel_catch_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
   </ul>

<?php
     // 自由入力欄　-------------------------------------------------------------
     } elseif ($cb_content_select == 'free_space') {

       if (!isset($value['free_space'])) {
         $value['free_space'] = '';
       }
?>
  <h3 class="cb_content_headline"><?php _e('Free space', 'tcd-w');  ?></h3>
  <div class="cb_content">

   <h4 class="theme_option_headline2"><?php _e('Free space', 'tcd-w');  ?></h4>
   <?php
        wp_editor(
          $value['free_space'],
          'cb_wysiwyg_editor-' . $cb_index,
          array (
            'textarea_name' => 'dp_options[contents_builder][' . $cb_index . '][free_space]'
          )
       );
   ?>

<?php
     // ボタンの表示　-------------------------------------------------------------
     } else {
?>
  <h3 class="cb_content_headline"><?php echo esc_html($cb_content_select); ?></h3>
  <div class="cb_content">

<?php
     }
?>

   <ul class="button_list cf">
    <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
    <li><a href="#" class="button-ml close-content"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
   </ul>

  </div><!-- END .cb_content -->

</div><!-- END .cb_content_wrap -->

<?php

} // END the_cb_content_setting()

/**
 * クローン用のリッチエディター化処理をしないようにする
 * クローン後のリッチエディター化はjsで行う
 */
function cb_tiny_mce_before_init( $mceInit, $editor_id ) {
	if ( strpos( $editor_id, 'cb_cloneindex' ) !== false ) {
		$mceInit['wp_skip_init'] = true;
	}
	return $mceInit;
}
add_filter( 'tiny_mce_before_init', 'cb_tiny_mce_before_init', 10, 2 );

?>