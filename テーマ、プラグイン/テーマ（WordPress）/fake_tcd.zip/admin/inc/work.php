<?php
/*
 * 実績の設定
 */


// Add default values
add_filter( 'before_getting_design_plus_option', 'add_work_dp_default_options' );


//  Add label of work tab
add_action( 'tcd_tab_labels', 'add_work_tab_label' );


// Add HTML of work tab
add_action( 'tcd_tab_panel', 'add_work_tab_panel' );


// Register sanitize function
add_filter( 'theme_options_validate', 'add_work_theme_options_validate' );


// タブの名前
function add_work_tab_label( $tab_labels ) {
  $options = get_design_plus_option();
  $tab_label = $options['work_label'] ? esc_html( $options['work_label'] ) : __( 'Achievement', 'tcd-w' );
  $tab_labels['work'] = $tab_label;
	return $tab_labels;
}


// 初期値
function add_work_dp_default_options( $dp_default_options ) {

	// 基本設定
	$dp_default_options['work_label'] = __( 'Achievement', 'tcd-w' );
	$dp_default_options['work_category_font_color'] = '#FFFFFF';
	$dp_default_options['work_category_bg_color'] = '#000000';
	$dp_default_options['work_category_font_color_hover'] = '#FFFFFF';
	$dp_default_options['work_category_bg_color_hover'] = '#999999';
	$dp_default_options['work_slug'] = 'work';
	$dp_default_options['landmark_label'] = __( 'Landmark', 'tcd-w' );
	$dp_default_options['landmark_slug'] = 'landmark';
	$dp_default_options['area_label'] = __( 'Area', 'tcd-w' );
	$dp_default_options['area_slug'] = 'area';

	// ヘッダー
	$dp_default_options['work_catch'] = __( 'Catchprase will be displayed here.', 'tcd-w' );
	$dp_default_options['work_desc'] = __( 'Description will be displayed here.<br />Description will be displayed here.', 'tcd-w' );
	$dp_default_options['work_catch_font_size'] = '42';
	$dp_default_options['work_catch_font_size_mobile'] = '22';
	$dp_default_options['work_desc_font_size'] = '16';
	$dp_default_options['work_desc_font_size_mobile'] = '14';
	$dp_default_options['work_catch_color'] = '#FFFFFF';
	$dp_default_options['work_desc_color'] = '#FFFFFF';
	$dp_default_options['work_bg_color'] = '#000000';
	$dp_default_options['work_bg_image'] = false;
	$dp_default_options['work_bg_image_mobile'] = false;
	$dp_default_options['work_use_overlay'] = 1;
	$dp_default_options['work_overlay_color'] = '#000000';
	$dp_default_options['work_overlay_opacity'] = '0.3';

	// アーカイブページ
	$dp_default_options['archive_work_headline_font_size'] = '30';
	$dp_default_options['archive_work_headline_font_size_mobile'] = '20';
	$dp_default_options['archive_work_desc_font_size'] = '16';
	$dp_default_options['archive_work_desc_font_size_mobile'] = '13';
	$dp_default_options['show_archive_work_tab'] = 1;
	$dp_default_options['archive_work_tab_font_size'] = '14';
	$dp_default_options['archive_work_tab_font_size_mobile'] = '12';
	$dp_default_options['archive_work_tab_font_color'] = '#000000';
	$dp_default_options['archive_work_tab_bg_color'] = '#ffffff';
	$dp_default_options['archive_work_tab_bg_opacity'] = '0.7';
	$dp_default_options['archive_work_tab_bg_blur'] = '3';
	$dp_default_options['archive_work_tab_font_color_hover'] = '#ffffff';
	$dp_default_options['archive_work_tab_bg_color_hover'] = '#333333';
	$dp_default_options['archive_work_tab_bg_color_active'] = '#000000';
	$dp_default_options['show_archive_work_button'] = 1;
	$dp_default_options['archive_work_button_font_size'] = '16';
	$dp_default_options['archive_work_button_font_size_mobile'] = '14';
	$dp_default_options['archive_work_button_font_color'] = '#000000';
	$dp_default_options['archive_work_button_bg_color'] = '#ffffff';
	$dp_default_options['archive_work_button_font_color_hover'] = '#ffffff';
	$dp_default_options['archive_work_button_bg_color_hover'] = '#a33f37';
	$dp_default_options['archive_work_button_label'] = __( 'Select the category', 'tcd-w' );
	$dp_default_options['archive_work_list_animation_type'] = 'type1';

	// 実績一覧
	$dp_default_options['work_list_title_font_size'] = '16';
	$dp_default_options['work_list_title_font_size_mobile'] = '14';
	$dp_default_options['show_work_list_category'] = 1;
	$dp_default_options['work_list_category_font_size'] = '14';
	$dp_default_options['work_list_category_font_size_mobile'] = '12';
	$dp_default_options['work_list_category_font_color'] = '#ffffff';
	$dp_default_options['work_list_category_bg_color'] = '#000000';
	$dp_default_options['work_list_caetgory_opacity'] = '0.7';

	// 記事ページ
	$dp_default_options['single_work_title_font_size'] = '32';
	$dp_default_options['single_work_content_font_size'] = '16';
	$dp_default_options['single_work_title_font_size_mobile'] = '20';
	$dp_default_options['single_work_content_font_size_mobile'] = '14';
	$dp_default_options['show_work_category'] = 1;
	$dp_default_options['show_work_nav'] = 1;

	// 関連記事
	$dp_default_options['show_related_work'] = 1;
	$dp_default_options['related_work_headline_font_size'] = '22';
	$dp_default_options['related_work_headline_font_size_mobile'] = '16';
	$dp_default_options['related_work_post_num'] = '6';


	return $dp_default_options;

}


// 入力欄の出力　■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
function add_work_tab_panel( $options ) {

  global $dp_default_options, $pagenation_type_options, $work_list_animation_type_options;
  $work_label = $options['work_label'] ? esc_html( $options['work_label'] ) : __( 'Achievement', 'tcd-w' );
  $landmark_label = $options['landmark_label'] ? esc_html( $options['landmark_label'] ) : __( 'Landmark', 'tcd-w' );
  $area_label = $options['area_label'] ? esc_html( $options['area_label'] ) : __( 'Area', 'tcd-w' );

?>

<div id="tab-content-work" class="tab-content">

   <?php // 基本設定 -------------------------------------------------------------------------------------------- ?>
   <div class="theme_option_field cf theme_option_field_ac">
    <h3 class="theme_option_headline"><?php _e('Basic setting', 'tcd-w');  ?></h3>
    <div class="theme_option_field_ac_content">
     <h4 class="theme_option_headline2"><?php _e('Name of content', 'tcd-w');  ?></h4>
     <div class="theme_option_message2">
      <p><?php _e('This name will also be used in breadcrumb link and page header.', 'tcd-w'); ?></p>
     </div>
     <input class="regular-text" type="text" name="dp_options[work_label]" value="<?php echo esc_attr( $options['work_label'] ); ?>" />
     <h4 class="theme_option_headline2"><?php _e('Slug setting', 'tcd-w');  ?></h4>
     <div class="theme_option_message2">
      <p><?php _e('Please enter word by alphabet only.<br />After changing slug, please update permalink setting form <a href="./options-permalink.php"><strong>permalink option page</strong></a>.', 'tcd-w'); ?></p>
     </div>
     <p><input class="hankaku regular-text" type="text" name="dp_options[work_slug]" value="<?php echo sanitize_title( $options['work_slug'] ); ?>" /></p>
     <h4 class="theme_option_headline2"><?php printf(__('%s category setting', 'tcd-w'), $landmark_label); ?></h4>
     <div class="theme_option_message2">
      <p><?php _e('Please enter word by alphabet only.<br />After changing slug, please update permalink setting form <a href="./options-permalink.php"><strong>permalink option page</strong></a>.', 'tcd-w'); ?></p>
     </div>
     <ul class="option_list">
      <li class="cf"><span class="label"><?php _e('Name', 'tcd-w'); ?></span><input type="text" name="dp_options[landmark_label]" value="<?php esc_attr_e( $options['landmark_label'] ); ?>" /></li>
      <li class="cf"><span class="label"><?php _e('Slug', 'tcd-w'); ?></span><input type="text" name="dp_options[landmark_slug]" value="<?php echo sanitize_title( $options['landmark_slug'] ); ?>" /></li>
     </ul>
     <h4 class="theme_option_headline2"><?php printf(__('%s category setting', 'tcd-w'), $area_label); ?></h4>
     <div class="theme_option_message2">
      <p><?php _e('Please enter word by alphabet only.<br />After changing slug, please update permalink setting form <a href="./options-permalink.php"><strong>permalink option page</strong></a>.', 'tcd-w'); ?></p>
     </div>
     <ul class="option_list">
      <li class="cf"><span class="label"><?php _e('Name', 'tcd-w'); ?></span><input type="text" name="dp_options[area_label]" value="<?php esc_attr_e( $options['area_label'] ); ?>" /></li>
      <li class="cf"><span class="label"><?php _e('Slug', 'tcd-w'); ?></span><input type="text" name="dp_options[area_slug]" value="<?php echo sanitize_title( $options['area_slug'] ); ?>" /></li>
     </ul>
     <ul class="button_list cf">
      <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
      <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
     </ul>
    </div><!-- END .theme_option_field_ac_content -->
   </div><!-- END .theme_option_field -->

   <?php // ヘッダーの設定 ----------------------------------------- ?>
   <div class="theme_option_field cf theme_option_field_ac">
    <h3 class="theme_option_headline"><?php _e('Header setting', 'tcd-w');  ?></h3>
    <div class="theme_option_field_ac_content">
     <h4 class="theme_option_headline2"><?php _e('Catchphrase', 'tcd-w');  ?></h4>
     <textarea class="large-text" cols="50" rows="2" name="dp_options[work_catch]"><?php echo esc_textarea(  $options['work_catch'] ); ?></textarea>
     <h4 class="theme_option_headline2"><?php _e('Description', 'tcd-w');  ?></h4>
     <textarea class="large-text" cols="50" rows="3" name="dp_options[work_desc]"><?php echo esc_textarea(  $options['work_desc'] ); ?></textarea>
     <h4 class="theme_option_headline2"><?php _e('Font size setting', 'tcd-w');  ?></h4>
     <ul class="option_list">
      <li class="cf"><span class="label"><?php _e('Catchphrase', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[work_catch_font_size]" value="<?php esc_attr_e( $options['work_catch_font_size'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Description', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[work_desc_font_size]" value="<?php esc_attr_e( $options['work_desc_font_size'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Catchphrase (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[work_catch_font_size_mobile]" value="<?php esc_attr_e( $options['work_catch_font_size_mobile'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Description (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[work_desc_font_size_mobile]" value="<?php esc_attr_e( $options['work_desc_font_size_mobile'] ); ?>" /><span>px</span></li>
     </ul>
     <h4 class="theme_option_headline2"><?php _e('Color setting', 'tcd-w');  ?></h4>
     <div class="theme_option_message2">
      <p><?php _e('Background color will be used if background image is not registered.', 'tcd-w'); ?></p>
     </div>
     <ul class="color_field">
      <li class="cf"><span class="label"><?php _e('Font color of catchphrase', 'tcd-w'); ?></span><input type="text" name="dp_options[work_catch_color]" value="<?php echo esc_attr( $options['work_catch_color'] ); ?>" data-default-color="#ffffff" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Font color of description', 'tcd-w'); ?></span><input type="text" name="dp_options[work_desc_color]" value="<?php echo esc_attr( $options['work_desc_color'] ); ?>" data-default-color="#ffffff" class="c-color-picker"></li>
      <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[work_bg_color]" value="<?php echo esc_attr( $options['work_bg_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
     </ul>
     <h4 class="theme_option_headline2"><?php _e('Background image', 'tcd-w'); ?></h4>
     <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '1450', '650'); ?></p>
     <div class="image_box cf">
      <div class="cf cf_media_field hide-if-no-js work_bg_image">
       <input type="hidden" value="<?php echo esc_attr( $options['work_bg_image'] ); ?>" id="work_bg_image" name="dp_options[work_bg_image]" class="cf_media_id">
       <div class="preview_field"><?php if($options['work_bg_image']){ echo wp_get_attachment_image($options['work_bg_image'], 'medium'); }; ?></div>
       <div class="buttton_area">
        <input type="button" value="<?php _e('Select Image', 'tcd-w'); ?>" class="cfmf-select-img button">
        <input type="button" value="<?php _e('Remove Image', 'tcd-w'); ?>" class="cfmf-delete-img button <?php if(!$options['work_bg_image']){ echo 'hidden'; }; ?>">
       </div>
      </div>
     </div>
     <h4 class="theme_option_headline2"><?php _e('Background image (mobile)', 'tcd-w'); ?></h4>
     <p><?php printf(__('Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w'), '550', '300'); ?></p>
     <div class="image_box cf">
      <div class="cf cf_media_field hide-if-no-js work_bg_image_mobile">
       <input type="hidden" value="<?php echo esc_attr( $options['work_bg_image_mobile'] ); ?>" id="work_bg_image_mobile" name="dp_options[work_bg_image_mobile]" class="cf_media_id">
       <div class="preview_field"><?php if($options['work_bg_image_mobile']){ echo wp_get_attachment_image($options['work_bg_image_mobile'], 'medium'); }; ?></div>
       <div class="buttton_area">
        <input type="button" value="<?php _e('Select Image', 'tcd-w'); ?>" class="cfmf-select-img button">
        <input type="button" value="<?php _e('Remove Image', 'tcd-w'); ?>" class="cfmf-delete-img button <?php if(!$options['work_bg_image_mobile']){ echo 'hidden'; }; ?>">
       </div>
      </div>
     </div>
     <h4 class="theme_option_headline2"><?php _e( 'Overlay setting', 'tcd-w' ); ?></h4>
     <p class="displayment_checkbox"><label><input name="dp_options[work_use_overlay]" type="checkbox" value="1" <?php checked( $options['work_use_overlay'], 1 ); ?>><?php _e( 'Use overlay', 'tcd-w' ); ?></label></p>
     <div class="work_show_overlay" style="<?php if($options['work_use_overlay'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
      <ul class="color_field" style="border-top:1px dotted #ccc; padding-top:12px;">
       <li class="cf"><span class="label"><?php _e('Color of overlay', 'tcd-w'); ?></span><input type="text" name="dp_options[work_overlay_color]" value="<?php echo esc_attr( $options['work_overlay_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
       <li class="cf">
        <span class="label"><?php _e('Transparency of overlay', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[work_overlay_opacity]" value="<?php echo esc_attr( $options['work_overlay_opacity'] ); ?>" />
        <div class="theme_option_message2" style="clear:both; margin:7px 0 0 0;">
         <p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p>
        </div>
       </li>
      </ul>
     </div>
     <ul class="button_list cf">
      <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
      <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
     </ul>
    </div><!-- END .theme_option_field_ac_content -->
   </div><!-- END .theme_option_field -->

   <?php // アーカイブページの設定 ----------------------------------------- ?>
   <div class="theme_option_field cf theme_option_field_ac">
    <h3 class="theme_option_headline"><?php _e('Archive page setting', 'tcd-w'); ?></h3>
    <div class="theme_option_field_ac_content">
     <h4 class="theme_option_headline2"><?php printf(__('%s tab setting', 'tcd-w'), $landmark_label); ?></h4>
     <p class="displayment_checkbox"><label><input name="dp_options[show_archive_work_tab]" type="checkbox" value="1" <?php checked( $options['show_archive_work_tab'], 1 ); ?>><?php _e( 'Display tab', 'tcd-w' ); ?></label></p>
     <div style="<?php if($options['show_archive_work_tab'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
      <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
       <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[archive_work_tab_font_size]" value="<?php esc_attr_e( $options['archive_work_tab_font_size'] ); ?>" /><span>px</span></li>
       <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[archive_work_tab_font_size_mobile]" value="<?php esc_attr_e( $options['archive_work_tab_font_size_mobile'] ); ?>" /><span>px</span></li>
       <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[archive_work_tab_font_color]" value="<?php echo esc_attr( $options['archive_work_tab_font_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[archive_work_tab_bg_color]" value="<?php echo esc_attr( $options['archive_work_tab_bg_color'] ); ?>" data-default-color="#ffffff" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[archive_work_tab_font_color_hover]" value="<?php echo esc_attr( $options['archive_work_tab_font_color_hover'] ); ?>" data-default-color="#ffffff" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php _e('Background color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[archive_work_tab_bg_color_hover]" value="<?php echo esc_attr( $options['archive_work_tab_bg_color_hover'] ); ?>" data-default-color="#333333" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php _e('Active background color', 'tcd-w'); ?></span><input type="text" name="dp_options[archive_work_tab_bg_color_active]" value="<?php echo esc_attr( $options['archive_work_tab_bg_color_active'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
       <li class="cf">
        <span class="label"><?php _e('Transparency of background', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[archive_work_tab_bg_opacity]" value="<?php echo esc_attr( $options['archive_work_tab_bg_opacity'] ); ?>" />
        <div class="theme_option_message2" style="clear:both; margin:7px 0 0 0;">
         <p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p>
        </div>
       </li>
       <li class="cf">
        <span class="label"><?php _e('Strenth of background blur effect', 'tcd-w'); ?></span><input class="hankaku" style="width:70px;" type="number" max="10" min="0" step="1" name="dp_options[archive_work_tab_bg_blur]" value="<?php echo esc_attr( $options['archive_work_tab_bg_blur'] ); ?>" />
        <div class="theme_option_message2" style="clear:both; margin:7px 0 0 0;">
         <p><?php _e('Please specify the number of 1 from 10. Blur effect will be stronger as the number is large.', 'tcd-w');  ?></p>
        </div>
       </li>
      </ul>
     </div>
     <h4 class="theme_option_headline2"><?php printf(__('%s sort button setting', 'tcd-w'), $area_label); ?></h4>
     <p class="displayment_checkbox"><label><input name="dp_options[show_archive_work_button]" type="checkbox" value="1" <?php checked( $options['show_archive_work_button'], 1 ); ?>><?php _e( 'Display sort button', 'tcd-w' ); ?></label></p>
     <div style="<?php if($options['show_archive_work_button'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
      <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
       <li class="cf"><span class="label"><?php _e('label', 'tcd-w'); ?></span><input class="full_width" type="text" name="dp_options[archive_work_button_label]" value="<?php echo esc_attr( $options['archive_work_button_label'] ); ?>" /></li>
       <li class="cf"><span class="label"><?php _e('Font size', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[archive_work_button_font_size]" value="<?php esc_attr_e( $options['archive_work_button_font_size'] ); ?>" /><span>px</span></li>
       <li class="cf"><span class="label"><?php _e('Font size (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[archive_work_button_font_size_mobile]" value="<?php esc_attr_e( $options['archive_work_button_font_size_mobile'] ); ?>" /><span>px</span></li>
       <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[archive_work_button_font_color]" value="<?php echo esc_attr( $options['archive_work_button_font_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[archive_work_button_bg_color]" value="<?php echo esc_attr( $options['archive_work_button_bg_color'] ); ?>" data-default-color="#ffffff" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[archive_work_button_font_color_hover]" value="<?php echo esc_attr( $options['archive_work_button_font_color_hover'] ); ?>" data-default-color="#ffffff" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php _e('Background color on mouseover', 'tcd-w'); ?></span><input type="text" name="dp_options[archive_work_button_bg_color_hover]" value="<?php echo esc_attr( $options['archive_work_button_bg_color_hover'] ); ?>" data-default-color="#a33f37" class="c-color-picker"></li>
      </ul>
     </div>
     <h4 class="theme_option_headline2"><?php printf(__('%s list animation setting', 'tcd-w'), $work_label); ?></h4>
     <ul class="design_radio_button" style="margin-bottom:40px;">
      <?php foreach ( $work_list_animation_type_options as $option ) { ?>
      <li>
       <input type="radio" id="archive_work_list_animation_type_<?php esc_attr_e( $option['value'] ); ?>" name="dp_options[archive_work_list_animation_type]" value="<?php esc_attr_e( $option['value'] ); ?>" <?php checked( $options['archive_work_list_animation_type'], $option['value'] ); ?> />
       <label for="archive_work_list_animation_type_<?php esc_attr_e( $option['value'] ); ?>"><?php echo $option['label']; ?></label>
      </li>
      <?php } ?>
     </ul>
     <h4 class="theme_option_headline2"><?php _e('Other font size setting', 'tcd-w');  ?></h4>
     <ul class="option_list">
      <li class="cf"><span class="label"><?php _e('Headline', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[archive_work_headline_font_size]" value="<?php esc_attr_e( $options['archive_work_headline_font_size'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Description', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[archive_work_desc_font_size]" value="<?php esc_attr_e( $options['archive_work_desc_font_size'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Headline (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[archive_work_headline_font_size_mobile]" value="<?php esc_attr_e( $options['archive_work_headline_font_size_mobile'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Description (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[archive_work_desc_font_size_mobile]" value="<?php esc_attr_e( $options['archive_work_desc_font_size_mobile'] ); ?>" /><span>px</span></li>
     </ul>
     <ul class="button_list cf">
      <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
      <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
     </ul>
    </div><!-- END .theme_option_field_ac_content -->
   </div><!-- END .theme_option_field -->

   <?php // 記事一覧の設定 ----------------------------------------- ?>
   <div class="theme_option_field cf theme_option_field_ac">
    <h3 class="theme_option_headline"><?php printf(__('%s list setting', 'tcd-w'), $work_label); ?></h3>
    <div class="theme_option_field_ac_content">
     <div class="theme_option_message2">
      <p><?php _e( 'This setting will be applied in archive page, category page, single page related post, and content builder on top page.', 'tcd-w' ); ?></p>
     </div>
     <h4 class="theme_option_headline2"><?php _e('Font size setting', 'tcd-w');  ?></h4>
     <ul class="option_list">
      <li class="cf"><span class="label"><?php _e('Post title', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[work_list_title_font_size]" value="<?php esc_attr_e( $options['work_list_title_font_size'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php echo esc_html($area_label); ?></span><input class="font_size hankaku" type="text" name="dp_options[work_list_category_font_size]" value="<?php esc_attr_e( $options['work_list_category_font_size'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Post title (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[work_list_title_font_size_mobile]" value="<?php esc_attr_e( $options['work_list_title_font_size_mobile'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php printf(__('%s (mobile)', 'tcd-w'), $area_label); ?></span><input class="font_size hankaku" type="text" name="dp_options[work_list_category_font_size_mobile]" value="<?php esc_attr_e( $options['work_list_category_font_size_mobile'] ); ?>" /><span>px</span></li>
     </ul>
     <h4 class="theme_option_headline2"><?php printf(__('%s setting', 'tcd-w'), $area_label); ?></h4>
     <p class="displayment_checkbox"><label><input name="dp_options[show_work_list_category]" type="checkbox" value="1" <?php checked( $options['show_work_list_category'], 1 ); ?>><?php printf(__('Display %s', 'tcd-w'), $area_label); ?></label></p>
     <div style="<?php if($options['show_work_list_category'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
      <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
       <li class="cf"><span class="label"><?php _e('Font color', 'tcd-w'); ?></span><input type="text" name="dp_options[work_list_category_font_color]" value="<?php echo esc_attr( $options['work_list_category_font_color'] ); ?>" data-default-color="#ffffff" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php _e('Background color', 'tcd-w'); ?></span><input type="text" name="dp_options[work_list_category_bg_color]" value="<?php echo esc_attr( $options['work_list_category_bg_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
       <li class="cf">
        <span class="label"><?php _e('Transparency of background', 'tcd-w'); ?></span><input class="hankaku index_slider_overlay_opacity<?php echo $i; ?>" style="width:70px;" type="number" max="1" min="0" step="0.1" name="dp_options[work_list_caetgory_opacity]" value="<?php echo esc_attr( $options['work_list_caetgory_opacity'] ); ?>" />
        <div class="theme_option_message2" style="clear:both; margin:7px 0 0 0;">
         <p><?php _e('Please specify the number of 0.1 from 0.9. Overlay color will be more transparent as the number is small.', 'tcd-w');  ?></p>
        </div>
       </li>
      </ul>
     </div>
     <ul class="button_list cf">
      <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
      <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
     </ul>
    </div><!-- END .theme_option_field_ac_content -->
   </div><!-- END .theme_option_field -->

   <?php // 記事ページの設定 -------------------------------------------------------------------- ?>
   <div class="theme_option_field cf theme_option_field_ac">
    <h3 class="theme_option_headline"><?php _e('Single page setting', 'tcd-w');  ?></h3>
    <div class="theme_option_field_ac_content">
     <h4 class="theme_option_headline2"><?php _e('Font size setting', 'tcd-w');  ?></h4>
     <ul class="option_list">
      <li class="cf"><span class="label"><?php _e('Title', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[single_work_title_font_size]" value="<?php esc_attr_e( $options['single_work_title_font_size'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Content', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[single_work_content_font_size]" value="<?php esc_attr_e( $options['single_work_content_font_size'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Title (mobile)', 'tcd-w');  ?></span><input class="font_size hankaku" type="text" name="dp_options[single_work_title_font_size_mobile]" value="<?php esc_attr_e( $options['single_work_title_font_size_mobile'] ); ?>" /><span>px</span></li>
      <li class="cf"><span class="label"><?php _e('Content (mobile)', 'tcd-w');  ?></span><input class="font_size hankaku" type="text" name="dp_options[single_work_content_font_size_mobile]" value="<?php esc_attr_e( $options['single_work_content_font_size_mobile'] ); ?>" /><span>px</span></li>
     </ul>
     <h4 class="theme_option_headline2"><?php _e('Category setting', 'tcd-w');  ?></h4>
     <div class="theme_option_message2">
      <p><?php printf(__('You can set the color of %s individually from <a href="./edit-tags.php?taxonomy=area&post_type=work">%s category edit page</a>', 'tcd-w'), $area_label, $area_label); ?></p>
     </div>
     <p class="displayment_checkbox"><label><input name="dp_options[show_work_category]" type="checkbox" value="1" <?php checked( $options['show_work_category'], 1 ); ?>><?php _e( 'Display category', 'tcd-w' ); ?></label></p>
     <div style="<?php if($options['show_work_category'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
      <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
       <li class="cf"><span class="label"><?php printf(__('Font color of %s', 'tcd-w'), $landmark_label); ?></span><input type="text" name="dp_options[work_category_font_color]" value="<?php echo esc_attr( $options['work_category_font_color'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php printf(__('Background color of %s', 'tcd-w'), $landmark_label); ?></span><input type="text" name="dp_options[work_category_bg_color]" value="<?php echo esc_attr( $options['work_category_bg_color'] ); ?>" data-default-color="#000000" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php printf(__('Font color of %s on mouseover', 'tcd-w'), $landmark_label); ?></span><input type="text" name="dp_options[work_category_font_color_hover]" value="<?php echo esc_attr( $options['work_category_font_color_hover'] ); ?>" data-default-color="#FFFFFF" class="c-color-picker"></li>
       <li class="cf"><span class="label"><?php printf(__('Background color of %s on mouseover', 'tcd-w'), $landmark_label); ?></span><input type="text" name="dp_options[work_category_bg_color_hover]" value="<?php echo esc_attr( $options['work_category_bg_color_hover'] ); ?>" data-default-color="#999999" class="c-color-picker"></li>
      </ul>
     </div>
     <h4 class="theme_option_headline2"><?php _e('Related post setting', 'tcd-w');  ?></h4>
     <p class="displayment_checkbox"><label><input name="dp_options[show_related_work]" type="checkbox" value="1" <?php checked( $options['show_related_work'], 1 ); ?>><?php _e( 'Display related post', 'tcd-w' ); ?></label></p>
     <div style="<?php if($options['show_related_work'] == 1) { echo 'display:block;'; } else { echo 'display:none;'; }; ?>">
      <ul class="option_list" style="border-top:1px dotted #ccc; padding-top:12px;">
       <li class="cf"><span class="label"><?php _e('Number of post to display', 'tcd-w');  ?></span>
        <select name="dp_options[related_work_post_num]">
         <?php for($i=3; $i<= 12; $i++): ?>
         <?php if( $i % 3 == 0 ){ ?>
         <option style="padding-right: 10px;" value="<?php echo esc_attr($i); ?>" <?php selected( $options['related_work_post_num'], $i ); ?>><?php echo esc_html($i); ?></option>
         <?php }; ?>
         <?php endfor; ?>
        </select>
       </li>
       <li class="cf"><span class="label"><?php _e('Font size of headline', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[related_work_headline_font_size]" value="<?php esc_attr_e( $options['related_work_headline_font_size'] ); ?>" /><span>px</span></li>
       <li class="cf"><span class="label"><?php _e('Font size of headline (mobile)', 'tcd-w'); ?></span><input class="font_size hankaku" type="text" name="dp_options[related_work_headline_font_size_mobile]" value="<?php esc_attr_e( $options['related_work_headline_font_size_mobile'] ); ?>" /><span>px</span></li>
      </ul>
     </div>
     <h4 class="theme_option_headline2"><?php _e('Other setting', 'tcd-w');  ?></h4>
     <ul class="option_list">
      <li class="cf"><span class="label"><?php _e('Display next previous post link', 'tcd-w');  ?></span><input name="dp_options[show_work_nav]" type="checkbox" value="1" <?php checked( '1', $options['show_work_nav'] ); ?> /></li>
     </ul>
     <ul class="button_list cf">
      <li><input type="submit" class="button-ml ajax_button" value="<?php echo __( 'Save Changes', 'tcd-w' ); ?>" /></li>
      <li><a class="close_ac_content button-ml" href="#"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
     </ul>
    </div><!-- END .theme_option_field_ac_content -->
   </div><!-- END .theme_option_field -->


</div><!-- END .tab-content -->

<?php
} // END add_work_tab_panel()


// バリデーション　■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
function add_work_theme_options_validate( $input ) {

  global $dp_default_options, $pagenation_type_options, $work_list_animation_type_options;

  // 基本設定
  $input['work_label'] = wp_filter_nohtml_kses( $input['work_label'] );
  $input['work_category_bg_color'] = wp_filter_nohtml_kses( $input['work_category_bg_color'] );
  $input['work_category_bg_color_hover'] = wp_filter_nohtml_kses( $input['work_category_bg_color_hover'] );
  $input['work_category_font_color'] = wp_filter_nohtml_kses( $input['work_category_font_color'] );
  $input['work_category_font_color_hover'] = wp_filter_nohtml_kses( $input['work_category_font_color_hover'] );
  $input['landmark_label'] = wp_filter_nohtml_kses( $input['landmark_label'] );
  $input['landmark_slug'] = sanitize_title( $input['landmark_slug'] );
  $input['area_label'] = wp_filter_nohtml_kses( $input['area_label'] );
  $input['area_slug'] = sanitize_title( $input['area_slug'] );

  //ヘッダーの設定
  $input['work_catch'] = wp_filter_nohtml_kses( $input['work_catch'] );
  $input['work_desc'] = wp_filter_nohtml_kses( $input['work_desc'] );
  $input['work_catch_font_size'] = wp_filter_nohtml_kses( $input['work_catch_font_size'] );
  $input['work_catch_font_size_mobile'] = wp_filter_nohtml_kses( $input['work_catch_font_size_mobile'] );
  $input['work_desc_font_size'] = wp_filter_nohtml_kses( $input['work_desc_font_size'] );
  $input['work_desc_font_size_mobile'] = wp_filter_nohtml_kses( $input['work_desc_font_size_mobile'] );
  $input['work_catch_color'] = wp_filter_nohtml_kses( $input['work_catch_color'] );
  $input['work_desc_color'] = wp_filter_nohtml_kses( $input['work_desc_color'] );
  $input['work_bg_color'] = wp_filter_nohtml_kses( $input['work_bg_color'] );
  $input['work_bg_image'] = wp_filter_nohtml_kses( $input['work_bg_image'] );
  $input['work_bg_image_mobile'] = wp_filter_nohtml_kses( $input['work_bg_image_mobile'] );
  if ( ! isset( $input['work_use_overlay'] ) )
    $input['work_use_overlay'] = null;
    $input['work_use_overlay'] = ( $input['work_use_overlay'] == 1 ? 1 : 0 );
  $input['work_overlay_color'] = wp_filter_nohtml_kses( $input['work_overlay_color'] );
  $input['work_overlay_opacity'] = wp_filter_nohtml_kses( $input['work_overlay_opacity'] );

  // アーカイブページ
  $input['archive_work_headline_font_size'] = wp_filter_nohtml_kses( $input['archive_work_headline_font_size'] );
  $input['archive_work_headline_font_size_mobile'] = wp_filter_nohtml_kses( $input['archive_work_headline_font_size_mobile'] );
  $input['archive_work_desc_font_size'] = wp_filter_nohtml_kses( $input['archive_work_desc_font_size'] );
  $input['archive_work_desc_font_size_mobile'] = wp_filter_nohtml_kses( $input['archive_work_desc_font_size_mobile'] );
  if ( ! isset( $input['show_archive_work_tab'] ) )
    $input['show_archive_work_tab'] = null;
    $input['show_archive_work_tab'] = ( $input['show_archive_work_tab'] == 1 ? 1 : 0 );
  $input['archive_work_tab_font_size'] = wp_filter_nohtml_kses( $input['archive_work_tab_font_size'] );
  $input['archive_work_tab_font_size_mobile'] = wp_filter_nohtml_kses( $input['archive_work_tab_font_size_mobile'] );
  $input['archive_work_tab_font_color'] = wp_filter_nohtml_kses( $input['archive_work_tab_font_color'] );
  $input['archive_work_tab_bg_color'] = wp_filter_nohtml_kses( $input['archive_work_tab_bg_color'] );
  $input['archive_work_tab_bg_opacity'] = wp_filter_nohtml_kses( $input['archive_work_tab_bg_opacity'] );
  $input['archive_work_tab_bg_blur'] = wp_filter_nohtml_kses( $input['archive_work_tab_bg_blur'] );
  $input['archive_work_tab_font_color_hover'] = wp_filter_nohtml_kses( $input['archive_work_tab_font_color_hover'] );
  $input['archive_work_tab_bg_color_hover'] = wp_filter_nohtml_kses( $input['archive_work_tab_bg_color_hover'] );
  $input['archive_work_tab_bg_color_active'] = wp_filter_nohtml_kses( $input['archive_work_tab_bg_color_active'] );
  if ( ! isset( $input['show_archive_work_button'] ) )
    $input['show_archive_work_button'] = null;
    $input['show_archive_work_button'] = ( $input['show_archive_work_button'] == 1 ? 1 : 0 );
  $input['archive_work_button_font_size'] = wp_filter_nohtml_kses( $input['archive_work_button_font_size'] );
  $input['archive_work_button_font_size_mobile'] = wp_filter_nohtml_kses( $input['archive_work_button_font_size_mobile'] );
  $input['archive_work_button_font_color'] = wp_filter_nohtml_kses( $input['archive_work_button_font_color'] );
  $input['archive_work_button_bg_color'] = wp_filter_nohtml_kses( $input['archive_work_button_bg_color'] );
  $input['archive_work_button_font_color_hover'] = wp_filter_nohtml_kses( $input['archive_work_button_font_color_hover'] );
  $input['archive_work_button_bg_color_hover'] = wp_filter_nohtml_kses( $input['archive_work_button_bg_color_hover'] );
  $input['archive_work_button_label'] = wp_filter_nohtml_kses( $input['archive_work_button_label'] );
  if ( ! isset( $input['archive_work_list_animation_type'] ) )
    $input['archive_work_list_animation_type'] = null;
  if ( ! array_key_exists( $input['archive_work_list_animation_type'], $work_list_animation_type_options ) )
    $input['archive_work_list_animation_type'] = null;

  // 記事一覧
  $input['work_list_title_font_size'] = wp_filter_nohtml_kses( $input['work_list_title_font_size'] );
  $input['work_list_title_font_size_mobile'] = wp_filter_nohtml_kses( $input['work_list_title_font_size_mobile'] );
  $input['work_list_category_font_size'] = wp_filter_nohtml_kses( $input['work_list_category_font_size'] );
  $input['work_list_category_font_size_mobile'] = wp_filter_nohtml_kses( $input['work_list_category_font_size_mobile'] );
  $input['work_list_category_font_color'] = wp_filter_nohtml_kses( $input['work_list_category_font_color'] );
  $input['work_list_category_bg_color'] = wp_filter_nohtml_kses( $input['work_list_category_bg_color'] );
  $input['work_list_caetgory_opacity'] = wp_filter_nohtml_kses( $input['work_list_caetgory_opacity'] );
  if ( ! isset( $input['show_work_list_category'] ) )
    $input['show_work_list_category'] = null;
    $input['show_work_list_category'] = ( $input['show_work_list_category'] == 1 ? 1 : 0 );

  // 記事ページ
  $input['single_work_title_font_size'] = wp_filter_nohtml_kses( $input['single_work_title_font_size'] );
  $input['single_work_content_font_size'] = wp_filter_nohtml_kses( $input['single_work_content_font_size'] );
  $input['single_work_title_font_size_mobile'] = wp_filter_nohtml_kses( $input['single_work_title_font_size_mobile'] );
  $input['single_work_content_font_size_mobile'] = wp_filter_nohtml_kses( $input['single_work_content_font_size_mobile'] );
  if ( ! isset( $input['show_work_category'] ) )
    $input['show_work_category'] = null;
    $input['show_work_category'] = ( $input['show_work_category'] == 1 ? 1 : 0 );
  if ( ! isset( $input['show_work_nav'] ) )
    $input['show_work_nav'] = null;
    $input['show_work_nav'] = ( $input['show_work_nav'] == 1 ? 1 : 0 );

  // 関連記事
  if ( ! isset( $input['show_related_work'] ) )
    $input['show_related_work'] = null;
    $input['show_related_work'] = ( $input['show_related_work'] == 1 ? 1 : 0 );
  $input['related_work_headline_font_size'] = wp_filter_nohtml_kses( $input['related_work_headline_font_size'] );
  $input['related_work_headline_font_size_mobile'] = wp_filter_nohtml_kses( $input['related_work_headline_font_size_mobile'] );
  $input['related_work_post_num'] = wp_filter_nohtml_kses( $input['related_work_post_num'] );


	return $input;

};


?>