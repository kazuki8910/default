/* JavaScript (jQuery) */
jQuery(function(){
  jQuery('area').hover(
   function() { jQuery(this).focus(); },
   function() { jQuery(this).blur(); }
  )
});