<?php
     get_header();
     $options = get_design_plus_option();

     $catch = $options['blog_catch'];
     $desc = $options['blog_desc'];
     $headline = $options['archive_blog_headline'];

     $image_id = $options['blog_bg_image'];
     $image_id_mobile = $options['blog_bg_image_mobile'];
     $background_color = $options['blog_bg_color'];

     $use_overlay = $options['blog_use_overlay'];
     if($use_overlay) {
       $overlay_color = hex2rgb($options['blog_overlay_color']);
       $overlay_color = implode(",",$overlay_color);
       $overlay_opacity = $options['blog_overlay_opacity'];
     }

     if (is_category()) {
       $headline = single_cat_title('', false);
       $query_obj = get_queried_object();
       $cat_id = $query_obj->term_id;
       $term_meta = get_option( 'taxonomy_' . $cat_id, array() );
       if (!empty($term_meta['image'])){
         $image_id = $term_meta['image'];
       }
       if (!empty($term_meta['image_mobile'])){
         $image_id_mobile = $term_meta['image_mobile'];
       }
       if (!empty($term_meta['blog_use_overlay'])){
         if (!empty($term_meta['blog_overlay_color'])){
           $overlay_color = hex2rgb($term_meta['blog_overlay_color']);
           $overlay_color = implode(",",$overlay_color);
           if (!empty($term_meta['blog_overlay_opacity'])){
             $overlay_opacity = $term_meta['blog_overlay_opacity'];
           } else {
             $overlay_opacity = '0.3';
           }
         }
       }
     } elseif( is_tag() ) {
       $catch = single_tag_title('', false);
       $desc = tag_description();
     } elseif (is_day()) {
       $catch = sprintf(__('Archive for %s', 'tcd-w'), get_the_time(__('F jS, Y', 'tcd-w')) );
       $desc = '';
     } elseif (is_month()) {
       $catch = sprintf(__('Archive for %s', 'tcd-w'), get_the_time(__('F, Y', 'tcd-w')) );
       $desc = '';
     } elseif (is_year()) {
       $catch = sprintf(__('Archive for %s', 'tcd-w'), get_the_time(__('Y', 'tcd-w')) );
       $desc = '';
     } elseif (is_author()) {
       global $wp_query;
       $curauth = $wp_query->get_queried_object();
       $author_id = $curauth->ID;
       $user_data = get_userdata($author_id);
       $author_name = $user_data->display_name;
       $catch = sprintf(__('Archive for %s', 'tcd-w'), $author_name);
       $desc = '';
     } else {
     };
?>
<div id="page_header" <?php if( is_paged() || is_tag() || is_day() || is_month() || is_year() || is_author() ) { ?>class="small"<?php }; ?> style="background:<?php echo esc_attr($options['blog_bg_color']); ?>;">

 <?php if( is_paged() || is_tag() || is_day() || is_month() || is_year() || is_author() ) { } else { ?>

 <div id="page_header_catch">
  <?php if($catch){ ?><h2 class="catch rich_font animate_pc animate_mobile"><span><?php echo wp_kses_post(nl2br($catch)); ?></span></h2><?php }; ?>
  <?php if($desc){ ?><p class="desc animate_pc animate_mobile"><span><?php echo nl2br(esc_html($desc)); ?></span></p><?php }; ?>
 </div>
 <?php
      if($options['show_archive_blog_tab']){
        $archive_blog_tab_bg_color = hex2rgb($options['archive_blog_tab_bg_color']);
        $archive_blog_tab_bg_color = implode(",",$archive_blog_tab_bg_color);
 ?>
 <div id="tab_button_list">
  <div id="tab_button_list_inner">
   <ul class="clearfix">
    <li><span style="color:<?php echo esc_html($options['archive_blog_tab_font_color']); ?>; background:rgba(<?php echo esc_html($archive_blog_tab_bg_color); ?>,<?php echo esc_html($options['archive_blog_tab_bg_opacity']); ?>);"><?php echo esc_html($headline); ?></span></li>
   </ul>
  </div>
  <?php if(($image_id || $image_id_mobile) && $options['archive_blog_tab_bg_blur']) { ?>
  <?php if($use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>);"></div><?php }; ?>
  <div id="blur_bg" data-parallax-overlay-blur="<?php echo absint($options['archive_blog_tab_bg_blur']); ?>"></div>
  <?php }; ?>
 </div>
 <?php }; ?>

 <?php }; ?>


 <?php if($use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>);"></div><?php }; ?>
 <?php if($image_id || $image_id_mobile) { ?><div class="bg_image" data-parallax-image="<?php echo esc_attr(wp_get_attachment_url($image_id)); ?>" data-parallax-mobile-image="<?php echo esc_attr(wp_get_attachment_url($image_id_mobile)); ?>" data-parallax-speed="0"></div><?php }; ?>
</div>

<?php if( is_paged() || is_tag() || is_day() || is_month() || is_year() || is_author() ) { ?>
<?php get_template_part('template-parts/breadcrumb'); ?>
<?php }; ?>

<?php
     if( is_tag() || is_day() || is_month() || is_year() || is_author() ) {
       if($catch) {
?>
<div id="archive_catch">
 <h2 class="rich_font"><span><?php echo wp_kses_post(nl2br($catch)); ?></span></h2>
</div>
<?php }; }; ?>

<div id="archive_blog">

 <?php
      if( is_tag() || is_day() || is_month() || is_year() || is_author() ) {
        if($desc) {
 ?>
 <div id="archive_desc">
  <?php echo wp_kses_post($desc); ?>
 </div>
 <?php }; };?>

 <?php if ( have_posts() ) : ?>
 <div id="blog_list" class="clearfix">
  <?php
       while ( have_posts() ) : the_post();
          if(has_post_thumbnail()) {
            $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'size3' );
          } elseif($options['no_image2']) {
            $image = wp_get_attachment_image_src( $options['no_image2'], 'full' );
          } else {
            $image = array();
            $image[0] = esc_url(get_bloginfo('template_url')) . "/img/common/no_image3.gif";
          }
  ?>
  <article class="item">
   <?php if ( $options['show_archive_blog_category'] ){ ?>
   <p class="category"><?php echo the_category(' '); ?></p>
   <?php }; ?>
   <a class="link animate_background" href="<?php the_permalink() ?>">
    <div class="title_area">
     <?php if ( $options['show_archive_blog_date'] ){ ?>
     <p class="date"><time class="entry-date updated" datetime="<?php the_modified_time('c'); ?>"><?php the_time('Y.m.j'); ?></time></p>
     <?php }; ?>
     <h3 class="title rich_font"><span><?php the_title(); ?></span></h3>
    </div>
    <div class="image" style="background:url(<?php echo esc_attr($image[0]); ?>) no-repeat center center; background-size:cover;"></div>
    <div class="overlay"></div>
   </a>
   <p class="excerpt"><span><?php if ( post_password_required( $post ) ) { the_excerpt(); } else { echo trim_excerpt(140); } ?></span></p>
  </article>
  <?php endwhile; ?>
 </div><!-- END #blog_list -->
 <?php get_template_part('template-parts/navigation'); ?>
 <?php else: ?>
 <p id="no_post"><?php _e('There is no registered post.', 'tcd-w');  ?></p>
 <?php endif; ?>

</div><!-- END #archive_blog -->

<?php get_footer(); ?>