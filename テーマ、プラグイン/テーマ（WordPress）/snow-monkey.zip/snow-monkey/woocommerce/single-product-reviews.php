<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 * @version 5.6.1
 */
?>

<div class="p-comments">
	<div class="p-comments__form">
		<?php wc_get_template( 'single-product-reviews.php', [], true ); ?>
	</div>
</div>
