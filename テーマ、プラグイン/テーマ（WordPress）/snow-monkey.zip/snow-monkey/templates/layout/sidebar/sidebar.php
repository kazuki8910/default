<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 * @version 1.0.8
 */

do_action( 'snow_monkey_sidebar' );
