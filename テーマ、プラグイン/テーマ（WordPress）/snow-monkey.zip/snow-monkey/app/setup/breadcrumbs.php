<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 * @version 7.0.0
 */

add_filter( 'inc2734_wp_breadcrumbs_remove_last_link', '__return_false' );
