<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 * @version 5.1.3
 */

use Inc2734\WP_Basis\Bootstrap;

new Bootstrap();
