<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 * @version 5.0.0
 *
 * renamed: template-parts/profile-box.php
 */

echo do_shortcode( '[wp_profile_box]' );
