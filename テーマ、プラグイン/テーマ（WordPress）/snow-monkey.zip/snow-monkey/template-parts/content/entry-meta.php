<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 * @version 5.0.0
 *
 * renamed: template-parts/entry-meta.php
 */
?>

<ul class="c-meta">
	<?php do_action( 'snow_monkey_entry_meta_items' ); ?>
</ul>
