<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 * @version 6.0.0
 */
?>

<div class="c-entry__content p-entry-content">
	<?php wc_get_template_part( 'content', 'single-product' ); ?>
</div>
