# SANGO
Bold and handy WordPress theme

## DEMO
https://saruwakakun.design/

## Copyright
The php files in SANGO theme are under GNU General Public License(http://www.gnu.org/licenses/gpl-3.0.html).
On the other hand, copyright of CSS, Javascript and some of images belongs to saruwakakun.com.

### Sources

#### lazyload
Author: Andrea Verlicchi
URL: https://github.com/verlok/lazyload
License: MIT

#### FontAwesome
URL: https://fontawesome.com
Font License: SIL OFL 1.1
Code License: MIT License
Detail: https://fontawesome.com/license

#### Quicksand
Designer: Andrew Paglinawan
URL: https://fonts.google.com/specimen/Quicksand
License: Open Font License

#### Bones
Author: Eddie Machado
URL: http://themble.com/bones
License: WTFPL
License URL: http://sam.zoy.org/wtfpl/


## Submit Bugs
nodding.com@gmail.com
