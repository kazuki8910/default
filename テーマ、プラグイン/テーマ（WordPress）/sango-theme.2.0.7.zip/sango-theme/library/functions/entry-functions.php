<?php
/**
 * SANGOの投稿ページで使われる関数をまとめています。
 * - articleに含まれるクラス名を変更
 * - 1カラム設定用のクラス名を出力
 * - 記事下：おすすめ記事
 * - 記事下：CTA
 * - 記事下：フォローボックス
 * - この記事を書いた人
 * - ユーザープロフィールからSNSのURLを登録
 * - 関連記事
 * - 構造化データ
 * - コメント
 * -「前後の記事へ」用にタイトル文字数を制限
 * - シェアボタン
 * - excerpt（要約の末尾の「…」を変更）
 */

/*************************
 * articleに出力されるクラス名を変更
 **************************/
function no_hentry($classes) {
  // アイキャッチ画像なしクラスを出力
  global $post;
  if (!has_post_thumbnail($post->ID) && (!get_option('open_fab') || is_page())) {
    $classes[] = 'nothumb';
  }
  // hentryを出力しない
  $classes = array_diff($classes, array('hentry'));
  return $classes;
}
add_filter('post_class', 'no_hentry');

/*********************
 * 1カラム設定のときに特定のクラス名を出力
 *********************/
/**
 * 以下のどちらかの条件で1カラム設定
 * 1) カスタマイザーで「モバイルでサイドバーを表示しない」にチェック
 * 2) 投稿/固定ページで1カラム設定にチェック
 * どちらかに当てはまれば、one-columnのクラス名を出力
 */
if (!function_exists('column_class')) {
  function column_class() {
    global $post;
    if ((wp_is_mobile() && get_option('no_sidebar_mobile')) || get_post_meta($post->ID, 'one_column_options', true)) {
      echo ' class="one-column"';
    }
  }
}

/*********************
 * 記事下に表示するおすすめの記事
 *（カスタマイザーから4つまで登録可能）
 *********************/
if (!function_exists('sng_recommended_posts')) {
  function sng_recommended_posts() {
    if (get_option('enable_recommend')) {
      if (get_option('recommend_title')) {
        echo '<h3 class="h-undeline related_title">' . get_option('recommend_title') . '</h3>';
      }
      // タイトル（未入力なら非表示）
      echo '<div class="recommended cf">';
      global $post;
      $i = 0;
      while ($i < 4) {
        $i++;
        $url_option_name = 'recid' . $i; // カスタマイザーに入力されたURLを取得するための名前
        $id = esc_attr(get_option($url_option_name)); // 記事のID
        $url = get_permalink($id); // 記事のURL
        $title_option_name = 'rectitle' . $i; // カスタマイザーに入力されたタイトルを取得するための名前
        $title = (get_option($title_option_name)) ? get_option($title_option_name) : get_the_title($id); //記事のタイトルを取得：カスタマイザーで未入力の場合、デフォルトのタイトルを取得
        if ($id && ($id != $post->ID)):
        ?>
        <a href="<?php echo esc_attr($url); ?>">
          <figure><?php echo get_the_post_thumbnail($id, 'thumb-160'); ?></figure>
          <div><?php echo esc_attr($title); ?></div>
        </a>
        <?php endif;
      } // endwhile
      echo '</div>';
    } // endif
  } // end function
}

/**************************
 * 記事下CTA
 ***************************/
if (!function_exists('insert_cta')) {
  function insert_cta() {
    if (!get_option('enable_cta')) return;
    $exclude_cat = explode(',', get_option('no_cta_cat')); // CTAを表示しないカテゴリー
    if (in_category($exclude_cat)) return;
?>
  <div class="cta" style="background: <?php echo get_theme_mod('cta_background_color', '#c8e4ff'); ?>;">
    <?php if (get_option('cta_big_txt')): ?>
      <h3 style="color: <?php echo get_theme_mod('cta_bigtxt_color', '#333'); ?>;">
        <?php echo get_option('cta_big_txt'); ?>
      </h3>
    <?php endif;
      if (get_option('cta_image_upload')): ?>
      <p class="cta-img">
        <img src="<?php echo esc_url(get_option('cta_image_upload')); ?>" <?php sng_lazy_attr(); ?>/>
      </p>
    <?php endif;
      if (get_option('cta_sml_txt')): ?>
        <p class="cta-descr" style="color: <?php echo get_theme_mod('cta_smltxt_color', '#333'); ?>;"><?php echo get_option('cta_sml_txt'); ?></p>
    <?php endif;
      if (get_option('cta_btn_txt')): ?>
      <p class="cta-btn"><a class="raised" href="<?php echo esc_url(get_option('cta_btn_url')); ?>" style="background: <?php echo get_theme_mod('cta_btn_color', '#ffb36b'); ?>;"><?php echo get_option('cta_btn_txt'); ?></a></p>
    <?php endif;?>
  </div>
<?php
  }
}
/*********************
 * フォローボックス（この記事が気に入ったらいいね）
 *********************/
if (!function_exists('insert_like_box')) {
  function insert_like_box() {
    if (!get_option('enable_like_box')) return;

    $user_tw = (get_option('like_box_twitter')) ? esc_attr(get_option('like_box_twitter')) : null;
    $url_fb = (get_option('like_box_fb')) ? esc_url(get_option('like_box_fb')) : null;
    $url_fdly = (get_option('like_box_feedly')) ? esc_url(get_option('like_box_feedly')) : null;
    $url_insta = (get_option('like_box_insta')) ? esc_url(get_option('like_box_insta')) : null;
    $url_youtube = (get_option('like_box_youtube')) ? esc_url(get_option('like_box_youtube')) : null;
    $line_id = (get_option('like_box_line_friend_id')) ? esc_attr(get_option('like_box_line_friend_id')) : null;
    $title = (get_option('like_box_title')) ? '<p class="dfont">' . get_option('like_box_title') . '</p>' : "";
  ?>
  <div class="like_box">
    <div class="like_inside">
      <div class="like_img">
        <img src="<?php echo featured_image_src('thumb-520'); ?>" <?php sng_lazy_attr(); ?>>
        <?php echo $title; ?>
      </div>
      <div class="like_content">
        <p>この記事が気に入ったらフォローしよう</p>
        <?php if ($user_tw): ?>
          <div><a href="https://twitter.com/<?php echo $user_tw; ?>" class="twitter-follow-button" data-show-count="<?php echo get_option('follower_count') ? 'true' : 'false'; ?>" data-lang="ja" data-show-screen-name="false" rel="nofollow">フォローする</a> <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script></div>
        <?php endif; ?>
        <?php if ($line_id): ?>
          <div class="like-line-friend">
            <div class="line-it-button" data-lang="ja" data-type="friend" data-lineid="<?php echo $line_id; ?>" data-count="<?php echo get_option('like_box_line_show_follower_count') ? 'true' : 'false'; ?>" style="display: none;"></div>
            <script src="https://d.line-scdn.net/r/web/social-plugin/js/thirdparty/loader.min.js" async="async" defer="defer"></script>
          </div>
        <?php endif; ?>
        <?php if ($url_fdly): ?>
          <div><a href="<?php echo $url_fdly; ?>" target="blank" rel="nofollow"><img src="<?php echo get_template_directory_uri() . '/library/images/feedly.png'; ?>" alt="follow me on feedly" width="66" height="20" <?php sng_lazy_attr(); ?>></a></div>
        <?php endif; ?>
        <?php if ($url_fb): ?>
          <div><div class="fb-like" data-href="<?php echo $url_fb; ?>" data-layout="button_count" data-action="like" data-share="false"></div></div>
          <?php fb_like_js(); ?>
        <?php endif; ?>
        <?php if ($url_insta): ?>
          <div><a class="like_insta" href="<?php echo $url_insta; ?>" target="blank" rel="nofollow"><?php fa_tag("instagram","instagram",true) ?> <span>フォローする</span></a></div>
        <?php endif; ?>
        <?php if ($url_youtube): ?>
          <div><a class="like_youtube" href="<?php echo $url_youtube; ?>" target="blank" rel="nofollow"><?php fa_tag("youtube","youtube",true) ?> <span>YouTube</span></a></div>
        <?php endif; ?>
      </div>
    </div>
  </div>
<?php 
  } // end function
}

// facebookいいねボタン用のjs。カスタマイザーで登録済みの場合のみ出力
function fb_like_js() {
  echo <<< EOM
  <div id="fb-root"></div>
  <script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "https://connect.facebook.net/ja_JP/sdk.js#xfbml=1&version=v3.0";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));</script>
EOM;
}

/*********************
 * この記事を書いた人
 *********************/
if (!function_exists('insert_author_info')) {
  function insert_author_info() {
    $author_descr = get_the_author_meta('description');
    // プロフィール情報が空欄のときは表示しない
    if (empty($author_descr)) return;
  ?>
	  <div class="author-info pastel-bc">
	    <div class="author-info__inner">
	      <div class="tb">
	        <div class="tb-left">
	        <div class="author_label">
	          <span>この記事を書いた人</span>
	        </div>
          <div class="author_img"><?php 
            $iconimg = get_avatar(get_the_author_meta('ID'), 100);
            if($iconimg) echo $iconimg; ?></div>
	          <dl class="aut">
              <dt>
                <a class="dfont" href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
                  <span><?php esc_attr(the_author_meta('display_name')); //名前 ?></span>
                </a>
              </dt>
              <dd><?php esc_attr(the_author_meta('yourtitle'));?></dd>
	          </dl>
	        </div>
          <div class="tb-right">
            <p><?php the_author_meta('user_description'); //プロフィール文 ?></p>
            <div class="follow_btn dfont">
            <?php
              $socials = array(
                'Twitter' => esc_attr(get_the_author_meta('twitter')),
                'Facebook' => esc_url(get_the_author_meta('facebook')),
                'Instagram' => esc_url(get_the_author_meta('instagram')),
                'Feedly' => esc_url(get_the_author_meta('feedly')),
                'LINE' => esc_url(get_the_author_meta('line')),
                'YouTube' => esc_url(get_the_author_meta('youtube')),
                'Website' => esc_url(get_the_author_meta('url')),
              );
              foreach ($socials as $name => $url) {
                if ($url) { ?>
                  <a class="<?php echo $name; ?>" href="<?php echo esc_url($url); ?>" target="_blank" rel="nofollow noopener noreferrer"><?php echo esc_attr($name); ?></a>
          <?php }
              }?>
            </div>
          </div>
	      </div>
	    </div>
	  </div>
	<?php }
}

/*********************
 * ユーザー管理画面からfacebookやTwitterを登録
 *********************/
function add_user_contactmethods($user_contactmethods) {
  return array(
    'yourtitle' => '肩書き（入力するとプロフィールに表示）',
    'twitter' => 'TwitterのURL',
    'facebook' => 'FacebookのURL',
    'instagram' => 'InstagramのURL',
    'feedly' => 'FeedlyのURL',
    'youtube' => 'YouTubeのURL',
    'line' => 'LINEのURL',
  );
}
add_filter('user_contactmethods', 'add_user_contactmethods');

/*************************
 * 関連記事
 **************************/

// 親カテゴリーとその子カテゴリー（＝兄弟カテゴリー）を取得する関数
if (!function_exists('get_parent_and_siblings_cat_ids')) {
  function get_parent_and_siblings_cat_ids($category) {
    $ids = array();
    $parent_id = $category->category_parent; // 親カテゴリーを取得
    if(!$parent_id) return $category->cat_ID; // 親カテゴリがない場合はそのカテゴリだけ返す
    
    $child_catids = get_term_children($parent_id, 'category');
    foreach ($child_catids as $id) {
      $ids[] .= $id; // 子のIDを配列に追加
    }
    $ids[] .= $parent_id; // 親のIDを配列に追加
    return $ids; // 自身 + 親 + 兄弟 のID
  }
}

// 関連記事データの取得
if (!function_exists('sng_get_related_posts_array')) {
  function sng_get_related_posts_array() {
    global $post;
    $categories = get_the_category();
    if (!$categories) return null;

    $catid = (get_option('related_add_parent')) ?  get_parent_and_siblings_cat_ids($categories[0]) : $categories[0]->cat_ID;
    $num = (get_option('num_related_posts')) ? esc_attr(get_option('num_related_posts')) : 6;
    $orderby = (get_theme_mod('related_posts_order') == "date") ? "date" : "rand";

    $args = array(
      'category__in' => $catid,
      'exclude' => $post->ID,
      'numberposts' => $num,
      'orderby' => $orderby
    );
    
    $days_ago = get_option('related_posts_days_ago');
    if($days_ago && $days_ago != "0") {
      $args['date_query'] = array(
        array(
          'after' => date_i18n('Y-m-d 0:0:0', strtotime("- $days_ago days")),
          'inclusive' => true
        ),
      );
    }
   return get_posts($args);
  }
}

// 関連記事の出力
if (!function_exists('output_sng_related_posts')) {
  function output_sng_related_posts() {
    $related_posts = sng_get_related_posts_array();
    if(!$related_posts) return;

    $design = get_theme_mod('related_posts_type') ? esc_attr(get_theme_mod('related_posts_type')) : 'type_a';
    $design .= get_option('related_no_slider') || ($design == 'type_c') ? ' no_slide' : ' slide';

    if (get_option('related_post_title')) echo '<h3 class="h-undeline related_title">' . get_option('related_post_title') . '</h3>';
    echo '<div class="related-posts ' . $design . '" ontouchstart =""><ul>';
    foreach ($related_posts as $related_post) :
      $src = featured_image_src('thumb-520', $related_post->ID);
      $title = $related_post->post_title;
  ?>
  <li>
    <a href="<?php echo get_permalink($related_post->ID); ?>">
      <figure class="rlmg">
        <img src="<?php echo $src; ?>" alt="<?php echo $title; ?>">
      </figure>
      <div class="rep"><p><?php echo $title ?></p></div>
    </a>
  </li>
  <?php
    endforeach;
    wp_reset_postdata();
    echo '</ul></div>';
  } /* end related posts function */
}

/*********************
 * 構造化データ挿入
 *********************/
if (!function_exists('insert_json_ld')) {
  function insert_json_ld() {
    $src_info = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');
    if ($src_info) {
      $src = $src_info[0];
      $width = $src_info[1];
      $height = $src_info[2];
    } else { // アイキャッチ画像が無い場合はデフォルトの登録画像
      $src = featured_image_src('thumb-520');
      $width = '520';
      $height = '300';
    }
    $page_url = get_the_permalink();
    $headline = esc_attr(get_the_title());
    $date_published = get_the_date(DATE_ISO8601);
    $date_modified = (get_the_date() != get_the_modified_time()) ? get_the_modified_date(DATE_ISO8601) : get_the_date(DATE_ISO8601);
    $author_name = get_the_author_meta('display_name');
    $publisher_name = esc_attr(get_option('publisher_name'));
    $publisher_logo_url = esc_url(get_option('publisher_img'));
    $description = esc_attr(get_the_excerpt());

    $json = <<< EOM
    {
      "@context": "http://schema.org",
      "@type": "Article",
      "mainEntityOfPage":"{$page_url}",
      "headline": "{$headline}",
      "image": {
        "@type": "ImageObject",
        "url": "{$src}",
        "width": {$width},
        "height": {$height}
      },
      "datePublished": "{$date_published}",
      "dateModified": "{$date_modified}",
      "author": {
        "@type": "Person",
        "name": "{$author_name}"
      },
      "publisher": {
        "@type": "Organization",
        "name": "{$publisher_name}",
        "logo": {
          "@type": "ImageObject",
          "url": "{$publisher_logo_url}"
        }
      },
      "description": "{$description}"
    }
EOM;
    echo '<script type="application/ld+json">' . sng_minify_js($json) . '</script>';
  }
}
/*************************
 * コメントレイアウト（comments.phpで呼び出し）
 **************************/
if (!function_exists('sng_comments')) {
  function sng_comments($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;?>
    <div id="comment-<?php comment_ID();?>" <?php comment_class('cf');?>>
      <article  class="cf">
        <header class="comment-author vcard">
          <?php $bgauthemail = get_comment_author_email(); ?>
          <?php echo get_avatar($comment, 40); ?>
          <?php printf('<cite class="fn">%1$s</cite> %2$s', get_comment_author_link(), edit_comment_link('(Edit)', '  ', ''))?>
          <time datetime="<?php echo comment_time('Y-m-j'); ?>"><a href="<?php echo htmlspecialchars(get_comment_link($comment->comment_ID)) ?>" rel="nofollow"><?php comment_time(get_option( 'date_format' ));?></a></time>
        </header>
        <?php if ($comment->comment_approved == '0'): ?>
          <div class="alert alert-info">
            <p><?php echo 'あなたのコメントは現在承認待ちです。'; ?></p>
          </div>
        <?php endif;?>
        <section class="comment_content cf">
          <?php comment_text()?>
        </section>
        <?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth'])))?>
      </article>
  <?php
  } //END sng comments
}

/*********************
 * 文字数を制限しながらタイトルを出力
 * ⇒前の記事/次の記事へのリンクで使用
 *********************/
function lim_title($id) {
  $raw = esc_attr(get_the_title($id));
  if (mb_strlen($raw, 'UTF-8') > 31) {
    $title = mb_substr($raw, 0, 31, 'UTF-8');
    echo $title . '…';
  } else {
    echo $raw;
  }
}

/*********************
 * excerptの…を変更
 *********************/
function sng_excerpt_more($more) {
  return ' ... ';
}
add_filter('excerpt_more', 'sng_excerpt_more');